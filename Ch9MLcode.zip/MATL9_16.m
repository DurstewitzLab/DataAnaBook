clear all
close all

%% State inference & parameter estimation for recurrent neural network (RNN)
%     x(t) = A x(t-1) + W sigm(x(t-1)) + Inp(t) + eps(t), eps(t) ~ N(0,S)
%     x(1) ~ N(mu0,S)
%     c(t)|x(t) ~ Poisson[exp(log(b0)+B1 x(t))]
% --> based on Yu, B.M., Afshar, A., Santhanam, G., Ryu,S.I., Shenoy.K.V.: 
% Extracting Dynamical Structure Embedded in Neural Activity. 
% Advances in Neural Information Processing Systems 18, pp. 1545‐1552 (2005)


%% generate simple 3-unit RNN test case
RNNoscTestCase;

% ... produce noisy count time series from it
rand('state',0)
[N,T]=size(Xout);
b0=[3 5 7]';    % base rate parameters
b1=[3 2 1]';    % linear transform of latent states
mu=b0*ones(1,T).*exp((b1*ones(1,T)).*Xout); % conditional mean of Poisson process
C=poissrnd(mu); % produce Poisson count series
save('RNN_TestCase','Xout','GxOut','W','a','InpVal','par','Ntrials','b0','b1','C');

% plot observed count series
figure(1), hold off cla
subplot(4,2,1), plot(C','o-','LineWidth',2); box off
axis([1900 2000 0 55])
set(gca,'FontSize',24,'XTickLabel',''); ylabel('count')
title('Observed count process');
legend('c_1','c_2','c_3','Orientation','horizontal','Position',[350,545,0.2,0.1]); legend('boxoff');


%% estimate state path given correct parameters
ga=par{1};  % slopes of sigmoid activ. func.
th=par{2};  % thresholds of sigmoid activ. func.
S=diag(par{7}); % process noise cov matrix
It=repmat(InpVal,1,Ntrials);    % external inputs
m0=Xout(:,1);   % initial process mean
B1=diag(b1);    % observation regression matrix
[m,V,CV]=StatePathEstimRNN(C,a,W,It,S,b0,B1,ga,th,m0);  % run estimation
save('RNNstateEstim','m','V','CV','It');
Mt=cell2mat(m); % inferred latent states

% graph agreement true vs. inferred latent states
for i=1:3
    subplot(4,2,2*i+1), hold off cla
    plot(1:T,Xout(i,:),'g',1:T,Mt(i,:),'k--','LineWidth',2);
    xmi=min(Xout(i,1900:2000))-0.1*abs(min(Xout(i,:)));
    xmx=max(Xout(i,1900:2000))+0.1*abs(max(Xout(i,:)));
    axis([1900 2000 xmi xmx]), box off
    set(gca,'FontSize',24); ylabel(['x_' num2str(i)]);
    if i<3, set(gca,'XTickLabel',''); end;
    if i==1, title('State estimates'); end;
end;
xlabel('time step');
legend('true','estimate','Position',[250,370,0.2,0.1]); legend('boxoff');


%% estimate parameters given state path
clear all

load('RNN_TestCase');   % load true param.s
ga=par{1};  % slopes of sigmoid activ. func.
th=par{2};  % thresholds of sigmoid activ. func.
B1ini=3*diag(rand(3,1));    % needs initialization, since solved for numerically

load('RNNstateEstim');  % load estimated states

% estimate parameters given states
[w0est,West,Sest,b0est,B1est,m0est,LL]=ParamEstimRNN(C,It,ga,th,m,V,CV,B1ini);
 
% graph agreement true vs. estimated parameters
Y={[b0 b0est];[b1 diag(B1est)];[a w0est];[W(1:end)' West(1:end)']};
ylbl={'\beta_0';'\beta_1';'\alpha';'W'};
for i=1:length(Y)
    subplot(4,2,2*i), hold off cla
    bar(Y{i}), set(gca,'FontSize',24); ylabel(ylbl{i}); box off
    if i<4, axis([0 length(Y{i}(:,1))+1 0 1.1*max(Y{i}(1:end))]);
    else
        xmi=min(Y{i}(1:end))-0.1*abs(min(Y{i}(1:end)));
        xmx=max(Y{i}(1:end))+0.1*abs(max(Y{i}(1:end)));
        axis([0 length(Y{i}(:,1))+1 xmi xmx]);
    end;
    if i==1, title('Parameter estimates'); end;
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
