clear all
close all

%% Fig. 9.1: Linear map

alp=0.5; c=1;   % parameters of map
a=zeros(1,200);
a(1)=0.5;   % initial value
for n=2:length(a)     % iterate map
    a(n)=alp*a(n-1)+c;
end;

%% plot successive values of a(n) (time graph):
subplot(1,2,1), hold off, plot(a,'LineWidth',2,'Color','b');
axis([0 20 0 3]); set(gca,'FontSize',20), box off
title(['Time graph']); xlabel('t'); ylabel('x_t');

%% plot a(n+1) as function of a(n) (return plot):
a1=0:0.05:4;
subplot(1,2,2), hold off
plot(a1,alp*a1+c,'b',a1,a1,'g','LineWidth',2); % plot map & bisectrix
hold on;
i=1:(length(a)-1); i=ones(2,1)*i;
j(1:2*(length(a)-1))=i;
k(1:(2*(length(a)-1)-1))=j(2:end);
k(2*(length(a)-1))=j(end)+1;
plot(a(j),a(k),'r','LineWidth',2);  % plot cobweb
set(gca,'FontSize',20), box off
title(['Return plot']); xlabel('x_t'); ylabel('x_t_+_1');
text(a(1),0.3,'\it{x_o}    \it{x_1}   \it{x^*}','FontSize',20,'Color','red');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University