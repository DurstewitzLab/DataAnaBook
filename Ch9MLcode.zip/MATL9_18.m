clear all
close all

%% Fig. 9.24: Delay embedding and attractor reconstruction using simulated 
% 3-ODE system for different embedding time lags

% simulate Lorenz ODE system
r=28; s=10; b=8/3;  % parameters
v0=[1 1 1]; % initial condition
tstop=1000; % simulation time
opt=odeset('RelTol',1e-5,'AbsTol',1e-8);
[t,v]=ode23(@LorenzEqns,[0 tstop],v0,opt,r,s,b);    % numerical solver
k=find(t>=100); t=t(k); v=v(k,:);   % extract 'steady state' trajectory

%% plot original time series
figure(31), hold off cla
subplot(3,2,1), plot(t,v(:,2),'LineWidth',2)
set(gca,'FontSize',20); title('Time graph');
xlabel('t'); ylabel('y'); box off; axis([300 400 -30 30]);
% ... and state space
k=find(t>=700);
subplot(3,2,2), plot3(v(k,1),v(k,2),v(k,3),'LineWidth',2)
set(gca,'FontSize',20); title('State space trajectory')
xlabel('x'); ylabel('y'); zlabel('z'); box off;
xlim([-20 20]); ylim([-30 30]); zlim([0 50])

%% plot delay embeddings for different time lags
lag=[1 5 20 200];   % range of lags
D=3;    % embedding dim.
for l=1:length(lag)
    % create delay embedding vector from scalar observations:
    y=v(:,2)'; for i=1:D-1, y=[y;circshift(v(:,2)',[0 i*lag(l)])]; end; y=y';
    % plot reconstructed space:
    subplot(3,2,l+2), plot3(y(k,1),y(k,2),y(k,3),'LineWidth',2);
    set(gca,'FontSize',20); xlabel('y_t');
    ylabel(['y_{t-' num2str(lag(l)) '}']); zlabel(['y_{t-' num2str(2*lag(l)) '}']); box off;
    title(['lag = ' num2str(lag(l))]);
    xlim([-30 30]); ylim([-30 30]); zlim([-30 30]);
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
