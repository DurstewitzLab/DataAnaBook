clear all
close all

%% Fig. 9.20: Phase coupling in spike train/ LFP data

load placecell.mat  % experimental data set, provided by Dr. Matt Jones, Bristol

%% filter LFP data in theta freq. range
Fs=1/mean(diff(ts));
[b,a]=butter(2,[5/(Fs/2) 10/(Fs/2)]);
LFPf=filtfilt(b,a,lfp);

%% extract oscillation minima from filtered signal
[MinT,MinV]=ExtrOscMin2(LFPf,10,0.8,0.33*0.15,0);
Tosc=ts(MinT(2:end-1)); Vosc=MinV(2:end-1);
ST=tt3_3;
twin=[5380 5880];
k=find(ST>twin(1) & ST<=twin(2)); ST=ST(k);

%% determine phase of all spikes
STph=zeros(size(ST));
for m=1:length(ST)
    k=find(Tosc<=ST(m),1,'last');
    STph(m)=(ST(m)-Tosc(k))/(Tosc(k+1)-Tosc(k));
end;
STph=STph*2*pi-pi;

%% plot phase stroboscope
subplot(1,3,2), hold off cla
plot(ST,STph,'r.','MarkerSize',10,'LineWidth',2), axis([twin(1) twin(2) -pi pi])
set(gca,'FontSize',20); xlabel('Spike times (s)'); ylabel('LFP \theta-band phase');
title('Phase Stroboscope');

%% plot phase histogram
subplot(1,3,3), hold off cla
phBins=-pi:2*pi/25:pi;
hPh=histc(STph,phBins); hPh(end-1)=hPh(end-1)+hPh(end); hPh=hPh(1:end-1);
phV=phBins(1:end-1)+mean(diff(phBins))/2;
Nbins=length(phV);
ME=ones(1,Nbins).*length(ST)/Nbins;
% confidence bands from binomial:
CIlow=ones(1,Nbins).*binoinv(0.05,length(ST),1/Nbins);
CIhigh=ones(1,Nbins).*binoinv(0.95,length(ST),1/Nbins);
bar(phV,hPh,'b'); hold on
plot(phV,ME,'r-',phV,CIlow,'r--',phV,CIhigh,'r--','LineWidth',2);
% cubic spline fit:
SplFit=CubicSpline(phV',hPh,phV',8);
hold on, plot(phV,SplFit,'g','LineWidth',2); box off
xlim([-pi pi]); set(gca,'FontSize',20), %ylim([0 15])
xlabel('\theta phase'); ylabel('spike count');
title('Phase Histogram'); 

%% illustration of ST - phase relation
subplot(1,3,1), hold off cla
plot(ts,LFPf,'b',ST,0,'r+','MarkerSize',10,'LineWidth',2)
set(gca,'FontSize',20); xlabel('Time (s)'); ylabel('LFP / spike times');
axis([5535.5 5536.2 -110 110])
title('Spike - LFP relation');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
