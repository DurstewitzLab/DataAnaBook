function [m,V,CV]=StatePathEstimRNN(ct,w0,W,Inp,S,b0,B1,ga,th,m0)
% Extended Kalman filter-smoother recursions for state space model
%     x(t) = A x(t-1) + W sigm(x(t-1)) + Inp(t) + eps(t), eps(t) ~ N(0,S)
%     x(1) ~ N(mu0,S)
%     c(t)|x(t) ~ Poisson[exp(log(b0)+B1 x(t))]
% based on Yu, B.M., Afshar, A., Santhanam, G., Ryu,S.I., Shenoy.K.V.: 
% Extracting Dynamical Structure Embedded in Neural Activity. 
% Advances in Neural Information Processing Systems 18, pp. 1545‐1552 (2005)
%
% INPUTS:
% ct: MxT observed count series
% w0: Mx1 vector of auto-regressive weights 
% W: MxM matrix of coupling weights
% Inp: MxT matrix of external inputs 
% S: MxM diagonal covariance matrix (Gaussian process noise)
% b0: Poisson base rates
% B1: NxM matrix of regression weights
% ga: slopes of sigmoids
% th: thresholds of sigmoids
% m0: prior state mean
%
% OUTPUTS:
% m: posterior state estimates (arranged in cell array)
% V: posterior covariance estimate at t (arranged in cell array)
% CV: posterior covariance estimate for t,t+1 

%% define transfer function and derivative
phi=@(x) 1./(1+exp(ga.*(th-x)));
dphi=@(x) ga.*exp(ga.*(th-x)).*(1+exp(ga.*(th-x))).^-2;

errTol=1e-6;    % error tolerance for numerical solution for posterior states
MaxSteps=100;   % max. iterations for numerical solver

[~,T]=size(ct);
m=cell(1,T); V=cell(1,T);

%% Extended Kalman-filter recursions
B=cell(1,T); C=cell(1,T); L=cell(1,T);
for t=1:T
    
    % Linearization
    if t==1  % first time step requires special treatment based on priors
        B{t}=eye(size(W));
        C{t}=Inp(:,t);
        L{t}=S; % prior covariance
        mf=m0;  % prior mean
        x=m0;   % initialize
    else
        B{t}=diag(w0)+W*diag(dphi(m{t-1}));
        C{t}=W*(phi(m{t-1})-dphi(m{t-1}).*m{t-1})+Inp(:,t);
        L{t}=B{t}*V{t-1}*B{t}'+S;   % forwarded covariance
        mf=B{t}*m{t-1}+C{t};  % forwarded mean
        x=m{t-1};   % initialize
    end
    
    % Solve for states by Newton-Raphson
    xOld=1e8; k=0;
    while sum(abs(xOld-x))>errTol && k<MaxSteps
        u=b0.*exp(B1*x);
        dQ=B1'*(ct(:,t)-u)-L{t}^-1*(x-mf);  % first derivatives
        ddQ=-B1'*diag(u)*B1-L{t}^-1;    % second derivatives
        xOld=x; k=k+1;
        x=x-ddQ^-1*dQ;
        x=max(min(x,4),-4);   % constrain state estimates
    end;
    m{t}=x; % posterior mean
    V{t}=-ddQ^-1;   % posterior covariance = neg. inv. Hessian
    
end;
V{t}=(V{t}+V{t}')./2;  % ensure symmetry


%% Kalman-smoother recursions
CV=cell(1,T);   % covariance across (t,t+1)
for t=T-1:-1:1
    Z=V{t}*B{t+1}'*L{t+1}^-1;
    m{t}=m{t}+Z*(m{t+1}-B{t+1}*m{t}-C{t+1});    % smoothed mean
    V{t}=V{t}+Z*(V{t+1}-L{t+1})*Z'; % smoothed covariance
    V{t}=(V{t}+V{t}')./2;  % ensure symmetry
    CV{t+1}=V{t+1}*Z';  % (t,t+1)-covariance
end;


%% this implementation:
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
