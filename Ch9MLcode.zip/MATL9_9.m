clear all
close all

%% Fig. 9.11: Wilson-Cowan-type ODE neural model
% - consists of a 'population' of excitatory (E) and one of inhibitory (I)
% units
% - illustrates bistability (via saddle node bifurcation)

%% parameters specifying system
slopeE=4;   % slope of sigmoid of E-unit
halfE=0.4;  % half activation threshold of E sigmoid
wei=0.5;    % I-->E connection weight
IextE=0;    % external input to E-unit
IextI=0;    % external input to I-unit
halfI=0.35; % half activation threshold of I sigmoid
tauE=30;    % time constant of E unit
wie=0.5;    % E-->I connection weight
tauI=5;     % time constant of I unit
slopeI=1;   % slope of sigmoid of I-unit
weeL=[1.15 1.23 1.3 1.45];  % list of E-->E connection weights

%% simulate E-I model & plot results
figure(16), hold off cla
for i=1:length(weeL)
    par=[weeL(i) wei IextE slopeE halfE tauE wie IextI slopeI halfI tauI];
    if i==3, Stim=true; else Stim=false; end;   % external stim in 3rd run
    ncEImodel([4 i],par,[],Stim);   % run model
    subplot(4,3,3*(i-1)+1);
    text(800,45,['$$w_{EE} = ' num2str(weeL(i)) '$$'],'Interpreter','latex','FontSize',18);
end;
subplot(4,3,1), title('Time graph');
subplot(4,3,2), title('State space');
subplot(4,3,3), title('Eigenvalues');
subplot(4,3,10), xlabel('Time (ms)');
subplot(4,3,11), xlabel('\itR\rm_e_x_c (Hz)');
subplot(4,3,12), xlabel('\it{i}');
for i=1:9, gca=subplot(4,3,i); set(gca,'XTickLabel',''); end;
for i=3:3:12, subplot(4,3,i), axis([0 3 -0.22 0.05]); end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
