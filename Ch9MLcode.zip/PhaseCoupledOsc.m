function [t,phi1,phi,dphi]=PhaseCoupledOsc(w,A,phi0,Tend,m)
% simulates evolution of phase-difference for 2 coupled oscillators
% (cf. Strogatz, 1994, Nonlinear dynamics & chaos. Perseus.)
% --- INPUTS
% w: 1x2 vector of intrinsic oscillation freq.
% A: coupling amplitude
% phi0: initial phase difference
% Tend: simulation time
% m: vector specifying subplot to plot into
% --- OUTPUTS
% t: time vector
% phi1: phase diff. variable 
% phi: x-axis phase space 
% dphi: y-axis phase space

% set defaults
if nargin<3 || isempty(phi0), phi0=pi/2; end;
if nargin<4 || isempty(Tend), Tend=100; end;
if nargin<5 || isempty(m), m=[1 1]; end;

%% plot phase space
phi=0:0.01:2*pi;
subplot(m(1),2,(m(2)-1)*2+1), hold off cla
dphi=dphidt(0,phi,[w A]);
plot(phi,dphi,'b',phi,zeros(size(phi)),'k--','LineWidth',2); box off
set(gca,'FontSize',20), xlabel('$$\Phi$$','Interpreter','latex'); ylabel('$$d\Phi/dt$$','Interpreter','latex'); xlim([0 2*pi]);

%% numerically integrate ODE and plot
opt=odeset('RelTol',1e-5,'AbsTol',1e-8);
[t,phi1]=ode23(@dphidt,[0 Tend],phi0,opt,[w A]);
hold on, plot(phi1,dphidt(t,phi1,[w A]),'r','LineWidth',2);
subplot(m(1),2,(m(2)-1)*2+2), hold off cla
plot(t,phi1,'r','LineWidth',2); box off
set(gca,'FontSize',20), xlabel('Time'); ylabel('$$\Phi$$','Interpreter','latex'); xlim([0 Tend]);

%% ODE for phase difference:
function dphi=dphidt(t,phi,par)
dphi=par(1)-par(2)+2*par(3)*sin(phi);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
