function dV=dVdtNMDAburster(t,V,Par)
% implements ODE system for NMDA-driven single cell model eq. 9.62
% (from Durstewitz, 2009, Neural Networks)
I=Par(1);       % external current input
C=Par(2);       % mem. capacitance
gL=Par(3);      % leakage conductance
EL=Par(4);      % leak reversal potential
gNa=Par(5);     % max. Na+ conductance
ENa=Par(6);     % Na+ reversal potential
VhNa=Par(7);    % m-gate half-activation
kNa=Par(8);     % Na+ activation slope
gK=Par(9);      % max. K+ conductance
EK=Par(10);     % K+ reversal potential
VhK=Par(11);    % n-gate half-activation
kK=Par(12);     % K+ activation slope
tcK=Par(13);    % time constant K+ current
gM=Par(14);     % max. M-type K+ conductance
VhM=Par(15);    % h-gate half-activation
kM=Par(16);     % M current activation slope
tcM=Par(17);    % time constant M current
gNMDA=Par(18);  % max. NMDA conductance
Vsinf=Par(19);  % steady-state NMDA activation voltage for linear NMDA
Tmax=Par(20);   % simulation time
eps=Par(21:end);% noise vector

k=floor(t/(Tmax+1e-8)*length(eps))+1;

% implements eq. 9.62 ...
minf=1/(1+exp((VhNa-V(1))/kNa));
ninf=1/(1+exp((VhK-V(1))/kK));
hinf=1/(1+exp((VhM-V(1))/kM));
if Vsinf==0
    sinf=1/(1+0.33*exp(-0.0625*V(1)));
else
    sinf=1/(1+0.33*exp(-0.0625*Vsinf));
end;
dV(1)=(I-gL*(V(1)-EL)-gNa*minf*(V(1)-ENa)-gK*V(2)*(V(1)-EK) ...
    -gM*V(3)*(V(1)-EK)-gNMDA*sinf*V(1)+eps(k))/C;
dV(2)=(ninf-V(2))/tcK;
dV(3)=(hinf-V(3))/tcM;
dV=dV';


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
