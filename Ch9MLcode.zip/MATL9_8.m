clear all
close all

%% Fig. 9.10: Numerical integration of harmonic (linear) oscillator

x0=[1 1];  % initial state
b=-1;   % auto-coupling weight
[t1,x1,t2,x2,x3]=LinOsc2D(x0,b);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
