function [w0,W,S,b0,B1,m0,LL]=ParamEstimRNN(ct,It,ga,th,m,V,CV,B1ini)
% Parameter estimation given states for state space model
%     x(t) = A x(t-1) + W sigm(x(t-1)) + Inp(t) + eps(t), eps(t) ~ N(0,S)
%     x(1) ~ N(mu0,S)
%     c(t)|x(t) ~ Poisson[exp(log(b0)+B1 x(t))]
% based on Yu, B.M., Afshar, A., Santhanam, G., Ryu,S.I., Shenoy.K.V.: 
% Extracting Dynamical Structure Embedded in Neural Activity. 
% Advances in Neural Information Processing Systems 18, pp. 1545‐1552 (2005)
%
% INPUTS:
% ct: MxT observed count series
% It: MxT matrix of external inputs 
% ga: slopes of sigmoids
% th: thresholds of sigmoids
% m: posterior state estimates (arranged in cell array)
% V: posterior covariance estimates (arranged in cell array)
% CV: posterior covariance estimates for t,t+1 
% B1ini: initialization for NxM matrix of regression weights (estimated
% numerically)
%
% OUTPUTS:
% w0: Mx1 vector of auto-regressive weights 
% W: MxM matrix of coupling weights
% S: MxM diagonal covariance matrix (Gaussian process noise)
% b0: Poisson base rates
% B1: NxM matrix of regression weights
% m0: prior state mean
% LL: Expected (complete data) log-likelihood


T=length(m);
M=length(m{1});

%% numerically evaluate all integrals for expectancies E[phi(x)...]
gcf=parpool('local',2);
mphi=cell(size(m));
Vphi=cell(size(V));
Vxphi=cell(size(V));
Vxttphi=cell(size(V));
parfor t=2:T
    
    %% single integrals in phi(xt-1), phi(xt-1)^2, xt-1*phi(xt-1)
    mt=m{t-1};
    % L=V{t-1}^-1;
    mphi{t-1}=zeros(M,1);
    for i=1:M
        phi=@(x) 1./(1+exp(ga(i).*(th(i)-x)));
        phiinv=@(z) th(i)-log(1./z-1)./ga(i);   % inverse func. of phi
        dphiinv=@(z) 1./(ga(i).*(z-z.^2));  % derivative of inverse
        
        Vaa=V{t-1}(i,i);    % pick out relevant element from cov
        % --- SAME AS:
        % Lab=L(i,[1:i-1 i+1:end]);
        % Lbb=L([1:i-1 i+1:end],[1:i-1 i+1:end]);
        % Vaa=(L(i,i)-Lab*Lbb^-1*Lab')^-1; Vaa=(Vaa+Vaa')./2;
        
        Ef1=@(z) normpdf(phiinv(z),mt(i),sqrt(Vaa)).*abs(dphiinv(z)).*z;
        mphi{t-1}(i)=integral(Ef1,0,1);
        Ef1=@(z) normpdf(phiinv(z),mt(i),sqrt(Vaa)).*abs(dphiinv(z)).*z.^2;
        Vphi{t-1}(i,i)=integral(Ef1,0,1);
        Ef1=@(x) normpdf(x,mt(i),sqrt(Vaa)).*x.*phi(x);
        Vxphi{t-1}(i,i)=integral(Ef1,-inf,inf);
    end;
    
    %% double integrals in phi(xt-1)*phi(xt-1)'
    for i=1:M-1
        for j=i+1:M
            phiinv2=@(z1,z2) th([i j])-log(1./[z1 z2]'-1)./ga([i j]);
            dphiinv2=@(z1,z2) 1./(ga([i j]).*([z1 z2]'-[z1 z2]'.^2));
            
            Vaa=V{t-1}([i j],[i j]);    % pick out relevant elements from cov
            % --- SAME AS:
            % r=setdiff(1:M,[i j]);
            % Lab=L([i j],r); Lbb=L(r,r);
            % Vaa=(L([i j],[i j])-Lab*Lbb^-1*Lab')^-1; Vaa=(Vaa+Vaa')./2;
            
            Ef2=@(z1,z2) mvnpdf(phiinv2(z1,z2)',mt([i j])',Vaa).*abs(prod(dphiinv2(z1,z2))).*z1.*z2;
            Vphi{t-1}(i,j)=integral2(@(z1,z2)arrayfun(Ef2,z1,z2),0,1,0,1);
            Vphi{t-1}(j,i)=Vphi{t-1}(i,j);
        end;
    end;
    
    %% double integrals in xt-1*phi(xt-1)'
    for i=1:M
        for j=1:M
            if i~=j
                phi=@(x) 1./(1+exp(ga(j).*(th(j)-x)));
                
                Vaa=V{t-1}([i j],[i j]);    % pick out relevant elements from cov
                % --- SAME AS:
                % r=setdiff(1:M,[i j]);
                % Lab=L([i j],r); Lbb=L(r,r);
                % Vaa=(L([i j],[i j])-Lab*Lbb^-1*Lab')^-1; Vaa=(Vaa+Vaa')./2;
                
                Ef2=@(x1,x2) mvnpdf([x1 x2],mt([i j])',Vaa).*x1.*phi(x2);
                Vxphi{t-1}(i,j)=integral2(@(x1,x2)arrayfun(Ef2,x1,x2),-inf,inf,-inf,inf);
            end;
        end;
    end;
    
    %% double integrals in xt*phi(xt-1)
    mt=[m{t};m{t-1}];
    % L=[V{t} CV{t};CV{t}' V{t-1}]^-1;
    VV=[V{t} CV{t};CV{t}' V{t-1}];
    for i=1:M
        for j=M+1:2*M
            phi=@(x) 1./(1+exp(ga(j-M).*(th(j-M)-x)));
            
            Vaa=VV([i j],[i j]);    % pick out relevant elements from cov
            % --- SAME AS:
            % r=setdiff(1:2*M,[i j]);
            % Lab=L([i j],r); Lbb=L(r,r);
            % Vaa=(L([i j],[i j])-Lab*Lbb^-1*Lab')^-1; Vaa=(Vaa+Vaa')./2;
            
            Ef2=@(x1,x2) mvnpdf([x1 x2],mt([i j])',Vaa).*x1.*phi(x2);
            Vxttphi{t}(i,j-M)=integral2(@(x1,x2)arrayfun(Ef2,x1,x2),-inf,inf,-inf,inf);
        end;
    end;
    
end;
delete(gcf);


%% maximization of log-likelihood ---------------------------------

% Estimate B1 numerically after inserting expression for b0
% NOTES:
% - could be solved as N indep. problems cos of conditional independency 
% of outputs
% - ddL^-1*dL only works that way since ddL is block-diagonal and thus
% 'zeros out' wrong elements from dL; otherwise dL would have to be a
% matrix itself with each column containing all derivatives of each element
% of dLL/dB1ij w.r.t. all elements of B1!
errTol=1e-6;    % convergence criterion
MaxSteps=100;   % max. number numerical iterations
N=size(ct,1);
csum=sum(ct')';
K=zeros(N,M); for t=1:T, K=K+ct(:,t)*m{t}'; end;
B1=B1ini;   % initialize
B1old=1e8; k=0;
while sum(sum(abs(B1old-B1)))>errTol && k<MaxSteps
    
    H=cell(1,T); Hsum=zeros(N,M);
    A=cell(1,T); AHsum=zeros(N,M);
    for t=1:T
        H{t}=ones(N,1)*m{t}'+B1*V{t};
        Hsum=Hsum+H{t};
        A{t}=exp(B1*m{t}+1/2*diag(B1*V{t}*B1'));
        AHsum=AHsum+(A{t}*ones(1,M)).*H{t};
    end;
    Asum=sum(cell2mat(A)')';
    b0=csum./Asum;  % reinsert outcome to obtain b0
    dLdB=(K-(b0*ones(1,M)).*AHsum)';
    dL=dLdB(1:end)';
    
    ddL=[];
    for i=1:N
        Y1=zeros(M);
        for t=1:T, Y1=Y1+(V{t}'+H{t}(i,:)'*H{t}(i,:))*A{t}(i); end;
        Y2=(AHsum(i,:)'*AHsum(i,:))./Asum(i);
        ddL=blkdiag(ddL,-b0(i)*(Y1-Y2));
    end;
    
    B1old=B1;
    B1T=B1';
    bb1=B1T(1:end)'-ddL^-1*dL;  % Newton-Raphson step
    B1=reshape(bb1,M,N)';
    k=k+1;
    
end;

%% mu0 is simply first E[x1]-Inp1
m0=m{1}-It(:,1);

%% compute all time-accumulated expectancy matrices (see eq. 9.51)
E1=zeros(M); E2=E1; E3=E1; E4=E1; E5=E1; E6=E1; A1=E1; A2=E1; A3=E1; Itsum=E1;
for t=1:T-1
    E1=E1+Vphi{t};
    E2=E2+Vxttphi{t+1}';
    E3=E3+Vxphi{t};
    E4=E4+(V{t}+m{t}*m{t}');
    E5=E5+(CV{t+1}+m{t+1}*m{t}');
    E6=E6+(V{t+1}+m{t+1}*m{t+1}');
    A1=A1+It(:,t+1)*mphi{t}';
    A2=A2+It(:,t+1)*m{t}';
    A3=A3+m{t+1}*It(:,t+1)';
    Itsum=Itsum+It(:,t+1)*It(:,t+1)';
end;

%% compute auto-regressive weights w0
w0=diag((E5-E2'*E1^-1*E3'+A1*E1^-1*E3'-A2)).*diag(E4-E3*E1^-1*E3').^-1;
w0=min(max(w0,0),0.999); % impose constraints on AR time constant

%% compute coupling weight matrix W
W=(E2'-diag(w0)*E3-A1)*E1^-1;

%% compute noise covariance matrix
Z0=V{1}+E6'-A3-A3'+Itsum;
Z1=A2-E5;
Z2=A1-E2';
S=diag(diag(Z0+Z1*diag(w0)+diag(w0)*Z1'+diag(w0)*E4'*diag(w0)+ ...
    diag(w0)*E3*W'+W*E3'*diag(w0)+Z2*W'+W*Z2'+W*E1'*W'))./T;
S=diag(max(diag(S),1e-4));  % ensure that var>=1e-4


%% expected log-likelihood
if nargout>6
    Q1=0; Q2=Q1; Q3=Q1; Q4=Q1;
    for t=2:T
        Q1=Q1+m{t}'*S^-1*It(:,t);
        Q2=Q2+m{t-1}'*diag(w0)*S^-1*It(:,t);
        Q3=Q3+mphi{t-1}'*W'*S^-1*It(:,t);
        Q4=Q4+It(:,t)'*S^-1*It(:,t);
    end;
    LLobs=sum(csum.*log(b0)-b0.*Asum)+trace(K*B1');
    LLlatent=T/2*log(det(S))+1/2*(trace(S^-1*(E6-diag(w0)*E5'-W*E2))- ...
        trace(diag(w0)*S^-1*(E5-diag(w0)*E4-W*E3'))-trace(W'*S^-1*(E2'-diag(w0)*E3-W*E1))- ...
        Q1-Q1'+Q2+Q2'+Q3+Q3'+Q4);
    LL=LLobs-LLlatent;
end;


%% this implementation:
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
