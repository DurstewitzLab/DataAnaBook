%% Training Recurrent Neural Network (RNN) model through Real-Time Recurrent Learning (RTRL) 
% --> similar to MATL9_6, but runs slightly different RNN model of the type
%     x(t) = A x(t-1) + W sigm(x(t-1)) + Inp(t) + eps(t), eps(t)~N(0,S)
% including Gaussian white noise eps(t) in the latent state process
% --> designed for creating specific 'ground truth' latent state path
% for estimation through extended Kalman filter-smoother
% (see MATL9_6 or MATL9_7 for more details on different steps in this routine)

clear all;

rand('state',5);
randn('state',5);


%% General parameters
N=3;            % number units
beta=randn(N,1)+3;        % slopes of sigmoids
thresh=0.1*randn(N,1);     % thresholds of sigmoids
alpha=0.001;      % learning parameter
TF=1;           % Teacher-forcing
lam=0;          % constraint weighting
cons=0;         % constraints on auto-reg. terms
Ntrials=2000;   % number trials
par={beta,thresh,alpha,TF,lam,cons,0};

sigm=@(x,b,th) 1./(1+exp(b.*(th-x)));


%% Task specification
TrialLength=10;

InpVal=zeros(N,TrialLength);
InpVal(1,1)=1;
InpVal(2,4)=1;
InpVal(3,8)=1;

OutpVal=zeros(N,TrialLength)+nan; % nan = no specific output required
OutpVal(1,:)=[0 0.2 0.4 0.6 0.8 0.8 0.6 0.4 0.2 0];
OutpVal(2,:)=[0.4 0.2 0 0 0.2 0.4 0.6 0.8 0.8 0.6]; 
OutpVal(3,:)=[0.8 0.6 0.4 0.2 0 0 0.2 0.4 0.6 0.8]; 

% figure(1), hold off cla
% subplot(2,2,1), imagesc(InpVal)
% set(gca,'FontSize',20)
% title('Inputs'); xlabel('time step'); ylabel('unit #');
% subplot(2,2,2), plot(OutpVal','o-','LineWidth',2)
% set(gca,'FontSize',20)
% title('Desired Output'); xlabel('time step'); ylabel('x_5');
% axis([0 11 0 1]); box off

%% initialization
dXdw=zeros(N,N^2);
dXda=zeros(N,N);
W=rand(N,N)-0.5; W=W-diag(diag(W));
a=zeros(N,1);
X=zeros(N,1);
Gx=sigm(X,beta,thresh);
dGxdx=Gx.^2.*exp(par{1}.*(par{2}-X)).*par{1};

%% Training phase
for i=1:Ntrials
    ErrSum(i)=0;
    for j=1:TrialLength
        InpV=InpVal(:,j);
        OutV=OutpVal(:,j);
        [X,Gx,dGxdx,W,dXdw,a,dXda,Err]=TrainRNN(X,Gx,dGxdx,W,dXdw,a,dXda,InpV,OutV,par);
        ErrSum(i)=ErrSum(i)+Err;
    end;
    ErrSum(i)=ErrSum(i)/TrialLength;
end;

% subplot(2,2,3), hold off, plot(ErrSum,'LineWidth',2); box off
% set(gca,'FontSize',20); xlabel('Training run'); ylabel('Error');


%% Recall phase
par([3 4])={0,0};       % set learning param. & TF to 0
OutV=zeros(N,1)+nan;   % no teacher-outputs
par{7}=[0.02 0.02 0.02]';  % add Gaussian white noise
Ntrials=200;
for i=1:Ntrials
	for j=1:TrialLength
        InpV=InpVal(:,j);
        [X,Gx,dGxdx,W,dXdw,a,dXda,Err]=TrainRNN(X,Gx,dGxdx,W,dXdw,a,dXda,InpV,OutV,par);
        GxOut(:,j+(i-1)*TrialLength)=Gx;
        Xout(:,j+(i-1)*TrialLength)=X;
	end;
end;

% subplot(2,2,4), hold off, plot(GxOut','o-','LineWidth',2); box off
% set(gca,'FontSize',20)
% title('Actual Output'); xlabel('time step'); ylabel('x_5');
% xlim([1900 2000])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
