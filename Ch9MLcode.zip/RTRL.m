function [Vout,Wout,dVdwOut,ErrSum]=RTRL(Vin,Win,dVdwIn,InpL,InpV,OutL,OutV,par)
% Real-Time Recurrent Learning for RNN with sigmoid I/O functions:
% V(t) = sigm(W V(t-1)), sigm(Z)=[1+exp(-b(Z-th))]^-1
%
% (implemented acc. to Hertz, Krogh, Palmer, 1991, Introduction to the
% theory of neural computation. Addison-Wesley.)
%
% --- INPUTS
% Vin: Nx1 vector of current activation states
% Win: NxN matrix of current connection weights
% dVdwIn: NxN^2 matrix of current gradients (derivatives of states w.r.t.
% weights)
% InpL: list of all units receiving external inputs
% InpV: corresponding vector of input values
% OutL: list of all units with requested (teacher) outputs
% OutV: corresponding vector of target outputs
% par: vector of control parameters = [slope of sigm., threshold, learning
% rate, teacher forcing flag]
% --- OUTPUTS
% Vout: Nx1 vector of updated activation states
% Wout: updated NxN weight matrix
% dVdwOut: NxN^2 matrix of updated gradients
% ErrSum: total squared error across units with defined targets

N=length(Vin);
ExtInp=zeros(N,1);
ExtInp(InpL)=InpV;

%% update activations
NetInp=Win*Vin+ExtInp;
x=exp(-par(1)*(NetInp-par(2)));
Vout=1./(1+x);

%% compute total error
Err=zeros(N,1);
Err(OutL)=OutV-Vout(OutL);
ErrSum=Err'*Err/2;

%% update gradients & weight matrix
dSdNetInp=Vout.^2.*(par(1)*x);  % derivatives sigmoid w.r.t. net input
VinMtx=Vin';
for i=1:N-1  % rearrange matrix
    VinMtx=blkdiag(VinMtx,Vin');
end;
dVdwOut=(dSdNetInp*ones(1,N^2)).*(Win*dVdwIn+VinMtx);   % new gradients
dW=reshape(par(3)*Err'*dVdwOut,N,N)';
Wout=Win+dW;    % new weights

% if teacher forcing, reset output values & gradients
if par(4)==1
    Vout(OutL)=OutV;
    dVdwOut(OutL,:)=0;
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
