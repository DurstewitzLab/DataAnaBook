clear all
close all

%% Fig. 9.4: Oscillations & chaos in logistic map

% 4-cycle
alp=3.5; x=logf(alp,0.5,[3 1]); subplot(3,2,1), axis([170 200 0.4 0.9])
text(190,1,['$$ \bf{Period-4-cycle} \ (\alpha = ' num2str(alp) ')$$'],'Interpreter','latex','Fontsize',24);

% chaos
alp=3.9; x=logf(alp,0.6,[3 3]); subplot(3,2,3), xlim([100 200])
text(185,1.2,['$$ \bf{Chaos} \ (\alpha = ' num2str(alp) ')$$'],'Interpreter','latex','Fontsize',24);

% time graph from 2 nearby initial conditions
subplot(3,2,[5 6]), hold off cla
plot(x,'LineWidth',2,'Color','b'); hold on
x=logf(3.9,0.6001,[],false);    % add 1e-4 to previous initial value
plot(x,'LineWidth',2,'Color','c');
axis([0 100 0 1]); set(gca,'FontSize',20), box off
title('Divergence of trajectories');
xlabel('t'); ylabel('x_t');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University