clear all
close all

%% Fig. 9.13: Wilson-Cowan-type ODE neural model
% - consists of a 'population' of excitatory (E) and one of inhibitory (I)
% units
% - illustrates oscillations (via Hopf bifurcation)

%% parameters specifying system
slopeE=4;   % slope of sigmoid of E-unit
halfE=0.4;  % half activation threshold of E sigmoid
wei=0.5;    % I-->E connection weight
IextE=0;    % external input to E-unit
IextI=0;    % external input to I-unit
halfI=0.35; % half activation threshold of I sigmoid
tauE=30;    % time constant of E unit
tauI=180;   % time constant of I unit
slopeI=4.5; % slope of sigmoid of I-unit
wee=1.2;    % E-->E connection weight
wieL=[0.4 0.45 0.55 0.6];    % list of E-->I connection weights
Tend=5000;  % simulation time

%% simulate E-I model & plot results
figure(17), hold off cla
for i=1:length(wieL)
    par=[wee wei IextE slopeE halfE tauE wieL(i) IextI slopeI halfI tauI];
    ncEImodel([4 i],par,Tend);  % call simulator
    subplot(4,3,3*(i-1)+1);
    text(1700,40,['$$w_{EI} = ' num2str(wieL(i)) '$$'],'Interpreter','latex','FontSize',18);
end;
subplot(4,3,1), title('Time graph');
subplot(4,3,2), title('State space');
subplot(4,3,3), title('Eigenvalues');
subplot(4,3,10), xlabel('Time (ms)');
subplot(4,3,11), xlabel('\itR\rm_e_x_c (Hz)');
subplot(4,3,12), xlabel('\it{i}');
for i=1:9, gca=subplot(4,3,i); set(gca,'XTickLabel',''); end;
for i=3:3:12, subplot(4,3,i), axis([0 3 -0.01 0.01]); end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
