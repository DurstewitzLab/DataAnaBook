function [t1,x1,t2,x2,x3]=LinOsc2D(x0,b)
% simulates and solves analytically 2D linear ODE system; produces linear
% oscillator for b=-1
% --- INPUTS
% x0: 1x2 initial state vector
% b: auto-coupling weight of first process
% --- OUTPUTS
% t1: time vector for exact solution
% x1: exact solution
% t2: time vector for ODE solver soln.
% x2: implicit ODE solver soln.
% x3: forward-Euler solution

%% parameter (coupling) matrix defining linear ODE
A=[b 2;
   -2 1];

%% compute exact solution
[v,lam]=eig(A);
disp('eigenvalues'); disp(diag(lam));
disp('eigenvectors'); disp(v);
c=(v^-1)*x0';
t1=0:0.01:100;
x1=c(1)*v(:,1)*exp(lam(1,1)*t1)+c(2)*v(:,2)*exp(lam(2,2)*t1);

%% compute implicit ML-ode-solver solution
opt=odeset('RelTol',1e-5,'AbsTol',1e-8);
[t2,x2]=ode23s(@LinOsc,[0 t1(end)],x0,opt,A);

%% compute simple fw-Euler solution
x3(:,1)=x0';
for i=1:length(t1)-1
    dt=t1(i+1)-t1(i);
    x3(:,i+1)=x3(:,i)+dt*LinOsc(t1(i),x3(:,i),A);
end;

%% show results
plot(t1,x3(1,:),'r',t1,x1(1,:),'b',t2,x2(:,1),'g','LineWidth',2)
legend('fw-Euler','exact','Rosenbrock-2','Location','NorthWest'); legend('boxoff');
set(gca,'FontSize',20), box off
xlabel('Time'); ylabel('x_1');

%% ODE system
function dx=LinOsc(t,x,A)
dx=A*x;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
