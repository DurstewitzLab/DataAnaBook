clear all
close all

%% Fig. 9.3: Oscillations in logistic map as fixed points of F(F(x))

p=3.3;
xn=0:0.01:1;
Fxn=p.*xn.*(1-xn);  % logistic map
Fxn2=p.*Fxn.*(1-Fxn);   % 2-times iterated map (= 4th-order polynomial)

%% plot map with trajectory (2-cycle)
subplot(1,2,1), hold off
plot(xn,Fxn,'b',xn,xn,'g','LineWidth',2); hold on;
x=logf(p,0.5,[],false); x=x(100:end);
i=1:(length(x)-1); i=ones(2,1)*i; j(1:2*(length(x)-1))=i;
k(1:(2*(length(x)-1)-1))=j(2:end); k(2*(length(x)-1))=j(end)+1;
plot(x(j),x(k),'r','LineWidth',2);
set(gca,'FontSize',20), box off; title('1st-order return map');
xlabel('x_t'); ylabel('F(x_t)');

%% plot 2-times iterated map with fixed points corresponding to 2-cycle
subplot(1,2,2), hold off
plot(xn,Fxn2,'b',xn,xn,'g','LineWidth',2); hold on
plot(x(end),x(end),'r.',x(end-1),x(end-1),'r.','LineWidth',2,'MarkerSize',20);
set(gca,'FontSize',20), box off; title('2nd-order return map');
xlabel('x_t'); ylabel('F(F(x_t))');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University