%% Training Recurrent Neural Network (RNN) model through Real-Time Recurrent Learning (RTRL) 
% - wrapper file for defining task setup, and training & running RNN
% - creates Fig. 9.8, working memory task

clear all;
rand('state',5);

%% General (control) parameters
N=10;            % number units
beta=10;        % slope of sigmoid
thresh=0.5;     % threshold of sigmoid
alpha=0.0005;      % learning parameter
TF=1;           % Teacher-forcing
Ntrials=20000;   % number trials


%% Task specification
TrialLength=10;

% trial type 1
InpVal{1}=zeros(N,TrialLength);
InpVal{1}(1,3)=1;   % inputs
OutpVal{1}=zeros(N,TrialLength)+nan; % nan = no specific output required
OutpVal{1}(2,6)=1; OutpVal{1}(4,6)=0;   % requested outputs

% trial type 2
InpVal{2}=zeros(N,TrialLength);
InpVal{2}(3,3)=1;   % inputs
OutpVal{2}=zeros(N,TrialLength)+nan; % nan = no specific output required
OutpVal{2}(4,6)=1; OutpVal{2}(2,6)=0;   % requested outputs

% randomization of trial presentation
trialTyp=ones(1,Ntrials);
k=randsample(Ntrials,round(Ntrials/2));
trialTyp(k)=2;

% plot task setup
figure(1), hold off cla
subplot(2,2,1)
X=[3*InpVal{1} zeros(N,1)+64 3*InpVal{2}];
Y=[OutpVal{1} zeros(N,1)+64 OutpVal{2}];
k=find(Y==0); X(k)=64; k=find(Y==1); X(k)=57;
k=find(X==0); X(k)=61;
image(X), colormap('colorcube');
str=cell(1,21); for i=1:10, str{i}=num2str(i); end;
str{11}=''; str(12:21)=str(1:10);
set(gca,'XTick',1:21,'XTickLabel',str)
set(gca,'FontSize',20);
title('Trial type #1         Trial type #2');
xlabel('time step               time step'); ylabel('unit #');
text(1.5,5.5,'\color{green}Input','FontSize',20);
text(4.8,5.5,'\color{black}Outputs','FontSize',20);
text(12.5,5.5,'\color{green}Input','FontSize',20);
text(15.8,5.5,'\color{black}Outputs','FontSize',20);

%% initialization
par=[beta thresh alpha TF];
dVdw=zeros(N,N^2);
V=zeros(N,1);
W=rand(N,N)-0.5;

%% Training phase
for i=1:Ntrials   % loop through trials
    ErrSum(i)=0;
    tr=trialTyp(i);
    for j=1:TrialLength   % loop through time points, updating weights online
        InpL=find(InpVal{tr}(:,j)~=0);
        InpV=InpVal{tr}(InpL,j);
        OutL=find(~isnan(OutpVal{tr}(:,j)));
        OutV=OutpVal{tr}(OutL,j);
        [V,W,dVdw,Err]=RTRL(V,W,dVdw,InpL,InpV,OutL,OutV,par);
        ErrSum(i)=ErrSum(i)+Err;
    end;
    ErrSum(i)=ErrSum(i)/TrialLength;
    disp(i)
end;

% plot training error as function of trials
subplot(2,2,2), hold off, plot(ErrSum); box off
set(gca,'FontSize',20); xlabel('Training run'); ylabel('Error');
axis([0 15000 0 0.06]);
title('Total error')

%% Recall phase (disable learning)
par([3 4])=0;       % set learning param. & TF to 0
OutL=[]; OutV=[];   % no teacher-outputs
for tr=1:2
	for j=1:TrialLength
        InpL=find(InpVal{tr}(:,j)~=0);
        InpV=InpVal{tr}(InpL,j);
        [V,W,dVdw,Err]=RTRL(V,W,dVdw,InpL,InpV,OutL,OutV,par);
        Vout{tr}(:,j)=V;
	end;
end;

% plot performance of trained RNN during recall
subplot(2,2,3), hold off
plot(1:TrialLength,Vout{1}(2,:),'bo-',1:TrialLength,Vout{1}(4,:),'ro-','LineWidth',2,'MarkerSize',10);
set(gca,'FontSize',20); box off; title('Input unit #1');
xlabel('time step'); ylabel('activation'); legend('x_2','x_4','Location','SouthEast'); legend('boxoff');
axis([0 TrialLength+1 0 1.1])
title('Trial type #1')

subplot(2,2,4), hold off
plot(1:TrialLength,Vout{2}(2,:),'bo-',1:TrialLength,Vout{2}(4,:),'ro-','LineWidth',2,'MarkerSize',10);
set(gca,'FontSize',20); box off; title('Input unit #3');
xlabel('time step'); ylabel('activation'); legend('x_2','x_4','Location','SouthEast'); legend('boxoff');
title('Trial type #2')
axis([0 TrialLength+1 0 1.1])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
