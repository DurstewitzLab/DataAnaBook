clear all
close all

%% Fig. 9.16: Single cell 3-ODE system with NMDA-type synaptic input
% - simulation of single neuron model, defined by 3 ODEs for membrane
% voltage and fast and slow inhibitory K+ type currents (eq. 9.32)

% Simulate cell model in bursting, chaotic, and regular spiking regime
figure(3)
FS=18; FSsm=16; FSbig=24;   % just font sizes for figs.
tstop=8e3;  % simulation time
load NMDAcell_param.mat   % parameter file for cell model
gNMDA=[10.2 11.4 12.7]; % range of NMDA conductance inputs to simulate
for i=1:length(gNMDA)
    ParNL(18)=gNMDA(i);
    res{i}=NMDAburster(ParNL,tstop,[],[],[]); % call cell simulator
    save NMDAtraces res;
    disp(i)
end;

% plot time graphs from these 3 regimes
load NMDAtraces
for i=1:length(gNMDA)
    subplot(4,2,(i-1)*2+(1:2)), plot(res{i}.t-3600,res{i}.v(:,1),'k','LineWidth',2);
    axis([0 500 -70 0]), box off
    title(['g_N_M_D_A = ' num2str(gNMDA(i)) ' mS'],'FontSize',FSsm);
    ylabel('V_m (mV)','FontSize',FSsm);
    set(gca,'FontSize',FSsm);
end;
xlabel('Time (ms)','FontSize',FSsm); 


%% create bifurcation graphs from simulations across large gNMDA range
load NMDAbifurc
MS=7;

% create bif. graph from ISIs
for i=1:length(ISIlin) 
    if (~isempty(ISInonlin{i})) 
        subplot(4,2,7), hold on
        if (gNMDA(i)>=9.9 & gNMDA(i)<=10.1) | (gNMDA(i)>=11.2 & gNMDA(i)<=11.5)
            plot(gNMDA(i),ISInonlin{i},'k.','MarkerSize',MS); 
        else
            plot(gNMDA(i),ISInonlin{i}(end-8:end),'k.','MarkerSize',MS); 
        end;
        axis([8 15 0 40])
    end;
end;
subplot(4,2,7), ylabel('ISI (ms)','FontSize',FSsm); title('Nonlinear NMDA','FontSize',FSsm);
xlabel('g_N_M_D_A (mS)','FontSize',FSsm);

% homoclinic orbit bifurcation
resF={'resNonLin'};
x=eval(resF{1});
subplot(4,2,8), hold off
n=find(x.t>3/4*tstop);
k=find(x.Stab==0);
kd=[0 find(diff(k)>1) length(k)];
for j=1:length(kd)-1
    rg=k(kd(j)+1:kd(j+1));
    plot(x.hfix(rg),x.v1(rg),'k','LineWidth',2);    % plot stable FP
    hold on;
end;
k=find(x.Stab>0);
plot(x.hfix(k),x.v1(k),'k--','LineWidth',2);    % plot unstable FP
% plot upper and lower branch of LC:
k=find(x.LCmax-x.LCmin>1e-2);
plot(x.hVec(k),x.LCmin(k),x.hVec(k),x.LCmax(k),'Color',[0.7 0.7 0.7],'LineWidth',2);

box off, axis([0 0.15 -100 0])    
ylabel('V_m^* (mV)','FontSize',FSsm); title('Nonlinear NMDA','FontSize',FSsm);
xlabel('h','FontSize',FSsm);
subplot(4,2,[1 2])
text(-50,15,'A','FontSize',FSbig);
text(-50,-290,'B','FontSize',FSbig);
text(240,-290,'C','FontSize',FSbig);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
