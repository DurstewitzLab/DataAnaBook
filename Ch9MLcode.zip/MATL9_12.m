clear all
close all

%% Fig. 9.15: Fitting curve to return plot from Poincare section of stable
% limit cycle of E-I system (eq. 9.28)

slopeE=4;   % slope of sigmoid of E-unit
halfE=0.4;  % half activation threshold of E sigmoid
wei=0.5;    % I-->E connection weight
IextE=0;    % external input to E-unit
IextI=0;    % external input to I-unit
halfI=0.35; % half activation threshold of I sigmoid
tauE=30;    % time constant of E unit
tauI=180;   % time constant of I unit
slopeI=4.5; % slope of sigmoid of I-unit
wee=1.2;    % E-->E connection weight
wie=0.5;    % E-->I connection weight
Tend=10000;  % simulation time
par=[wee wei IextE slopeE halfE tauE wie IextI slopeI halfI tauI];

% list of different initial conditions for simulating different approaches
% to limit cycle
RiniLE=sort([5:5:40 18:24],'ascend');
RiniLI=sort([5:5:40 14.5:0.5:18.5],'ascend');
Z=cell(length(RiniLE),length(RiniLI));

figure(19), hold off cla
for i=1:length(RiniLE)
    for j=1:length(RiniLI)
        Rini=[RiniLE(i) RiniLI(j)];
        [~,~,~,~,~,~,Rall]=ncEImodel([1 3],par,Tend,false,false,Rini);  % simulate system
        
        % pick out local peaks of E-trajectory
        X=Rall(3:end-2,1);
        k=find(X>Rall(2:end-3,1) & X>Rall(1:end-4,1) & X>Rall(4:end-1,1) & X>Rall(5:end,1));
        Z{i,j}=X(k);
        
        % scale & plot
        plot(40*Z{i,j}(1:end-1),40*Z{i,j}(2:end),'k.','LineWidth',2,'MarkerSize',8); hold on
    end;
end;
axis([22 30 22 30])
plot(22:30,22:30,'b','LineWidth',2)
set(gca,'FontSize',20), xlabel('x_t'); ylabel('x_t_+_1');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
