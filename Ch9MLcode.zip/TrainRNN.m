function [Xnew,GxNew,dGxdxNew,Wnew,dXdwNew,anew,dXdaNew,ErrSum]=TrainRNN(Xold,GxOld,dGxdxOld,Wold,dXdwOld,aold,dXdaOld,InpV,OutV,par)
% Real-Time Recurrent Learning for RNN with sigmoid I/O functions
% --> similar to RTRL.m, but implements RNN models of the type
%     x(t) = A x(t-1) + W sigm(x(t-1)) + Inp(t) + eps(t), eps(t)~N(0,S)
%
% as in Yu et al. 2005, NIPS
%
% --- INPUTS
% Xold: Nx1 vector of current latent states
% GxOld: Nx1 vector of activations (x passed through sigmoid-nonlin.)
% dGxdxOld: current gradients of sigm(x) w.r.t. x
% Wold: NxN matrix of current connection weights
% dXdwOld: current gradients of x w.r.t. weights w
% aold: auto-regressive weights (diagonal of 'A' above)
% dXdaOld: current gradients of x w.r.t. auto-regr. weights a
% InpV: vector of external inputs
% OutV: vector of target (teacher) outputs
% par: vector of control parameters = [slope of sigm., threshold, learning
% rate, teacher forcing flag, regularization param. for a, bias term for a,
% diag. of noise-covariance]
% --- OUTPUTS
% Xnew: Nx1 vector of updated latent states
% GxNew: Nx1 vector of updated activations
% dGxdxNew: updated gradients of sigm(x) w.r.t. x
% Wnew: NxN matrix of updated connection weights
% dXdwNew: updated gradients of x w.r.t. weights w
% anew: updated auto-regressive weights (diagonal of 'A' above)
% dXdaNew: updated gradients of x w.r.t. auto-regr. weights a
% ErrSum: total squared error across units with defined targets


N=length(Xold);

%% create Gaussian white process noise
eps=zeros(N,1);
if sum(par{7})>0, eps=mvnrnd(zeros(1,N),diag(par{7}))'; end;

%% update states & activations
Xnew=aold.*Xold+Wold*GxOld+InpV+eps;
u=exp(par{1}.*(par{2}-Xnew));
GxNew=1./(1+u);

%% compute total error
ko=~isnan(OutV);
Err=GxNew(ko)-OutV(ko);
ErrSum=(Err'*Err)/2;

%% update all gradients
dGxdxNew=GxNew.^2.*u.*par{1};
Z=dGxdxNew(ko).*Err;
GinMtx=GxOld';
for i=1:N-1, GinMtx=blkdiag(GinMtx,GxOld'); end;
M=Wold.*(ones(N,1)*dGxdxOld');
dXdwNew=(aold*ones(1,N^2)).*dXdwOld+M*dXdwOld+GinMtx;
XinMtx=diag(Xold);
dXdaNew=(aold*ones(1,N)).*dXdaOld+M*dXdaOld+XinMtx;

%% compute new auto-regr. weights a and connection weights W
if ~isempty(Z)
    dW=reshape(Z'*dXdwNew(ko,:),N,N)';
    dW=dW-diag(diag(dW));
    Wnew=Wold-par{3}*dW;
    da=(Z'*dXdaNew(ko,:))'+par{5}*(aold-par{6});
    anew=aold-par{3}*da;
else
    Wnew=Wold;
    da=par{5}*(aold-par{6});
    anew=aold-par{3}*da;
end;    

%% teacher forcing if present
if par{4}==1
    Xnew(ko)=OutV(ko);
    dXdwNew(ko,:)=0;
    dXdaNew(ko,:)=0;
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
