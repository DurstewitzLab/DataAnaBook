clear all
close all

%% Fig. 9.14: Bifurcation graphs for saddle node and supra-critical Hopf bif. in E-I-system

% parameters
slopeE=4;   % slope of sigmoid of E-unit
halfE=0.4;  % half activation threshold of E sigmoid
wei=0.5;    % I-->E connection weight
IextE=0;    % external input to E-unit
IextI=0;    % external input to I-unit
halfI=0.35; % half activation threshold of I sigmoid
tauE=30;    % time constant of E unit


%% saddle node bifurcation
tauI=5;   % time constant of I unit
slopeI=1; % slope of sigmoid of I-unit
wie=0.5;  % E-->I connection weight
weeL=1.1:0.01:1.5;  % list of E-->E connection weights (control param.)
figure(18), hold off cla
subplot(1,2,1), hold off cla
RfixE=zeros(3,length(weeL));
for i=1:length(weeL)
    par=[weeL(i) wei IextE slopeE halfE tauE wie IextI slopeI halfI tauI];
    [Re_nc,Ri_nc,Rfix]=ncEImodel([4 i],par,[],[],false);
    Rf=cell2mat(Rfix); RfixE(:,i)=Rf(1:2:5)';
end;
plot(weeL(1:30),RfixE(3,1:30),'k',weeL(14:end),RfixE(1,14:end),'k',weeL(14:30),RfixE(2,14:30),'k--','LineWidth',2);
axis([1.1 1.5 0 40]); box off; set(gca,'FontSize',20)
title('Saddle node bifurc.'), xlabel('w_E_E'); ylabel('R_e_x_c^*');

%% Hopf bifurcation
tauI=180;   % time constant of I unit
slopeI=4.5; % slope of sigmoid of I-unit
wee=1.2;    % E-->E connection weight
wieL=0.4:0.005:0.6;    % list of E-->I connection weights (control param.)
Tend=10000;  % simulation time
subplot(1,2,2), hold off cla
RfixE=zeros(3,length(wieL)); Rosc=zeros(2,length(wieL));
for i=1:length(wieL)
    par=[wee wei IextE slopeE halfE tauE wieL(i) IextI slopeI halfI tauI];
    [~,~,Rfix,~,~,T0,R0]=ncEImodel([4 i],par,Tend,[],false);
    Rf=cell2mat(Rfix); RfixE(:,i)=Rf(1:2:5)';
    k=find(T0>Tend-2000); Rosc(:,i)=[min(R0(k,1)) max(R0(k,1))]';
end;
plot(wieL,40*Rosc(1,:),wieL,40*Rosc(2,:),'Color',[0.7 0.7 0.7],'LineWidth',2);
k=find(wieL>=0.48 & wieL<0.59); k0=find(wieL<0.48); k1=find(wieL>=0.59);
hold on, plot(wieL(k0),RfixE(2,k0),'k',wieL(k1),RfixE(2,k1),'k',wieL(k),RfixE(2,k),'k--','LineWidth',2);
axis([min(wieL) max(wieL) 5 40]); box off; set(gca,'FontSize',20)
title('Supercrit. Hopf bifurc.'), xlabel('w_E_I'); ylabel('R_e_x_c^*');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
