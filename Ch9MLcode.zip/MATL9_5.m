clear all
close all

%% Fig. 9.5: Bifurcation graph of logistic map

figure(10), hold off cla
p=0:0.02:4; % parameter range to scan
for i=1:length(p)
    x=logf(p(i),0.5,[],false);
    xp=unique(x(100:end));  % determine steady states
    plot(p(i),xp,'k.','LineWidth',2); hold on
end;
set(gca,'FontSize',20), box off; title('Bifuraction Graph');
xlabel('\alpha'); ylabel('x^*'); axis([min(p) max(p) 0 1]);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University