function a=logf(p,a0,v,show)
% logistic map
% --- INPUTS
% p: slope parameter
% a0: initial value
% v: vector specifying subplot to plot into
% show: flag indicating whether to show results (or just return time
% series)
% --- OUTPUTS
% a: time series of map

% set defaults
if nargin<2, a0=0.5; end;
if nargin<3, v=[1 1]; end;
if nargin<4, show=true; end;

%% implementation of the map a(n+1)=p*a(n)*(1-a(n)):
a(1)=a0;
for n=2:200
    a(n)=p*a(n-1)*(1-a(n-1));   % iterate logistic map
end;

%% plot results
if show
    % plot successive values of a(n):
    subplot(v(1),2,v(2)), hold off, plot(a,'LineWidth',2,'Color','b');
    axis([0 n 0 1]); set(gca,'FontSize',20), box off
    %title(['\alpha = ' num2str(p)]);
    xlabel('t'); ylabel('x_t');

    % plot a(n+1) as function of a(n):
    a1=0:0.05:1;
    subplot(v(1),2,v(2)+1), hold off, plot(a1,p*a1.*(1-a1),'b',a1,a1,'g','LineWidth',2);
    hold on;
    i=1:(length(a)-1); i=ones(2,1)*i;
    j(1:2*(length(a)-1))=i;
    k(1:(2*(length(a)-1)-1))=j(2:end);
    k(2*(length(a)-1))=j(end)+1;
    plot(a(j),a(k),'r','LineWidth',2);
    set(gca,'FontSize',20), box off
    %title(['\alpha = ' num2str(p)]);
    xlabel('x_t'); ylabel('x_t_+_1');
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
