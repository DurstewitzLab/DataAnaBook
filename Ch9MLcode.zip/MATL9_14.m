clear all
close all

%% Fig. 9.15: Phase space of coupled oscillators for different levels of freq. detuning

A=2;    % coupling strength

%% no freq. detuning
w=[3 3];    % intrinsic frequencies of oscillators
[t,phi1,phi,dphi]=PhaseCoupledOsc(w,A,[],[],[3 1]);
subplot(3,2,1), ylim([-10 5]);
title('State space');
text(1.5,-8,['$$\omega_1 = ' num2str(round(100*w(1))/100) ', \ \omega_2 = ' num2str(round(100*w(2))/100) '$$'],'Interpreter','latex','FontSize',22);
subplot(3,2,2), axis([0 10 1.2 3.5]);
title('Time graph');

%% weak detuning
w=[3 5];    % intrinsic freq. of oscillators
[t,phi1,phi,dphi]=PhaseCoupledOsc(w,A,[],[],[3 2]);
subplot(3,2,3), ylim([-10 5]);
text(1.5,-8,['$$\omega_1 = ' num2str(round(100*w(1))/100) ', \ \omega_2 = ' num2str(round(100*w(2))/100) '$$'],'Interpreter','latex','FontSize',22);
subplot(3,2,4), axis([0 10 1.2 3.5]);

%% strong detuning
w=[3 7.2];  % intrinsic freq. of oscillators
[t,phi1,phi,dphi]=PhaseCoupledOsc(w,A,2*pi,[],[3 3]);
subplot(3,2,5), ylim([-10 5]);
text(1.5,3,['$$\omega_1 = ' num2str(round(100*w(1))/100) ', \ \omega_2 = ' num2str(round(100*w(2))/100) '$$'],'Interpreter','latex','FontSize',22);
subplot(3,2,6), axis([0 50 -70 20]);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
