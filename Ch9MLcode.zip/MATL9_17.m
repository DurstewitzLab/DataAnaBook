clear all
close all

%% Fig. 9.22: Fractal error function landscapes in estimating chaotic systems
% with latent variables, using bursting single cell model eq. 9.62
% --> produces Fig. 9.22

load NMDAcell_param; Par=ParNL; % parameters of NMDA-driven single cell model

randn('state',0);

%% simulate 'ground truth' model with process noise
Tmax=2e3; dt=0.1; Tvec=0:dt:Tmax;   % solution time points
Par(18)=11.4;   % 'true' NMDA conductance strength
Par(20)=Tmax;   % simulation time
Par(21:20+length(Tvec))=30*randn(1,length(Tvec));   % Gaussian noise sequence
Vini=[Par(4) 0 0];  % initial condition
opt=odeset('RelTol',1e-5,'AbsTol',1e-7,'MaxStep',dt);
[tobs,Vobs]=ode23s(@dVdtNMDAburster,Tvec,Vini,opt,Par); % simulate model

%% Error function w.r.t. gNMDA in non-forced system
gNMDA=10:0.1:13;    % range to check
Par(21:20+length(Tvec))=0;
LSEfree=zeros(1,length(gNMDA));
for i=1:length(gNMDA)
    disp(['non-forced ' num2str(i)]);
    Par(18)=gNMDA(i);
    [t,V]=ode23s(@dVdtNMDAburster,Tvec,Vini,opt,Par);
    LSEfree(i)=sum((V(:,1)-Vobs(:,1)).^2);  % evaluate squared error
end;

%% Error function w.r.t. gNMDA in system forced by observations
Par(21:20+length(Tvec))=Vobs(:,1)';
Par(1)=1;
LSEforced=zeros(1,length(gNMDA));
for i=1:length(gNMDA)
    disp(['forced ' num2str(i)]);
    Par(18)=gNMDA(i);
    [t,V]=ode23s(@dVdtNMDAbursterForced,Tvec,Vini,opt,Par); % run forced system
    LSEforced(i)=sum((V(:,1)-Vobs(:,1)).^2);  % evaluate squared error
end;
%save Fig9_22Res gNMDA LSEfree LSEforced tobs Vobs

%% plot results
%load Fig9_22Res
plot(gNMDA,LSEfree,'b',gNMDA,100*LSEforced,'r','LineWidth',2); box off
xlim([gNMDA(1) gNMDA(end)]); set(gca,'FontSize',20)
xlabel('g_N_M_D_A (mS)'); ylabel('LSE');
axis([10 13 0 3.5e7])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
