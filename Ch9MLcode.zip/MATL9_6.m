%% Training Recurrent Neural Network (RNN) model through Real-Time Recurrent Learning (RTRL) 
% - wrapper file for defining task setup, and training & running RNN
% - creates Fig. 9.7, driven nonlinear limit cycle

clear all;
rand('state',5);    % random seed

%% General parameters
N=10;            % number units
beta=10;        % slope of sigmoid
thresh=0.5;     % threshold of sigmoid
alpha=0.05;      % learning parameter
TF=1;           % Teacher-forcing
Ntrials=2000;   % number trials


%% Task specification
TrialLength=15;

% Inputs
InpVal=zeros(N,TrialLength);
InpVal(1,1)=1;
InpVal(2,6)=1;
InpVal(3,11)=1;

% requested outputs
OutpVal=zeros(N,TrialLength)+nan; % nan = no specific output required
OutpVal(5,2:5)=[0.2 0.4 0.6 0.8];
OutpVal(5,7:10)=[1 0 0 1]; 
OutpVal(5,12:15)=[0.8 0.6 0.4 0.2]; 

% plot task setup
figure(1), hold off cla
subplot(2,2,1), imagesc(InpVal)
set(gca,'FontSize',20)
title('Inputs across one training epoch'); xlabel('time step'); ylabel('unit #');
subplot(2,2,2), bar(OutpVal(5,:))
set(gca,'FontSize',20)
title('Target Output'); xlabel('time step'); ylabel('x_5');
axis([0 16 0 1]);, box off

%% initialization
par=[beta thresh alpha TF];
dVdw=zeros(N,N^2);
V=zeros(N,1);
W=rand(N,N)-0.5;

%% Training phase
for i=1:Ntrials   % loop through trials
    ErrSum(i)=0;
    for j=1:TrialLength   % loop through time points, updating weights online
        InpL=find(InpVal(:,j)~=0);
        InpV=InpVal(InpL,j);
        OutL=find(~isnan(OutpVal(:,j)));
        OutV=OutpVal(OutL,j);
        [V,W,dVdw,Err]=RTRL(V,W,dVdw,InpL,InpV,OutL,OutV,par);
        ErrSum(i)=ErrSum(i)+Err;
    end;
    ErrSum(i)=ErrSum(i)/TrialLength;
    disp(i)
end;

% plot training error as function of trials
subplot(2,2,3), hold off, plot(ErrSum,'LineWidth',2); box off
set(gca,'FontSize',20); xlabel('Training run'); ylabel('Error');
title('Total Error');
axis([0 300 0 0.16]);


%% Recall phase (disable learning)
par([3 4])=0;       % set learning param. & TF to 0
OutL=[]; OutV=[];   % no teacher-outputs
Ntrials=20;
for i=1:Ntrials
	for j=1:TrialLength
        InpL=find(InpVal(:,j)~=0);
        InpV=InpVal(InpL,j);
        [V,W,dVdw,Err]=RTRL(V,W,dVdw,InpL,InpV,OutL,OutV,par);
        Vout(:,j+(i-1)*TrialLength)=V;
	end;
end;

% plot performance of trained RNN during recall
subplot(2,2,4), hold off, bar(Vout(5,:)); box off
set(gca,'FontSize',20)
title('Actual Output'); xlabel('time step'); ylabel('x_5');
axis([0 280 0 1])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
