clear all
close all

%% Fig. 9.2: first-return plots of logistic map for 3 different alpha's
% - cobwebs for stable/ unstable FP in logf

alp=0.7; x=logf(alp,0.5,[3 1]); subplot(3,2,1), xlim([0 40])    % low FP
text(13,0.8,['$$ \alpha = ' num2str(alp) '$$'],'Interpreter','latex','Fontsize',24);
title('Time graph'); subplot(3,2,2), title('Return plot');
alp=1.6; x=logf(alp,0.6,[3 3]); subplot(3,2,3), xlim([0 40])    % high FP
text(13,0.8,['$$ \alpha = ' num2str(alp) '$$'],'Interpreter','latex','Fontsize',24);
alp=3.3; x=logf(alp,0.65,[3 5]); subplot(3,2,5), xlim([0 40])   % 2-cycle
text(13,0.2,['$$ \alpha = ' num2str(alp) '$$'],'Interpreter','latex','Fontsize',24);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University