function [Re_nc,Ri_nc,Rfix,z,Jv,tall,Rall]=ncEImodel(kk,par,Tend,Stim,show,Rini)
% > simulate E-I model (Wilson-Cowan-type neural population model; see
% Wilson, 1999, Spikes, decisions, and actions. Oxford.)
% > show time graph
% > plot state space with nullclines & trajectory
% > show real & imaginary parts of eigenvalues of fixed point
%
% --- INPUTS
% kk: vector specifying subplot to plot into
% par: parameter vector (see below)
% Tend: simulation time
% Stim: stimulus flag
% show: flag indicating whether to plot results
% Rini: initial state for E and I unit
% --- OUTPUTS
% Re_nc: E nullcline
% Ri_nc: I nullcline
% Rfix: cell array of fixed points
% z: real & imaginary parts of eigenvalues
% Jv: Jacobian matrix at FP
% tall: time vector
% Rall: time series of E and I units

% set defaults
if nargin<3 || isempty(Tend), Tend=2500; end;
if nargin<4 || isempty(Stim), Stim=false; end;
if nargin<5 || isempty(show), show=true; end;
if nargin<6 || isempty(Rini), Rini=[2 7.5]; end;

%% parameters
wee=par(1);      % E-->E connection weight
wei=par(2);      % I-->E connection weight
IextE=par(3);    % external input to E-unit
slopeE=par(4);   % slope of sigmoid of E-unit
halfE=par(5);    % half activation threshold of E sigmoid
tauE=par(6);     % time constant of E unit
wie=par(7);      % E-->I connection weight
IextI=par(8);    % external input to I-unit
slopeI=par(9);   % slope of sigmoid of I-unit
halfI=par(10);   % half activation threshold of I sigmoid
tauI=par(11);    % time constant of I unit

% vector ranges for state space
Rfac=40;    % 'conversion factor' for interpretation of rates in Hz
Re=0:0.001:1.1;
Ri=0:0.001:1;
Re2=0:0.05:1.1;
Ri2=0:0.05:1;
Re3=0:0.5:1.1;

%% nullclines
x=(1-Re)./Re; k=find(x<0); x(k)=0;
Re_nc=(log(x)./slopeE-halfE+wee*Re+IextE)./wei;
Ri_nc=1./(1+exp(slopeI*(halfI-wie*Re-IextI)));

%% flow field
if show
    [ReMtx,RiMtx]=meshgrid(Re2,Ri2);
    DRe=(-ReMtx+1./(1+exp(slopeE*(halfE-wee*ReMtx+wei*RiMtx-IextE))))./tauE;
    DRi=(-RiMtx+1./(1+exp(slopeI*(halfI-wie*ReMtx-IextI))))./tauI;
    nrm=sqrt(DRe.^2+DRi.^2);    % normalization factor
    subplot(kk(1),3,(kk(2)-1)*3+1), hold off; set(gca,'FontSize',20);
end;

%% numerical integration of ODE system
opt=odeset('RelTol',1e-5,'AbsTol',1e-8);
tall=[]; Rall=[];
R1=Rini./Rfac;
if ~Stim  % external stimulus present?
    IextE=0; IextI=0;
    par([3 8])=[IextE IextI];
    [t1,R1]=ode23(@dRate,[0 Tend],R1,opt,par);  % call numerical ODE solver
    tall=[tall;t1];
    Rall=[Rall;R1];
    if show
        plot(tall,Rfac*Rall(:,1),'k','LineWidth',2);
        axis([0 Tend 0 50]); box off;
    end;
else
    IextE=0; IextI=0;
    par([3 8])=[IextE IextI];   % no stim
    [t1,R1]=ode23(@dRate,[0 500],R1,opt,par);
    tall=[tall;t1];
    Rall=[Rall;R1];
    IextE=0.5; IextI=0; % StimE>0
    par([3 8])=[IextE IextI];
    [t1,R1]=ode23(@dRate,[500 750],R1(end,:),opt,par);
    tall=[tall;t1]; % concatenate solution vectors
    Rall=[Rall;R1];
    IextE=0; IextI=0;   % no stim
    par([3 8])=[IextE IextI];
    [t1,R1]=ode23(@dRate,[750 1750],R1(end,:),opt,par);
    tall=[tall;t1];
    Rall=[Rall;R1];
    IextE=-0.5; IextI=0;    % StimE<0
    par([3 8])=[IextE IextI];
    [t1,R1]=ode23(@dRate,[1750 2000],R1(end,:),opt,par);
    tall=[tall;t1];
    Rall=[Rall;R1];
    IextE=0; IextI=0;   % no stim
    par([3 8])=[IextE IextI];
    [t1,R1]=ode23(@dRate,[2000 Tend],R1(end,:),opt,par);
    tall=[tall;t1];
    Rall=[Rall;R1];
    if show
        tStim=[0 500 500 750 750 1750 1750 2000 2000 2500];
        Stim=[-10 -10 -5 -5 -10 -10 -15 -15 -10 -10];
        plot(tall,Rfac*Rall(:,1),'k',tStim,Stim,'r','LineWidth',2);
        axis([0 2500 -20 50]); box off;
        text(900,-4,'Stim','FontSize',20,'Color','r');
    end;
end;

%% plot flow field
if show
    ylabel('\itR\rm_e_x_c (Hz)');
    set(gca,'FontSize',20);
    subplot(kk(1),3,(kk(2)-1)*3+2), hold off;
    set(gca,'FontSize',20);
    h=quiver(Rfac*ReMtx,Rfac*RiMtx,DRe./nrm,DRi./nrm,'k');  % normalized flow vectors
    %h=quiver(Rfac*ReMtx,Rfac*RiMtx,DRe,DRi,'k');   % non-normalized
    set(h,'LineWidth',0.8);
    hold on;
    plot(Rfac*Re,Rfac*Re_nc,'b',Rfac*Re,Rfac*Ri_nc,'r','LineWidth',2);
    plot(Rfac*Rall(:,1),Rfac*Rall(:,2),'g','LineWidth',2);
    axis([0 Rfac*1.1 0 Rfac*0.8]);
    ylabel('\itR\rm_i_n_h (Hz)');
    set(gca,'FontSize',20);
end;

%% solve for fixed points
opt=optimoptions('fsolve','MaxIter',1000,'TolFun',1e-8,'TolX',1e-8);
Rfix{1}=fsolve(@dRate2,[1 0.5],opt,par);
Rfix{2}=fsolve(@dRate2,[0.5 0.5],opt,par);
Rfix{3}=fsolve(@dRate2,[0 0.5],opt,par);

%% create symbolic Jacobian
syms dR1 R1 slopeE halfE wee wei R2 IextE tauE dR2 slopeI halfI wie IextI tauI;
dR1=(-R1+1/(1+exp(slopeE*(halfE-wee*R1+wei*R2-IextE))))/tauE;
dR2=(-R2+1/(1+exp(slopeI*(halfI-wie*R1-IextI))))/tauI;
J=jacobian([dR1;dR2],[R1,R2]);

%% evaluate eigenvalues based on Jacobian
% instantiate parameters for eval of Jacobian
wee=par(1); wei=par(2); IextE=par(3); slopeE=par(4); halfE=par(5); tauE=par(6);
wie=par(7); IextI=par(8); slopeI=par(9); halfI=par(10); tauI=par(11);
R1=Rfix{1}(1);
R2=Rfix{1}(2);
% compute eigenvalues and plot
Rfix{1}=Rfac*Rfix{1}; Rfix{2}=Rfac*Rfix{2}; Rfix{3}=Rfac*Rfix{3};
disp(Rfix{1});
Jv=eval(J);
e=eig(Jv);
z=[real(e) imag(e)];
if show
    subplot(kk(1),3,(kk(2)-1)*3+3), hold off; bar(z);
    set(gca,'FontSize',20); box off
    ylabel('\lambda_i')
end;


%% ODE system
function dR=dRate(t,R,par)  % E-I ODE system (for numerical integration)
wee=par(1); 
wei=par(2); 
IextE=par(3); 
slopeE=par(4); 
halfE=par(5); 
tauE=par(6); 
wie=par(7); 
IextI=par(8); 
slopeI=par(9); 
halfI=par(10); 
tauI=par(11);
dR(1)=(-R(1)+1./(1+exp(slopeE*(halfE-wee*R(1)+wei*R(2)-IextE))))./tauE;
dR(2)=(-R(2)+1./(1+exp(slopeI*(halfI-wie*R(1)-IextI))))./tauI;
dR=dR';

function dR=dRate2(R,par)  % E-I ODE system (for fixed point solver)
wee=par(1); 
wei=par(2); 
IextE=par(3); 
slopeE=par(4); 
halfE=par(5); 
tauE=par(6); 
wie=par(7); 
IextI=par(8); 
slopeI=par(9); 
halfI=par(10); 
tauI=par(11);
dR(1)=(-R(1)+1./(1+exp(slopeE*(halfE-wee*R(1)+wei*R(2)-IextE))))./tauE;
dR(2)=(-R(2)+1./(1+exp(slopeI*(halfI-wie*R(1)-IextI))))./tauI;
dR=dR';


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
