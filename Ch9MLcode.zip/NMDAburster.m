function res=NMDAburster(Par,tstop,vs,fn,tstep)
% simulates single bursting cell model, and computes nullclines, fixed points
% and their stability, flow fields, finds limit cycles, determines
% bifurcation point (critical conductance level)
% - original eqns. & param.s from Izhikevich (2007), Dynamical Systems in Neurosci.
% - implemented & adapted to show NMDA-induced bursting & chaos by 
% Daniel Durstewitz, CIMH/ Heidelberg University
% cf. Durstewitz (2009), Neural Networks
%
% --- INPUTS
% Par: parameter vector specifying cell model (see below)
% tstop: simulation time
% vs: initial condition (Vm,n,h)
% fn: filename for analysis output
% tstep: max. time step for tracking progression of simulation
% --- OUTPUTS
% res: structure containing simulation & analysis output
%       .t: time vector
%       .v: dynamical variables Vm,n,h
%       .hfix: h value at fixed point
%       .Stab: number unstable eigen-directions from local Jacobian
%       .v1: voltage range for hfix
%       .LCmin: min. value of limit cycle
%       .LCmax: max. value of limit cycle
%       .hVec: corresponding h range

Vth=-30;    % voltage threshold for (spiking) limit cycle

%% numerically integrate ODE system
if ~isempty(vs), v0=vs; else v0=[Par(4) 0 0]; end;
if isempty(tstep)
    opt=odeset('RelTol',1e-5,'AbsTol',1e-7);
    [res.t,res.v]=ode23s(@dVdt,[0 tstop],v0,opt,Par);
else
    opt=odeset('RelTol',1e-5,'AbsTol',1e-7,'MaxStep',tstep);
    [res.t,res.v]=ode23s(@dVdt,0:tstep:tstop,v0,opt,Par);
end;

%%
if ~isempty(vs)
    res.v1=-90:0.1:20;
    if isempty(tstep)
        tstart=tstop;
        tstep=10*tstop;
    else
        tstart=tstep;
    end;
    warning off
    for ti=tstart:tstep:tstop
        % time graph (up til ti)
        k=find(res.t<=ti);
        subplot(3,1,1), plot(res.t(k),res.v(k,1))
        title('Time graph');
        xlabel('Time (ms)'); ylabel('Potential (mV)');
        
        % compute nullclines
        [nc1,nc2]=nullcl(res.v1,Par,res.v(k(end),3));
        
        % determine flow field
        v2=0:nc2(end)*1.1/100:1.1*nc2(end);
        gridf=5;
        [v1Mtx,v2Mtx]=meshgrid(res.v1(1:gridf:end),v2(1:gridf:end));
        Dv=dVdtRed(0,{v1Mtx v2Mtx},Par,res.v(k(end),3));
        
        % plot flow field and nullclines
        %nrm=sqrt(Dv{1}.^2+Dv{2}.^2);
        nrm=1;
        subplot(3,1,2), hold off, quiver(v1Mtx,v2Mtx,Dv{1}./nrm,Dv{2}./nrm,'c');
        hold on, plot(res.v1,nc1,'b',res.v1,nc2,'g',res.v(k,1),res.v(k,2),'r','LineWidth',1.4)
        title(['State space h = ' num2str(res.v(k(end),3))]);
        xlabel('Vm'); ylabel('n');
        axis([res.v1(1) res.v1(end) v2(1)-0.1 v2(end)]);
        
        % step through simulation
        if tstep<tstop
            x=input('next? ','s');
            if x=='q' break; end;
        end;
    end;
    warning on
    
    % plot final results
    subplot(3,1,1), plot(res.t,res.v), ylim([-80 10])
    subplot(3,1,3), hold off
    k=find(res.t>tstop/2);
    plot(res.v(k,3),res.v(k,1),'r'), hold on;
    [res.hfix,nfix]=FixPt(res.v1,Par);
    for i=1:length(res.hfix)
        res.Stab(i)=LocStab([res.v1(i) nfix(i)],Par,res.hfix(i));
    end;
    k=find(res.Stab==0 & res.hfix>0);
    plot(res.hfix(k),res.v1(k),'k','LineWidth',1.4);
    k=find(res.Stab==0 & res.hfix<0);
    plot(res.hfix(k),res.v1(k),'k','LineWidth',1.4);
    k=find(res.Stab>0);
    plot(res.hfix(k),res.v1(k),'k--','LineWidth',1.4);
    xlim([0 1])
    
    % determine limit cycle
    if ~isempty(fn)
        %h0=CompGcrit(@dVdtRed,v0(1:2),Par,[0 1])   % determine critical h-bif.-value
        res.hVec=0:0.5e-3:0.07;
        opt=odeset('RelTol',1e-5,'AbsTol',1e-8);
        if exist(fn)
            load(fn);
            istart=length(res.LCmin)+1;
        else
            istart=1;
        end;
        for i=istart:length(res.hVec)
            [t1,v1]=ode23s(@dVdtRed,[0 tstop],v0(1:2),opt,Par,res.hVec(i));
            k=find(t1>=4/5*tstop);
            if max(v1(k,1))>Vth
                res.LCmax(i)=max(v1(k,1));
                res.LCmin(i)=min(v1(k,1));
            else
                res.LCmax(i)=NaN;
                res.LCmin(i)=NaN;
            end;
            disp(i)
            save(fn,'Par','res');
        end;
        plot(res.hVec,res.LCmin,'k.',res.hVec,res.LCmax,'k.');
    end;
    
end;


%% ODE system defining cell model -----------------------------------------
function dV=dVdt(t,V,Par)
I=Par(1);       % external current input
C=Par(2);       % mem. capacitance
gL=Par(3);      % leakage conductance
EL=Par(4);      % leak reversal potential
gNa=Par(5);     % max. Na+ conductance
ENa=Par(6);     % Na+ reversal potential
VhNa=Par(7);    % m-gate half-activation
kNa=Par(8);     % Na+ activation slope
gK=Par(9);      % max. K+ conductance
EK=Par(10);     % K+ reversal potential
VhK=Par(11);    % n-gate half-activation
kK=Par(12);     % K+ activation slope
tcK=Par(13);    % time constant K+ current
gM=Par(14);     % max. M-type K+ conductance
VhM=Par(15);    % h-gate half-activation
kM=Par(16);     % M current activation slope
tcM=Par(17);    % time constant M current
gNMDA=Par(18);  % max. NMDA conductance
Vsinf=Par(19);  % steady-state NMDA activation voltage for linear NMDA
minf=1/(1+exp((VhNa-V(1))/kNa));
ninf=1/(1+exp((VhK-V(1))/kK));
hinf=1/(1+exp((VhM-V(1))/kM));
if Vsinf==0
    sinf=1/(1+0.33*exp(-0.0625*V(1)));
else
    sinf=1/(1+0.33*exp(-0.0625*Vsinf));
end;
dV(1)=(I-gL*(V(1)-EL)-gNa*minf*(V(1)-ENa)-gK*V(2)*(V(1)-EK) ...
    -gM*V(3)*(V(1)-EK)-gNMDA*sinf*V(1))/C;
dV(2)=(ninf-V(2))/tcK;
dV(3)=(hinf-V(3))/tcM;
dV=dV';

%% -----------------------------------------------------------------------
function [n0V,n0n]=nullcl(V,Par,h)
I=Par(1);
C=Par(2);
gL=Par(3);
EL=Par(4);
gNa=Par(5);
ENa=Par(6);
VhNa=Par(7);
kNa=Par(8);
gK=Par(9);
EK=Par(10);
VhK=Par(11);
kK=Par(12);
tcK=Par(13);
gM=Par(14);
VhM=Par(15);
kM=Par(16);
tcM=Par(17);
gNMDA=Par(18);
Vsinf=Par(19);
minf=1./(1+exp((VhNa-V)./kNa));
ninf=1./(1+exp((VhK-V)./kK));
if Vsinf==0
    sinf=1./(1+0.33*exp(-0.0625*V));
else
    sinf=1./(1+0.33*exp(-0.0625*Vsinf));
end;
n0V=(I-gL*(V-EL)-gNa*minf.*(V-ENa)-gM*h*(V-EK)-gNMDA*sinf.*V)./(gK*(V-EK));
n0n=ninf;

%% -----------------------------------------------------------------------
function dV=dVdtRed(t,V,Par,h)
I=Par(1);
C=Par(2);
gL=Par(3);
EL=Par(4);
gNa=Par(5);
ENa=Par(6);
VhNa=Par(7);
kNa=Par(8);
gK=Par(9);
EK=Par(10);
VhK=Par(11);
kK=Par(12);
tcK=Par(13);
gM=Par(14);
VhM=Par(15);
kM=Par(16);
tcM=Par(17);
gNMDA=Par(18);
Vsinf=Par(19);
if iscell(V)
    V1=V{1}; V2=V{2};
else
    V1=V(1); V2=V(2);
end;
minf=1./(1+exp((VhNa-V1)./kNa));
ninf=1./(1+exp((VhK-V1)./kK));
if Vsinf==0
    sinf=1./(1+0.33*exp(-0.0625*V1));
else
    sinf=1./(1+0.33*exp(-0.0625*Vsinf));
end;
dV1=(I-gL*(V1-EL)-gNa*minf.*(V1-ENa)-gK*V2.*(V1-EK)- ...
    gM*h*(V1-EK)-gNMDA*sinf.*V1)./C;
dV2=(ninf-V2)./tcK;
if iscell(V)
    dV={dV1 dV2};
else
    dV=[dV1 dV2]';
end;

%% -----------------------------------------------------------------------
function [hfix,ninf]=FixPt(vfix,Par)
I=Par(1);
C=Par(2);
gL=Par(3);
EL=Par(4);
gNa=Par(5);
ENa=Par(6);
VhNa=Par(7);
kNa=Par(8);
gK=Par(9);
EK=Par(10);
VhK=Par(11);
kK=Par(12);
tcK=Par(13);
gM=Par(14);
VhM=Par(15);
kM=Par(16);
tcM=Par(17);
gNMDA=Par(18);
Vsinf=Par(19);
minf=1./(1+exp((VhNa-vfix)./kNa));
ninf=1./(1+exp((VhK-vfix)./kK));
if Vsinf==0
    sinf=1./(1+0.33*exp(-0.0625*vfix));
else
    sinf=1./(1+0.33*exp(-0.0625*Vsinf));
end;
hfix=(I-gL*(vfix-EL)-gNa*minf.*(vfix-ENa)-gK*ninf.*(vfix-EK)- ...
    gNMDA*sinf.*vfix)./(gM*(vfix-EK));

%% -----------------------------------------------------------------------
function Stab=LocStab(V,Par,hfix)
I=Par(1);
C=Par(2);
gL=Par(3);
EL=Par(4);
gNa=Par(5);
ENa=Par(6);
VhNa=Par(7);
kNa=Par(8);
gK=Par(9);
EK=Par(10);
VhK=Par(11);
kK=Par(12);
tcK=Par(13);
gM=Par(14);
VhM=Par(15);
kM=Par(16);
tcM=Par(17);
gNMDA=Par(18);
Vsinf=Par(19);
minf=1/(1+exp((VhNa-V(1))/kNa));
%ninf=1/(1+exp((VhK-V(1))/kK));
dminfdV=(exp((VhNa-V(1))/kNa)/kNa)/(1+exp((VhNa-V(1))/kNa))^2;
dninfdV=(exp((VhK-V(1))/kK)/kK)/(1+exp((VhK-V(1))/kK))^2;
if Vsinf==0
    sinf=1/(1+0.33*exp(-0.0625*V(1)));
    dsinfdV=(0.33*0.0625*exp(-0.0625*V(1)))/(1+0.33*exp(-0.0625*V(1)))^2;
else
    sinf=1/(1+0.33*exp(-0.0625*Vsinf));
    dsinfdV=0;
end;
dVdV(1,1)=(-gL-gNa*(dminfdV*(V(1)-ENa)+minf)-gK*V(2)-gM*hfix- ...
    gNMDA*(dsinfdV*V(1)+sinf))/C;
dVdV(1,2)=-gK*(V(1)-EK)/C;
dVdV(2,1)=dninfdV/tcK;
dVdV(2,2)=-1/tcK;
if length(find(isnan(dVdV)))==0 & length(find(isinf(dVdV)))==0
    ev=real(eig(dVdV));
    Stab=length(find(ev>=0));
else
    Stab=NaN;
end;

%% -----------------------------------------------------------------------
function hCrit=CompGcrit(ODESys,vini,Par,hBd0)
% determine critical h-conductance at which LC comes into existence
Tbin=500;
MaxAbsErr=1e-6;
hBd=hBd0;
err=1e6;
while err>MaxAbsErr
    h=diff(hBd)/2+hBd(1);
    LC=FindLC(ODESys,0,vini,Par,Tbin,h);
    if ~LC
        hBd(2)=h;
    else
        hBd(1)=h;
    end;
    err=abs(diff(hBd))
end;
if LC
    hCrit=h;
else
    hCrit=hBd(2);
end;

%% -----------------------------------------------------------------------
function LC=FindLC(ODESys,t,v,Par,Tbin,h)
opt=odeset('RelTol',1e-5,'AbsTol',1e-8);
Vth=-30;
eps=1e-3;
Nconv=10;
scrit=2;
ISImax=500;
Conv=false; Tsp=[];
while ~Conv
    v0=v(end,:);
    [t,v]=ode23s(ODESys,[t(end) t(end)+Tbin],v0,opt,Par,h);
    k=find(v(2:end,1)>=Vth & v(1:end-1,1)<Vth);
    Tsp1=t(k)+(t(k+1)-t(k)).*(Vth-v(k,1))./(v(k+1,1)-v(k,1));
    Tsp=[Tsp;Tsp1];
    if (length(Tsp)<2) | (t(end)-Tsp(end)>ISImax)
        Conv=true; LC=false;
    else
        ISI=diff(Tsp);
        if length(ISI)>=Nconv+1
            dISI=diff(ISI(end-Nconv:end));
            x=ISI(end)-ISI(end-Nconv);
            if (length(find(abs(dISI)>=eps*max(ISI(end-Nconv:end))))==0) & ...
                    (x<=max(dISI)) & (x>=min(dISI))
                Conv=true; LC=true;
            end;
        end;
    end;
end;
