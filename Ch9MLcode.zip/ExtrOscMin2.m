function [x,v]=ExtrOscMin2(S,npts,tol,MinIntv,ExtrType)
% finds extrema of oscillating function
% --- INPUTS:
% S: signal time series
% npts: +/- window of time points around putative extrema
% tol: tolerated relative proportion of time points violating local
% extremum condition
% MinIntv: minimum interval assumed between extrema
% ExtrType: type of extremum (0=minima, else=maxima)
% --- OUTPUTS:
% x: time points of detected extrema
% v: extremum values

d=sign(diff(S));
%k=find(abs(diff(d))>0);    % all extrema
if ExtrType==0
    k=find(diff(d)==2);    % only minima
else
    k=find(diff(d)==-2);    % only maxima
end;
k(2:end+1)=k; k(1)=-Inf;
r=1; x(1)=-Inf;
for i=2:length(k)
    kset1=max(1,k(i)-npts+1):k(i);
    kset2=(k(i)+1):min(k(i)+npts,length(d));
    l1=length(find(d(kset1)==d(k(i))))/npts;
    l2=length(find(d(kset2)==d(k(i)+1)))/npts;
    if l1>=tol & l2>=tol & (k(i)-x(r))>MinIntv
        r=r+1;
        x(r)=k(i)+1;
        v(r)=S(x(r));
    end;
end;
x=x(2:end);
v=v(2:end);
%plot(S), hold on, plot(x,v,'ro');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
