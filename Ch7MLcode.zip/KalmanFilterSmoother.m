function [muhat, Vhat, Vhat1, mu, V, K]=KalmanFilterSmoother(x,mu0,L0,A,B, Gamma, Sigma,C,u)
% x: observed variables (q x n, with q= number obs., n= number time steps)
% mu0, L0: initial values
% A: transition matrix
% B: observation/emission matrix
% Gamma: observation/emission covariance
% Sigma: process noise covariance
% C: control variable matrix
% u: control variables

p= size(Sigma, 1); %dimensionality of latent states
n= size(x,2);      %number of time steps
q= size(x,1);      %number of observations

% are control variables entered? if not, set to 0
if nargin<8
    C=zeros(q,q); u=zeros(q,n);
end

%initialize variables for filter and smoother
L = zeros(p,p,n);           % measurement covariance matrix
L(:,:,1)=L0;                % prior covariance
mu_p  = zeros(p,n);         % predicted expected value
mu_p(:,1)=mu0;              % prior expected value
mu   = zeros(p,n)  ;        % filter expected value
V   = zeros(p,p,n);         % filter covariance matrix
K      = zeros(p,q,n);      % Kalman Gain
Vhat  =zeros(p,p,n);        % smoother covariance matrix
muhat = zeros(p,n);         % smoother expected value
Vhat1=zeros(p,p,n);         % lag-1 covariance matrix (t,t-1)


%KALMAN FILTER 
%--------------------------------------------------------------------------
%first step
K(:,:,1)    = L(:,:,1)*B'/(B*L(:,:,1)*B'+Gamma);            %Kalman gain
mu(:,1)     = mu_p(:,1)+K(:,:,1)*(x(:,1)-B*mu_p(:,1));
V(:,:,1)    = (eye(p)-K(:,:,1)*B)*L(:,:,1);

for t = 2:n %go forwards
    L(:,:,t)    = A*V(:,:,t-1)*A'+Sigma;
    K(:,:,t)    = L(:,:,t)*B'/(B*L(:,:,t)*B'+Gamma);        %Kalman gain
    mu_p(:,t)   = A*mu(:,t-1)+C*u(:,t);                     %model prediction
    mu(:,t)     = mu_p(:,t) + K(:,:,t)*(x(:,t)-B*mu_p(:,t));%filtered state 
    V(:,:,t)    = (eye(p) - K(:,:,t)*B)*L(:,:,t);           %filtered covariance 
end

%SMOOTHER
%--------------------------------------------------------------------------
%last step
muhat(:,t)=mu(:,end);     %last expected value of smoother is equal to filter
Vhat(:,:,t)=V(:,:,end);   %last covariance of smoother is equal to filter

for t=n-1:-1:1 %go backwards
    J              = V(:,:,t)*A'*L(:,:,t)^-1;
    Vhat(:,:,t)    = V(:,:,t)+J*(Vhat(:,:,t+1)-L(:,:,t))*J';
    muhat(:,t)     = mu(:,t)+J*(muhat(:,t+1)-A*mu(:,t));
    Vhat1(:,:,t+1) = Vhat(:,:,t+1)*J';
end

%%
% (c) 2017 Georgia Koppe, Dept. Theoretical Neuroscience, Central
% Institute of Mental Health, Heidelberg University
