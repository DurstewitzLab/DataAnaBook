function [V,Nsteps,Goal,Trajec]=TDE0(World1,Ntrials,par,start,seed)
% Implementation of SARSA-TDE-algorithm
% Inputs: World1 = matrix defining world with barriers and rewards
%         Ntrials = total number trials
%         par = param. vector: [learning rate, discount factor,
%         exploration par.]
%         start = x/y initial coordinates of agent in world
%         seed = random seed
% Outputs: V = value matrix for best action
%          Nsteps = number steps required on each trial
%          Goal = final x/y position
%          Trajec = path taken in last trial

rand('state',seed);
Vmax=100;
MaxSteps=1000;
lp=par(1);
DiscFac=par(2);
beta=par(3);
m=size(World1,1);
n=size(World1,2);

%% surround world with barriers (=99)
World=zeros(m+2,n+2)+99;
World(2:m+1,2:n+1)=World1;
V=zeros(m+2,n+2,5);
start=start+1;
xact=[0 1 0 -1 0;0 0 1 0 -1];

%% for graphical illustration of trajectory:
clrmin=40;
clrmax=64;
WorldIm=World;
k=find(WorldIm==99);
WorldIm=sign(World).*mod(abs(World),1000);
WorldIm(k)=-10000;
a=max(max(WorldIm));
WorldIm(k)=10000;
b=min(min(WorldIm));
L=a-b;
if (L==0) L=1; end;
WorldIm=clrmin+(clrmax-clrmin)*(WorldIm-b)./L;
WorldIm(k)=1;

%% main loop
for i=1:Ntrials
    
    x=start';
    steps=0;

    while abs(World(x(1),x(2)))<1000 && steps<MaxSteps
        
        % plot current position in world
        Trajec(:,steps+1)=x-1;
        WorldIm1=WorldIm;
        WorldIm1(x(1),x(2))=34;
        figure(1), subplot(1,2,1), image(WorldIm1);
        title('World');
        pause(0.0001);
    
        % determine all permitted actions and their values
        Actions=1:5;
        x1=x*ones(1,5)+xact;
        Vsa=[];
        for j=1:5
            xx=x1(:,j);
            if World(xx(1),xx(2))==99
                Actions=setdiff(Actions,j);
            else
                Vsa=[Vsa V(x(1),x(2),j)];
            end;
        end;
        
        % action selection acc. to softmax function
        Q=exp(beta.*Vsa);
        psel=Q./sum(Q); pcum=cumsum(psel);
        q=find(floor(rand./pcum)==0,1);
        Asel=Actions(q);
        
        % perform action
        xprev=x;
        x=x+xact(:,Asel);
        
        % update values
        Rstate=sign(World(x(1),x(2)))*mod(abs(World(x(1),x(2))),1000);
        PredErr=Rstate+DiscFac*max(V(x(1),x(2),:))-V(xprev(1),xprev(2),Asel);
        V(xprev(1),xprev(2),Asel)=min(V(xprev(1),xprev(2),Asel)+lp*PredErr,Vmax);
        steps=steps+1;
   
    end;

    % plot world
    WorldIm1=WorldIm;
    WorldIm1(x(1),x(2))=34;
    figure(1), subplot(1,2,1), image(WorldIm1);
    set(gca,'FontSize',20); title('World');

    % plot learned value matrix
    Vs=max(V,[],3);    
	VIm=round(clrmin+(clrmax-clrmin)*(Vs-b)./L);
	figure(1), subplot(1,2,2), image(VIm);
    set(gca,'FontSize',20); title('Predicted Values');
    
    Nsteps(i)=steps;
    Goal(:,i)=x-1;   
    
    xyz=input('Continue?');
    
end;

V=max(V(2:m+1,2:n+1,:),[],3);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
