function ybs=BlockPerm(y,blL,Nbs,s)
% block permutation bootstraps
% --- INPUTS
% y: original time series
% blL: block length
% Nbs: number bootstraps to create
% s: random seed
% --- OUTPUTS
% ybs: BS data sets

rand('state',s);

% divide into blocks
k=floor(length(y)/blL);
V=zeros(1,k)+blL;
if rem(length(y),blL)>0, V=[V length(y)-k*blL]; end;

% put original data blocks into cells
A=mat2cell(y,1,V);

% permute and transform back into BS series 
ybs=cell(Nbs,1);
for b=1:Nbs
    r=randperm(length(A));
    ybs{b}=cell2mat(A(r));
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
