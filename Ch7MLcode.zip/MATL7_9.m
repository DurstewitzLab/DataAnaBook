clear all
close all

load FigsCh7data

%% Fig. 7.11: Illustration of kernel density estimate (KDE)-based time series bootstraps

figure(11), hold off cla

% perform KDE on spike train data & plot
T=min(ST)-0.5:0.05:max(ST)+0.5;
h0=mean(diff(ST))^2;
[hucv,MISE]=UniKDE(ST,h0,1);
iFR=STtoGfAvg(ST',T,sqrt(hucv));
plot(T(1:end-1),iFR,'b',ST,5,'r.','LineWidth',2,'MarkerSize',10);

% draw bootstrap spike trains from KDE & plot
randn('state',1); rand('state',1);
hold on
for b=1:3
    tctr=randsample(ST,length(ST),true);
    STbs=tctr+randn(length(ST),1)*sqrt(hucv);
    plot(STbs,5+b*2.5,'g.','LineWidth',2,'MarkerSize',10);
end;
axis([3328 3338 0 35]); box off; set(gca,'FontSize',20);
xlabel('Time (sec)'); ylabel('Spike rate (Hz)');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
