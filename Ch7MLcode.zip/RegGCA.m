function [R2v,prV,R2w,prW,R2t,prT,GCR,prGCR,UV,B]=RegGCA(X,Y,o,eps)
% implements Granger causality based on CCA; partializing out effects of 
% instantaneous (x,y)-corr.
% --- based on: 
% Wu, G.R., Chen, F., Kang, D., Zhang, X., Marinazzo, D., Chen, H.: 
% Multiscale Causal Connectivity Analysis by Canonical Correlation: Theory 
% and Application to Epileptic Brain. IEEE Trans. Biomed. Eng. 58, 
% 3088-3096 (2011)
% - performs rank-reduction for eps=0, and regularization otherwise
% - observations in rows, variables in columns
% - Note that same regularization param. eps is used in 3 different
% estimations: for partializing out Xt-past(o), and for cov(X) and cov(Y)
% in RegCCA
%
% --- INPUTS
% X: Txp data matrix of AR process
% Y: Txq data matrix of 'predictor' process
% o: model order to check
% eps: regularization param., if desired
% --- OUTPUTS (various GLM/CCA-based test stats)
% Rv2,prV: Pillai's test stat & prob
% Rw2,prW: Wilk's test stat & prob
% Rt2,prT: Hotelling's test stat & prob 
% GCR,prGCR: Roy's test stat & prob 
% UV: concatenated eigenvectors from X and Y spaces associated with largest
% eigenvalues
% B: regression weights from prediction {Xt-past(o),Yt}-->Xt

% set defaults:

if nargin<3 || isempty(o), o=1; end;
if nargin<4 || isempty(eps), eps=0; end;

%% regress Xt on Xt-past(o) and Yt, partialize out ==> Xres
[N,p]=size(X);
[~,q]=size(Y);
X0=X'; Y0=Y';
for i=1:o
    X0=[X0;circshift(X',[0 i])];
    Y0=[Y0;circshift(Y',[0 i])];
end;
X=X0(:,o+1:end)'; Y=Y0(:,o+1:end)';
Zresp=X(:,1:p);
Zpred=[ones(N-o,1) X(:,p+1:end) Y(:,1:q)];
ZZ=Zpred'*Zpred;
if eps>0, ZZ=ZZ+eps*eye(size(ZZ)); end;
B=ZZ^-1*Zpred'*Zresp;
Xres=Zresp-Zpred*B;

%% compute regularized CCA between Xres and Yt-past(o)
[R2,U,V,peff,qeff]=RegCCA(Xres,Y(:,q+1:end),eps);
UV=[U(:,1)' V(:,1)'];

%% compute various test stats from the eigenvalues R2 (see mvGLM)
s=min(peff,qeff*o); dfh=peff*qeff*o;

% Pillai's trace
R2v=sum(R2)/s;
dfe=s*(N-peff+s-qeff);
Fv=(dfe/dfh)*R2v/(1-R2v);
prV=1-fcdf(Fv,dfh,dfe);

% Wilk's lambda
W=prod(1-R2);
if W<0, warning(['W= ' num2str(W) ' , eps= ' num2str(eps)]); W=0; end;
R2w=1-W^(1/s);
t=N-1-(o*qeff+peff+1)/2; r=(o*qeff)^2*peff^2;
if r==4, d=1; else d=real(sqrt((r-4)/((qeff*o)^2+peff^2-5))); end;
dfe=1+t*d-qeff*o*peff/2;
Fw=(dfe/dfh)*R2w/(1-R2w);
prW=1-fcdf(Fw,dfh,dfe);

% Hotelling's trace
T=sum(R2./(1-R2));
R2t=T/(T+s); dfe=s*(N-peff-2-qeff*o)+2;
Ft=(dfe/dfh)*R2t/(1-R2t);
prT=1-fcdf(Ft,dfh,dfe);

% Roy's greatest characteristic root
GCR=max(R2);
dfh=qeff*o; dfe=N-1-qeff*o;
Fgcr=(dfe/dfh)*GCR/(1-GCR);
prGCR=1-fcdf(Fgcr,dfh,dfe);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
