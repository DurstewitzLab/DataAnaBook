clear all
close all

load FigsCh7data


%% Fig. 7.1: Auto-corr-func, power spectrum, & return plots

% --- on spike train data

% compute and plot acf on ISI data
ISI=diff(ST);
M=30; acf=zeros(1,M+1);
for m=0:M, acf(m+1)=corr(ISI(1:end-m),ISI(1+m:end)); end;
subplot(2,3,1), hold off cla, plot(0:M,acf,'o-','LineWidth',2); box off;
set(gca,'FontSize',20), axis([0 30 -0.1 1]); xlabel('ISI #'); ylabel('\rho');
title('Auto-correlation');

% compute and plot PS
bw=0.01; h=histc(ST,t0:bw:t1);
[ps,freq]=pwelch(h,[],[],[],1/bw);
subplot(2,3,2), hold off cla, plot(freq,ps,'LineWidth',2); box off;
%subplot(2,3,2), hold off cla, loglog(freq,ps,'LineWidth',2); box off;
set(gca,'FontSize',20), axis([0 max(freq) 0 0.03]); xlabel('Frequency (Hz)'); ylabel('Power');
title('Power spectrum');

% first-return plot
subplot(2,3,3), hold off cla, plot(ISI(1:end-1),ISI(2:end),'.','LineWidth',2); box off;
set(gca,'FontSize',20), axis([0 0.4 0 0.4]); xlabel('ISI_t'); ylabel('ISI_t_+_1');
title('Return plot');


%% --- on BOLD data

% compute and plot acf on BOLD data
M=50; acf=zeros(1,M+1);
for m=0:M, acf(m+1)=corr(BOLD(1:end-m,2),BOLD(1+m:end,2)); end;
TR=1.8;
T=(0:M).*TR+TR/2;
subplot(2,3,4), hold off cla, plot(T,acf,'o-','LineWidth',2); box off;
set(gca,'FontSize',20), axis([0 max(T) -0.2 1]); xlabel('Time (sec)'); ylabel('\rho');

% compute and plot PS
[ps,freq]=pwelch(BOLD(:,2),[],[],[],1/TR);
subplot(2,3,5), hold off cla, plot(freq,ps,'LineWidth',2); box off;
set(gca,'FontSize',20), axis([0 max(freq) 0 25]); xlabel('Frequency (Hz)'); ylabel('Power');

% first-return plot
subplot(2,3,6), hold off cla, plot(BOLD(1:end-1),BOLD(2:end),'.','LineWidth',2); box off;
set(gca,'FontSize',20), axis([-3 4 -3 4]); xlabel('BOLD_t'); ylabel('BOLD_t_+_1');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
