clear all
close all

%% Fig. 7.4: Convergent, divergent, random walk AR processes

% convergent
T=1000; % # time steps
a=0.5;  % AR parameter
s=0.2;  % stdv of noise process
x=SimARMA(T,a,s);   % simulate AR model
subplot(1,3,1), hold off cla, plot(1:T,x,'LineWidth',2); box off;
set(gca,'FontSize',20), axis([0 T -1 1]); xlabel('t'); ylabel('x');
title('Stationary');
text(100,0.8,['$$ a_1=' num2str(a) '$$'],'FontSize',24,'Interpreter','latex');

% divergent
T=1000; a=1.05; s=0.2;
x=SimARMA(T,a,s);
subplot(1,3,2), hold off cla, plot(1:T,x,'LineWidth',2); box off;
set(gca,'FontSize',20), axis([0 T -1.5e20 1e20]); xlabel('t'); ylabel('x');
title('Divergent');
text(100,0.5e20,['$$ a_1=' num2str(a) '$$'],'FontSize',24,'Interpreter','latex');

% random walk
T=1000; a=1; s=0.2;
x=SimARMA(T,a,s);
subplot(1,3,3), hold off cla, plot(1:T,x,'LineWidth',2); box off;
set(gca,'FontSize',20), axis([0 T -10 5]); xlabel('t'); ylabel('x');
title('Random walk');
text(300,2,['$$ a_1=' num2str(a) '$$'],'FontSize',24,'Interpreter','latex');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
