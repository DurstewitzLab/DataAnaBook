clear all
close all

%% Fig. 7.7: Estimation of information transfer based on inferred Poisson AR models

% simulate Poisson AR process for 1000 different random initializations
for s=1:1000, [T,X]=SimPoissonAR(s); X1{s}=X(:,1); X2{s}=X(:,2); end;

% compute info transfer within sliding windows (may take long!)
Lwin=20;    % sliding window size
pmax=10;    % max # time lags to consider
XX=[cell2mat(X1') cell2mat(X2')];
tau=zeros(1,length(T)-Lwin);
itc=zeros(2,length(T)-Lwin);
pp=parpool(2);
parfor t=1:length(T)-Lwin
    disp(t);
    tt=t:t+Lwin-1;
    X1probe=cell(size(X1)); X2probe=cell(size(X2));
    for s=1:length(X1), X1probe{s}=X1{s}(tt,:); X2probe{s}=X2{s}(tt,:); end;
    [itc0,tau(t)]=InfoTransferPoisson(X1probe,X2probe,pmax,1);
    itc(:,t)=itc0';
end;
delete(pp);
%save SimAnaRes tau itc T Lwin


%% plot results
%load SimAnaRes
bw=10e-3;
BR=[3 6]'*ones(1,length(T)-Lwin).*bw;
k=find((T>=25 & T<=30) | (T>=45 & T<=50)); BR(1,k)=5*BR(1,k);
k=find((T>=35 & T<=40) | (T>=45 & T<=50)); BR(2,k)=5*BR(2,k);
k=find(T>=55 & T<=60); BR(:,k)=2*BR(:,k);
PP=ones(2,length(T)-Lwin);
k=find((T>=5 & T<=10) | (T>=55 & T<=60)); PP(1,k)=2*PP(1,k);
k=find(T>=15 & T<=20); PP(2,k)=2*PP(2,k);

% simulation setup
subplot(3,1,1), hold off cla
plot([T(1:end-Lwin);T(1:end-Lwin)]',BR','LineWidth',2)
hold on, plot(T(1:end-Lwin),PP(1,:),'b--','LineWidth',2);
plot(T(1:end-Lwin),PP(2,:),'r--','LineWidth',2);
axis([0 T(end) 0 2.1])
set(gca,'FontSize',20), box off
xlabel('Time'); title('Simulation setup');
set(gca,'FontSize',20), box off
text(22,1.8,'Conditional modulation','FontSize',20);
text(23,1.3,'$$ p(c_i=1|c_j=1)/p(c_i=1) $$','Interpreter','latex','FontSize',20);
text(3,0.5,'Base rate','FontSize',20);
text(15,0.45,'$$ p(c_i=1) $$','Interpreter','latex','FontSize',20);

% estimated info transfer
subplot(3,1,2), hold off cla
plot([T(1:end-Lwin);T(1:end-Lwin)]',itc','LineWidth',2), xlim([0 T(end)])
set(gca,'FontSize',20), box off
title('Estimated information transfer'), xlabel('Time'); ylabel('Info Transfer');

% estimated time lag
subplot(3,1,3), hold off cla
plot(T(1:end-Lwin)',tau','k','LineWidth',2), xlim([0 T(end)])
set(gca,'FontSize',20), box off
title('Estimated time lag'), xlabel('Time'); ylabel('Time Lag');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
