function [p,lLR,prChi2,prF,AIC,Zr,BIC]=MVARorder(X,m,pre,eps,alpha)
% determines order p of MVAR model from data X
% (implementation acc. to Lütkepohl, 2006, New Introduction to Multiple
% Time Series Analysis, Springer)
% --- INPUTS
% X: Txq data matrix, or cell array of data matrices (eg multiple trials)
% m: max. model order to check
% pre: flag which determines whether the initial m_max time steps are
% excluded from ALL models tested (instead of just m; looses some time 
% points, but makes models strictly comparable across all orders)
% eps: regularization par. (see MVARfit)
% alpha: alpha-level for successive-order tests 
% --- OUTPUTS
% p: estimated order based on LLR-test
% lLR: log-likelihood ratios for successive tests
% prChi2,prF: Chi2 and F statistics for successive tests 
% AIC,BIC: LL-based AIC and BIC for successive tests
% Zr: cell array of residual matrices from successive tests 

% set defaults:
if nargin<2 || isempty(m), m=10; end;
if nargin<3 || isempty(pre), pre=0; end;
if nargin<4 || isempty(eps), eps=0; end;
if nargin<5 || isempty(alpha), alpha=.05; end;

AIC=zeros(1,m+1)+nan; lLR=AIC; prChi2=zeros(1,m+1); prF=prChi2; BIC=AIC;
Zr=cell(1,m);
for i=0:m  % move through all orders
    X0=X;
    if pre % makes sure all model orders are tested with exactly same tp
        a=m-i+1;
        if iscell(X)
            for j=1:length(X), X0{j}=X{j}(a:end,:); end;
        else X0=X(a:end,:); end;
    end;
    [~,Zr{i+1},~,~,~,~,~,df1,~,~,nveff]=MVARfit(X0,i,eps);  % fit MVAR model of order i
    
    % compute test stats based on log-likelihood (see Lütkepohl 2006)
    L=df1+nveff;
    a=df1/L; Zr{i+1}=a*Zr{i+1};
    q=log(det(Zr{i+1}));    % LL
    AIC(i+1)=q+2*length(Zr{i+1})*(nveff-1)/L;
    BIC(i+1)=q+log(L)*length(Zr{i+1})*(nveff-1)/L;
    if i>0  % compute LLR and LLR-based stats
        lLR(i+1)=L*(log(det(Zr{i}))-q);
        prChi2(i+1)=1-chi2cdf(lLR(i+1),length(Zr{i+1})*(nveff-nvold));
        prF(i+1)=1-fcdf(lLR(i+1)/(length(Zr{i+1})*(nveff-nvold)),length(Zr{i+1})*(nveff-nvold),df1);
    end;
    nvold=nveff;
end;
r=(prF<=alpha); k=find(r==0);
if ~isempty(k), p=min(k)-2; else p=nan; end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
