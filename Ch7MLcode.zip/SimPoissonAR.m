function [T,X]=SimPoissonAR(s)
% simulate 2 point processes with different phases of baseline rate changes
% and/or inter-process couplings
% s: random seed
% T: time (binned)
% X: Tx2 point process output

rand('state',s);

nx=1; ny=1; % assume just 2 processes x and y
N=nx+ny;
bw=10e-3;   % bin-width for spike counting (assumed to be small enough to contain <=1 spike)
r1=3; r2=6; % baseline rates
lag=5;  % time-lag of interaction

% I) just baseline rate, assume no coupling
apPr=bw.*[r1 r2];   % a-priori spike prob. within bin
m=zeros(1,N);   % modulation strength
C=zeros(N); % coupling matrix
T=5/bw; X1=PlaceSpikes(apPr,m,C,T,lag); % produce spikes acc. to this scheme

% II) directed modulation 1-->2 on top of baseline process
apPr=bw.*[r1 r2];
m=[0 1]; C=[0 0; 1 0];
T=5/bw; X2=PlaceSpikes(apPr,m,C,T,lag);

% III) just baseline rate, assume no coupling
apPr=bw.*[r1 r2];
m=zeros(1,N); C=zeros(N);
T=5/bw; X3=PlaceSpikes(apPr,m,C,T,lag);

% IV) directed modulation 2-->1 on top of baseline process
apPr=bw.*[r1 r2];
m=[1 0]; C=[0 1; 0 0];
T=5/bw; X4=PlaceSpikes(apPr,m,C,T,lag);

% V) just baseline rate, assume no coupling
apPr=bw.*[r1 r2];
m=zeros(1,N); C=zeros(N);
T=5/bw; X5=PlaceSpikes(apPr,m,C,T,lag);

% VI) increase in base rate 1
k=5;    % rate increase factor
apPr=bw.*[k*r1 r2];
m=zeros(1,N); C=zeros(N);
T=5/bw; X6=PlaceSpikes(apPr,m,C,T,lag);

% VII) just baseline rate, assume no coupling
apPr=bw.*[r1 r2];
m=zeros(1,N); C=zeros(N);
T=5/bw; X7=PlaceSpikes(apPr,m,C,T,lag);

% VIII) increase in base rate 2
k=5; apPr=bw.*[r1 k*r2];
m=zeros(1,N); C=zeros(N);
T=5/bw; X8=PlaceSpikes(apPr,m,C,T,lag);

% IX) just baseline rate, assume no coupling
apPr=bw.*[r1 r2];
m=zeros(1,N); C=zeros(N);
T=5/bw; X9=PlaceSpikes(apPr,m,C,T,lag);

% X) increase in both rate 1 & 2
k=5; apPr=k*bw.*[r1 r2];
m=zeros(1,N); C=zeros(N);
T=5/bw; X10=PlaceSpikes(apPr,m,C,T,lag);

% XI) just baseline rate, assume no coupling
apPr=bw.*[r1 r2];
m=zeros(1,N); C=zeros(N);
T=5/bw; X11=PlaceSpikes(apPr,m,C,T,lag);

% XII) increase in both base rates + modulation 1 --> 2
k=2; apPr=k*bw.*[r1 r2];
m=[0 1]; C=[0 0; 1 0];
T=5/bw; X12=PlaceSpikes(apPr,m,C,T,lag);

% XIII) just baseline rate, assume no coupling
apPr=bw.*[r1 r2];
m=zeros(1,N); C=zeros(N);
T=5/bw; X13=PlaceSpikes(apPr,m,C,T,lag);

% concatenate all different phases
X=[X1;X2;X3;X4;X5;X6;X7;X8;X9;X10;X11;X12;X13];
T=(1:size(X,1)).*bw-bw/2;


function X=PlaceSpikes(apPr,m,C,T,lag)
N=length(m);
Q=rand(T,N);
X=zeros(T,N);
for t=1:T
    w=apPr;
    if t-lag>0
        for i=1:N  % modulate spike prob. acc. to inputs from coupled processes
            a=sum(X(t-lag,find(C(i,:)))); w(i)=min(w(i)*(1+a*m(i)),1);
        end;
    end;
    r= Q(t,:)<w;
    X(t,r)=1;
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
