function [acf,pacf]=pacfun(x,M)
% acorr and partial-acorr function
% --- INPUTS
% x: time series data
% M: maximum time lag to consider
% --- OUTPUTS
% acf: auto-corr function of t.s.
% pacf: partial auto-corr function of t.s.

acf=zeros(1,M+1); pacf=zeros(1,M+1);
X0=x; for i=1:M, X0=[X0;circshift(x,[0 i])]; end; Xpred=X0';
for m=0:M
    acf(m+1)=corr(x(1:end-m)',x(1+m:end)');
    if m<2, pacf(m+1)=acf(m+1);
    else
        l=m-1;
        X0=Xpred(1+l:end,2:2+l-1);
        b=(X0'*X0)^-1*X0'*x(1+l:end)';  % regression weights from m-1 previous time steps
        xres=x(1+l:end)'-X0*b;  % regress out last m-1 lags
        pacf(m+1)=corr(xres(1:end-m),xres(1+m:end));  % m-lag acorr on residual t.s.
    end;
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
