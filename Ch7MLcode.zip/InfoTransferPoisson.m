function [ITC,TAU,O]=InfoTransferPoisson(X1,X2,pmax,alpha)
% evaluates info transfer between 2 sets of point processes X1 and X2, up
% to a max. time lag of pmax, based on the fitting of Poisson AR models,
% using an analytical approximation to model estimation with step-wise
% addition of predictors, as given in Durstewitz (2017), Advanced Data Ana 
% in Neurosci, Springer.
% The algorithm adds predictors from previous time steps step-wise and
% retains only those regressors that significantly reduce the LL AND reduce
% the BIC. This accounts for long series of 0's in spike time series, which
% are kicked out without stopping the algo from exploring larger lags.
%
% --- INPUTS
% X1: Txm count data matrix, or set of such matrices arranged as cell array
% (corresponding to eg different trials)
% X2: Txn count data matrix, or set of such matrices arranged as cell array
% pmax: max. time lag to evaluate
% alpha: sig. level used for accepting or rejecting additional predictors
% in the model
% --- OUTPUTS
% ITC: info transfer coefficients for X1-->X2 and X2-->X1, defined as the
% difference between the BICs associated with the full {X1,X2} vs. X1 or X2
% only models
% TAU: estimated (max.) time lag of info transfer (from the persp. of X1)
% O: max. orders of estimated X1- and X2-only AR processes (first column),
% and orders up to which the resp. other process contributes to the first
% (2nd column)

% set defaults
if nargin<3 || isempty(pmax), pmax=10; end;
if nargin<4 || isempty(alpha), alpha=0.05; end;

% determine orders and info X2-->X1
[O(1,1),O(1,2),ITC(1)]=DetermOrderStepWise(X1,X2,pmax,alpha);
% determine orders and info X1-->X2
[O(2,2),O(2,1),ITC(2)]=DetermOrderStepWise(X2,X1,pmax,alpha);
TAU=O(1,2)-O(2,1);  % define time lag as difference between max. X2-->X1 order minus X2-only order


%% ---------------------------------------------------------
function [p_,q_,ITC]=DetermOrderStepWise(Xs,Ys,pmax,alpha)

if iscell(Xs), Y=cell2mat(Ys'); X=cell2mat(Xs');
    ns=length(Xs); Ls=[0 cumsum(cellfun(@length,Xs))];
else X=Xs; Y=Ys; ns=1; Ls=[0 size(Xs,1)]; end;
N=length(Y);
pmax0=min(pmax,max(find((1:pmax).*2<=N-ns*(1:pmax))));

if sum(Y)==0, p_=0; q_=0; ITC=0;
else
c0=ones(N,1)*log(mean(Y)); ce0=exp(c0);
p_=0; npred=1;
% prepare predictor and response matrices
Y0=Y'; for i=1:pmax0, Y0=[Y0;circshift(Y',[0 i])]; end; Y1=Y0';
X0=X'; for i=1:pmax0, X0=[X0;circshift(X',[0 i])]; end; X1=X0';
kk=[]; for i=1:ns, kk=[kk Ls(i)+1+pmax0:Ls(i+1)]; end;
X1=X1(kk,:); Y1=Y1(kk,:); X=X(kk,:); Y=Y(kk); c0=c0(kk); ce0=ce0(kk);

% base model LL and BIC
LLold=Y'*c0-sum(ce0); BICold=-2*LLold+npred*log(length(kk));

% add predictors from X stepwise (AR part):
for p=0:pmax0
    if p>0, Ypr0=Y1(:,p+1); else Ypr0=X; end;
    % analytical approx. to LL (uses up to quadratic terms):
    a0=-Y'*Ypr0; a1=sum(ce0(Ypr0==1)); a2=2*sum(ce0(Ypr0>1));
    if a1+a2==0 || sum(Y)==0, b=0;
    elseif a0==0, b=-100;
    elseif a2==0, b=log(-a0/a1);
    else z=(a1^2-4*a0*a2)^(1/2); b=log(-(a1-z)/(2*a2)); end;
    % compute new LL and BIC if new predictor were included:
    if ~isinf(b) && b~=0
        c=c0+b*Ypr0; ce=exp(c);
        LLnew=Y'*c-sum(ce); BICnew=-2*LLnew+(npred+1)*log(length(kk));
    else BICnew=BICold; LLnew=LLold; end;
    % compute LLR (deviance) and Chi2-based prob.:
    D=2*(LLnew-LLold); pr=1-chi2cdf(D,1);
    % add predictor only if it i) reduces BIC, ii) significantly
    % contributes:
    if (BICnew<BICold) && (pr<=alpha || p==0)
        BICold=BICnew; p_=p; npred=npred+1;
        LLold=LLnew;
        c0=c; ce0=ce;
    end;
end;

% ... now add 'cross-regressors' from 2nd process stepwise
BICsv=BICold; q_=0;
for q=1:pmax0
    Xpr0=X1(:,q+1);
    a0=-Y'*Xpr0; a1=sum(ce0(Xpr0==1)); a2=2*sum(ce0(Xpr0>1));
    if a1+a2==0 || sum(Y)==0, b=0;
    elseif a0==0, b=-100;
    elseif a2==0, b=log(-a0/a1);
    else z=(a1^2-4*a0*a2)^(1/2); b=log(-(a1-z)/(2*a2)); end;
    if ~isinf(b) && b~=0
        c=c0+b*Xpr0; ce=exp(c);
        LLnew=Y'*c-sum(ce); BICnew=-2*LLnew+(npred+1)*log(length(kk));
    end;
    D=2*(LLnew-LLold); pr=1-chi2cdf(D,1);
    if (BICnew<BICold) && (pr<=alpha)
        BICold=BICnew; q_=q; npred=npred+1;
        LLold=LLnew;
        c0=c; ce0=ce;
    end;
end;
ITC=BICsv-BICold;   % define info transfer as difference between BICs from cross+AR model vs. pure AR model
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
