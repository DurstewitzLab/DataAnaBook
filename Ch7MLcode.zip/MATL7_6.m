clear all
close all

%% Fig. 7.8: Granger causality measures based on AR and CCA models


%% simulate Y --> X scenario
T=10000;
A=eye(4)*0.5; A(1:2,3:4)=[0.3 0.3;0.3 0.3];
A(1,2)=0.2; A(2,1)=0.2; A(3,4)=0.2; A(4,3)=0.2;
B=eye(4)*0.2; B(1,2)=0.1; B(2,1)=0.1; B(3,4)=0.1; B(4,3)=0.1;
X=SimARMA(T,A,B)';

% compute AR-based Granger causality in both directions
[lWyx1,prChi2yx1,prFyx1,df1,df2]=MVARgranger(X(:,1:2),X(:,3:4),1);
[lWxy1,prChi2xy1,prFxy1,df1,df2]=MVARgranger(X(:,3:4),X(:,1:2),1);
% compute CCA-based Granger causality in both directions
[R2vYX1,prVyx1,R2wYX1,prWyx1,R2tYX1,prTyx1,GCRyx1,prGCRyx1,UVyx1,B]=RegGCA(X(:,1:2),X(:,3:4),1);
[R2vXY1,prVxy1,R2wXY1,prWxy1,R2tXY1,prTxy1,GCRxy1,prGCRxy1,UVxy1,B]=RegGCA(X(:,3:4),X(:,1:2),1);


%% simulate common driver scenario
A=eye(5)*0.5; A(1,2)=0.2; A(2,1)=0.2; A(3,4)=0.2; A(4,3)=0.2; A(:,5)=0.5;
B=eye(5)*0.2; B(1,2)=0.1; B(2,1)=0.1; B(3,4)=0.1; B(4,3)=0.1;
X=SimARMA(T,A,B)';

% compute AR-based Granger causality in both directions
[lWyx2,prChi2yx2,prFyx2,df1,df2]=MVARgranger(X(:,1:2),X(:,3:4),1);
[lWxy2,prChi2xy2,prFxy2,df1,df2]=MVARgranger(X(:,3:4),X(:,1:2),1);
% compute CCA-based Granger causality in both directions
[R2vYX2,prVyx2,R2wYX2,prWyx2,R2tYX2,prTyx2,GCRyx2,prGCRyx2,UV2,B]=RegGCA(X(:,1:2),X(:,3:4),1);
[R2vXY2,prVxy2,R2wXY2,prWxy2,R2tXY2,prTxy2,GCRxy2,prGCRxy2,UV2,B]=RegGCA(X(:,3:4),X(:,1:2),1);


%% plot all results
subplot(1,2,1), hold off cla
lW=[lWyx1 lWxy1 lWyx2 lWxy2];
bar(lW), box off
k=find([prFyx1 prFxy1 prFyx2 prFxy2]<0.05);
hold on, plot(k,1.1*max(lW),'k*','LineWidth',2,'MarkerSize',10)
set(gca,'FontSize',20); ylabel('\lambda_W');
set(gca,'XTickLabel',{'X-->Y','Y-->X','X-->Y','Y-->X'});

subplot(1,2,2), hold off cla
R2t=[R2tYX1 R2tXY1 R2tYX2 R2tXY2];
bar(R2t), box off
k=find([prTyx1 prTxy1 prTyx2 prTxy2]<0.05);
hold on, plot(k,1.1*max(R2t),'k*','LineWidth',2,'MarkerSize',10)
set(gca,'FontSize',20); ylabel('R_T^2');
set(gca,'XTickLabel',{'X-->Y','Y-->X','X-->Y','Y-->X'});


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
