clear all
close all

%% Fig. 7.5: (P)ACORR function of AR/MA process of higher order

T=100000; M=15;
a=cell(1,5); a0=[0.5 0.3 -0.3 0.2 -0.2];
a=mat2cell(a0,1,ones(1,length(a0))); b=0.2;
x=SimARMA(T,a,b); %x=zscore(x);
[acf,pacf]=pacfun(x,M);
subplot(2,2,1), hold off cla
plot(0:M,acf,'o-','LineWidth',2); box off; 
set(gca,'FontSize',20,'XTick',0:5:15), axis([0 M+1 -0.4 1]); xlabel('\Deltat'); ylabel('acorr');
title('Auto-correlation')
text(5,0.7,['AR(' num2str(length(a0)) ')'],'FontSize',20);
subplot(2,2,2), hold off cla
plot(0:M,pacf,'o-','LineWidth',2); box off; 
set(gca,'FontSize',20,'XTick',0:5:15), axis([0 M+1 -0.4 1]); xlabel('\Deltat'); ylabel('pacorr');
text(5,0.7,['AR(' num2str(length(a0)) ')'],'FontSize',20);
title('Partial auto-corr.');

a=[]; b0=[0.8 0.3 0.2 0.1 -0.1 0.1];
b=mat2cell(b0,1,ones(1,length(b0)));
x=SimARMA(T,a,b); %x=zscore(x);
[acf,pacf]=pacfun(x,M);
subplot(2,2,3), hold off cla
plot(0:M,acf,'o-','LineWidth',2); box off; 
set(gca,'FontSize',20,'XTick',0:5:15), axis([0 M+1 -0.4 1]); xlabel('\Deltat'); ylabel('acorr');
text(5,0.7,['MA(' num2str(length(b0)-1) ')'],'FontSize',20);
subplot(2,2,4), hold off cla
plot(0:M,pacf,'o-','LineWidth',2); box off; 
set(gca,'FontSize',20,'XTick',0:5:15), axis([0 M+1 -0.4 1]); xlabel('\Deltat'); ylabel('pacorr');
text(5,0.7,['MA(' num2str(length(b0)-1) ')'],'FontSize',20);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
