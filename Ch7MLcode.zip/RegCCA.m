function [R2,U,V,peff,qeff]=RegCCA(X,Y,eps)
% Regularized CCA
% - observations in rows, var in columns
%
% --- INPUTS
% X: Nxp data matrix
% Y: Nxq data matrix
% eps: regularization param., if desired
% --- OUTPUTS
% R2: eigenvalues
% U: eigenvectors from X-space sorted in order of descending eigenvalues
% V: eigenvectors from Y-space sorted in order of descending eigenvalues
% peff, qeff: effective d.f. in X and Y determined from hat matrix

% set defaults:
if nargin<3, eps=0; end;

[N,p]=size(X);
[~,q]=size(Y);

% cov matrices required for CCA (see MATL2_5)
Stot=cov([X Y]);
Sxx=Stot(1:p,1:p)+eps*eye(p);
Xmc=X-ones(N,1)*mean(X);
peff=trace(Xmc*(Xmc'*Xmc+eps*eye(p)*(N-1))^-1*Xmc');    % effective d.f.
Syy=Stot(p+1:p+q,p+1:p+q)+eps*eye(q);
Ymc=Y-ones(N,1)*mean(Y);
qeff=trace(Ymc*(Ymc'*Ymc+eps*eye(q)*(N-1))^-1*Ymc');    % effective d.f.
Sxy=Stot(1:p,p+1:p+q);
Syx=Stot(p+1:p+q,1:p);

% perform eigen-decomposition
[U,A]=eig(Sxx^-1*Sxy*Syy^-1*Syx);
[V,B]=eig(Syy^-1*Syx*Sxx^-1*Sxy);

% extract eigenvalues and sort eigen-vectors accordingly
R2=diag(real(A));
[~,k]=sort(R2,'descend');
U=U(:,k);
[~,k]=sort(diag(real(B)),'descend');
V=V(:,k);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
