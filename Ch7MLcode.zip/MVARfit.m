function [B,Zr,mu1,mu2,v,tstats,prt,df1,df2,Xpred,nveff]=MVARfit(X,p,eps)
% fits multivariate (vector) AR model of order p to data X and returns
% estimates of all model params. (mu,B,Zr) & matrix of t-stats for all par.
% - time in rows, variables in columns, separate trials as cells
% (implementation acc. to Lütkepohl, 2006, New Introduction to Multiple
% Time Series Analysis, Springer)
%
% --- INPUTS
% X: (T x nv) data matrix, or cell array of data matrices (eg multiple trials)
% p: model order (cf MVARorder)
% eps: ridge regularization param. for data cov-matrix
% --- OUTPUTS
% B: qxq coefficient matrix
% Zr: matrix of residuals
% mu1: estimated mean of t.s.
% mu2: empirical mean of t.s.
% v: maximum abs. eigenvalue of coefficient matrix for checking
% model stationarity
% tstats: matrix of t-stats for all coefficients in B
% prt: ... associated probs of t-stats
% df1,df2: degrees of freedom
% Xpred: predictor (regressor) matrix
% nveff: effective # var. or d.f. based on models 'hat' matrix (equal to nv
% in the absence of regularization)

% set defaults:
if nargin<2, p=1; end;
if nargin<3 || isempty(eps), eps=0; end;

if iscell(X), X1=cell2mat(X); else X1=X; X={X}; end;

%% construct predictor and response matrices from X
X0=X1'; for i=1:p, X0=[X0;circshift(X1',[0 i])]; end; X1=X0';
Xresp=[]; Xpred=[];
m0=0;
for i=1:length(X)
    [tp,nv]=size(X{i});
    kk=m0+(p+1:tp); m0=m0+tp;
    Xresp=[Xresp;X1(kk,1:nv)];
    Xpred=[Xpred;X1(kk,nv+1:end)];
end;

%% determine coeff. matrix B (perform regression)
L=size(Xresp,1);
Xpred=[ones(L,1) Xpred];
XX=Xpred'*Xpred;
if eps>0
    XX=XX+eps*eye(size(XX));
    nveff=trace((Xpred*XX^-1)'*Xpred);
else nveff=nv*p+1; end;
B=XX^-1*Xpred'*Xresp;
df1=L-nveff;
Zr=(Xresp-Xpred*B)'*(Xresp-Xpred*B)./df1;   % compute residuals
mu2=mean(Xresp);    % data mean

%% concatenate B-matrices for different orders for determining theoretical
% expectancy of process and checking stationarity
Y=eye(nv); A=[];
for i=1:p
    kk=1+(i-1)*nv+(1:nv);
    Y=Y-B(kk,:);
    A=[A B(kk,:)];  % used for stability check
end;
mu1=Y^-1*B(1,:)';   % alternative mean-estim. based on b0

% check for stationarity:
if nargout>4
    A=[A;eye(nv*(p-1),nv*p)];
    v=max(abs(eig(A)));
end;

%% t-stats for all coefficients
if nargout>5
    S=reshape(kron(diag(XX^-1),diag(Zr)),nv,nv*p+1)';
    tstats=B./sqrt(S);    % tests for bij=0
    df2=nv*df1;
    prt=tcdf(tstats,df1);
    % see Haufe et al., NIPS 2008, for an alternative way to correct var.
    % and compute FDR-corrected p
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
