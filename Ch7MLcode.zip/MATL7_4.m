clear all
close all

load FigsCh7data

%% Fig. 7.6: MVAR model parameter and order estimation from sim. & real data

% Simulate 3rd order MVAR process 
T=10000;    % length of t.s.
A=cell(1,3); A{1}=[0.8 0.2;-0.1 0.7];
A{2}=[-0.3 -0.4;0.1 0.4]; A{3}=[0.2 0;0.4 -0.1];
a0=[0.9 0.3]';
B=[0.2 0.1;0.1 0.2];
X=SimARMA(T,A,B,a0)';

% estimate model order:
M=10;   % max. order to check
alpha=0.05; % for stat. testing
[p,lLR,prChi2,prF,AIC,~,BIC]=MVARorder(X,M,false,[],alpha);
% estimate parameters and return test stats:
[B,Zr,mu1,mu2,v,tstats,prt,df1,df2]=MVARfit(X,p);

% plot BIC as func. of order
subplot(3,2,1), hold off cla
plot(0:M,BIC,'o-','LineWidth',2);
set(gca,'FontSize',20), axis([0 M+1 -8 4]); box off
title('Order estimate');
text(2,2.8,'\bf{MVAR(3)}','FontSize',20);
xlabel('order'); ylabel('BIC');

% plot estimated parameters
subplot(3,2,2), hold off cla
A1=[a0 cell2mat(A)]; B1=B';
AB=zeros(2,2*length(A1));
AB=[A1(1:end);B1(1:end)];
bar(AB'); axis([0 15 -0.5 1]); box off
set(gca,'FontSize',20), xlabel('parameter'), ylabel('value');
text(5,0.9,'\bf{MVAR(3)}','FontSize',20);
set(gca,'XTickLabel',{'\bf{a_0.}','','\bf{A_1.}','','','', ...
    '\bf{A_2.}','','','','\bf{A_3.}','','',''},'FontSize',20);
title('Parameter estimates');


%% estimate AR model from uni-var. ISI series

ISI=diff(ST);
[p,lLR,prChi2,prF,AIC,~,BIC]=MVARorder(ISI,M,false,[],alpha);
[B,Zr,mu1,mu2,v,tstats,prt,df1,df2]=MVARfit(ISI,p);

% plot BIC as func. of order
subplot(3,2,3), hold off cla
plot(0:M,BIC,'o-','LineWidth',2);
set(gca,'FontSize',20), axis([0 M+1 -4 -3.7]); box off
title('ISI'); xlabel('order'); ylabel('BIC');

% plot estimated parameters
subplot(3,2,4), hold off cla
bar(B'); axis([0 5 0 0.5]); box off
set(gca,'FontSize',20), xlabel('parameter'), ylabel('value');
set(gca,'XTickLabel',{'a_0','a_1','a_2','a_3'}); title('ISI');
k=find(prt<alpha | prt>1-alpha);
hold on, plot(k,0.4,'k*','LineWidth',2,'MarkerSize',10)


%% estimate MVAR model from multi-variate (BOLD) data

[p,lLR,prChi2,prF,AIC,~,BIC]=MVARorder(BOLD,M,false,[],alpha);
[B,Zr,mu1,mu2,v,tstats,prt,df1,df2]=MVARfit(BOLD,p);

% plot BIC as func. of order
subplot(3,2,5), hold off cla
plot(0:M,BIC,'o-','LineWidth',2); 
set(gca,'FontSize',20), xlabel('order'); ylabel('BIC');
axis([0 M+1 -5 -3.5]); box off, title('BOLD');

% graph estimated parameters
subplot(3,2,6), hold off cla
B1=B'; imagesc(B1(:,2:9)); colorbar
prt1=prt'; [r,c]=find(prt1(:,2:9)<0.01 | prt1(:,2:9)>1-0.01);
hold on, plot(c,r,'k*','LineWidth',3,'MarkerSize',15)
set(gca,'FontSize',20,'YTick',1:4);
set(gca,'XTick',1:9,'XTickLabel',{'a_{.1}','a_{.2}','a_{.3}','a_{.4}', ...
    'a_{.5}','a_{.6}','a_{.7}','a_{.8}'});
set(gca,'YTickLabel',{'a_{1.}','a_{2.}','a_{3.}','a_{4.}'}); title('BOLD');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
