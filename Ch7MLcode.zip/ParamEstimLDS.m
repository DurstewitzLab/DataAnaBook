function [mu0,A,B,S,G,ELL]=ParamEstimLDS(x,Ez,Vhat,Vhat1,B)

% implements parameter estimation for LDS
% z_1 ~ N(mu0,S)
% z_t = A z_t-1 + e_t , e_t ~ N(0,S)
% x_t = B z_t + nu_t , nu_t ~ N(0,G)

% REQUIRED INPUTS:
% x: observed variables (q x n, with q= number obs., n= number time steps)
% Ez: state estimates
% Vhat: estimated state covariance
% Vhat1: estimated lag-1 state covariance

% OPTIONAL INPUTS:
% B: observation parameter matrix (will be computed in here if omitted or set to []).

% OUTPUTS:
% mu0: state first moment initial conditions
% A: transition matrix
% B: observation matrix
% S: process noise diagonal covariance matrix
% G: observation noise diagonal covariance matrix
% ELL: expected (complete data) log-likelihood

[p,T] = size(Ez) ;
q     = size(x,1);


%% compute additional moments & expectancy matrices required for parameter estim:
x2   = zeros(q,q,T)  ;   % x*x'
Ezz  = zeros(p,p,T)  ;   % second moments
Ezz1 = zeros(p,p,T-1);   % lag-1 second moments
Ezx  = zeros(p,q,T)  ;   % E[z]*x'
for t=1:T
  x2(:,:,t)   = x(:,t)*x(:,t)';
  Ezz(:,:,t)  = Vhat(:,:,t) + Ez(:,t)*Ez(:,t)';
  Ezx(:,:,t)  = Ez(:,t)*x(:,t)';
  if t<T, Ezz1(:,:,t) = Vhat1(:,:,t+1) + Ez(:,t+1)*Ez(:,t)'; end
end


%% compute all parameters:
mu0=Ez(:,1);

A = sum(Ezz1,3)/sum(Ezz(:,:,1:end-1),3);

S = (sum(Ezz(:,:,2:end),3) - A*sum(Ezz1,3)' - sum(Ezz1,3)*A' + A*sum(Ezz(:,:,1:end-1),3)*A')./T;
S = diag(diag(S));

if nargin<5 || isempty(B)
  B = sum(Ezx,3)'/sum(Ezz,3);
end

G = mean(x2,3) - B*mean(Ezx,3) - mean(Ezx,3)'*B' + B*mean(Ezz,3)*B';
G = diag(diag(G));


%% compute expected log-likelihood:
if nargout == 6
  SA = S^-1*A; ASA = A'*SA;
  GB = G^-1*B; BGB = B'*GB;
  
  ELL = -(T*log(det(S)) + T*log(det(G)) - 2*trace(SA'*Ezz1(:,:,1)) ...
      + trace(ASA*Ezz(:,:,1)) + trace(BGB*Ezz(:,:,1)) + trace(G^-1*x2(:,:,1)) ...
      - 2*trace(GB*Ezx(:,:,1)))/2;
  for t = 2:T-1
    ELL = ELL - (trace(S^-1*Ezz(:,:,t)) - 2*trace(SA'*Ezz1(:,:,t)) ...
      + trace(ASA*Ezz(:,:,t)) + trace(BGB*Ezz(:,:,t)) + trace(G^-1*x2(:,:,t)) ...
      - 2*trace(GB*Ezx(:,:,t)))/2;
  end
  ELL = ELL - (trace(S^-1*Ezz(:,:,T)) ...
      + trace(BGB*Ezz(:,:,T)) + trace(G^-1*x2(:,:,T)) ...
      - 2*trace(GB*Ezx(:,:,T)))/2;
end

%%
% (c) 2017 Hazem Toutounji, Dept. Theoretical Neuroscience, Central
% Institute of Mental Health, Heidelberg University
