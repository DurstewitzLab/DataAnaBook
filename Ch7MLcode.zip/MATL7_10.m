clear all
close all

%% Illustration of block bootstraps

y=zeros(1,100);
for i=0:4, y(i*20+(1:10))=1; end;

blL=10; % block length
Nbs=10; % #BS
s=1;    % rand. seed
ybs=BlockPerm(y,blL,Nbs,s);

plot(y), hold on
plot(ybs{1}*0.8,'r')

%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
