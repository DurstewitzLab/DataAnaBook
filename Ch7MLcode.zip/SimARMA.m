function x=SimARMA(T,A0,B0,a0,S)
% simulation of multi-variate ARMA process
% --- INPUTS
% T: length of time series
% A0: AR coefficient matrix, or cell array of AR coeff. matrices, with the
% number of cells corresponding to the AR order (maximal time lag)
% B0: MA coefficient matrix, or cell array of MA coeff. matrices, with the
% number of cells corresponding to the MA order (maximal time lag)
% a0: (set of) initial values for the ARMA process
% S: noise covariance matrix
% --- OUTPUTS
% x: generated multivar. ARMA time series

randn('state',0);

if ~iscell(A0), A{1}=A0; else A=A0; end;
if ~iscell(B0) && ~isempty(B0), B{1}=B0; else B=B0; end;
if isempty(A{1}), N=0; else N=length(A); end;
if isempty(B{1}), M=0; else M=length(B); end;
p=max(length(A{1}),length(B{1}));

if nargin<4 || isempty(a0), a0=zeros(p,1); end;
if nargin<5 || isempty(S), S=eye(p); end;
x=zeros(p,T)+a0*ones(1,T);  % initialize process
e=mvnrnd(zeros(p,1),S,T)';  % draw noise innovations
x(:,1:max(N,M))=e(:,1:max(N,M));

%% iterate ARMA process
for t=max(N,M)+1:T
    for n=1:N, x(:,t)=x(:,t)+A{n}*x(:,t-n); end;
    for m=1:M, x(:,t)=x(:,t)+B{m}*e(:,t-m+1); end;
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
