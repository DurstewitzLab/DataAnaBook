clear all
close all

%% Expectation-Maximization on linear state-space model

load('ExampleLDSdata.mat');

% initial param. estimates
A = diag(rand(4,1));
B = randn(4);
Gamma = diag(rand(4,1))+0.001;
Sigma = diag(rand(4,1))+0.001;
mu0 = randn(4,1);
L0 = diag(rand(4,1))+0.001;

%% EM loop
max_iter=100;   % max. number EM iterations
ELL=0; LLR=inf;
tol=1e-4;   % relative threshold for LLR increase
i=1;
while i<max_iter && LLR>tol*abs(ELL(1))
    
    % E-step: Kalman filter-smoother
    [Ez,Vhat,Vhat1]=KalmanFilterSmoother(x,mu0,Sigma,A,B,Gamma,Sigma);
    
    % M-step: Parameter estimation
    [mu0,A,B,Sigma,Gamma,ELL(i)]=ParamEstimLDS(x,Ez,Vhat,Vhat1);  
    
    % compute log-likelihood ratio
    if i>1, LLR=ELL(i)-ELL(i-1); end
    i=i+1;
  
end

plot(ELL,'LineWidth',2)


%%
% (c) 2017 Toutounji/ Durstewitz, Dept. Theoretical Neuroscience, Central
% Institute of Mental Health, Heidelberg University
