function [lW,prChi2,prF,df1,df2]=MVARgranger(X,Y,p,eps)
% tests whether Y Granger-causes X
% (implementation acc. to Lütkepohl, 2006, New Introduction to Multiple
% Time Series Analysis, Springer)
% --- INPUTS
% X: T x nv1 data matrix, or cell array of data matrices (eg multiple trials)
% Y: T x nv2 data matrix, or cell array of data matrices (eg multiple trials)
% p: model order to check
% eps: regularization param., if desired
% --- OUTPUTS
% lW: Wald-type test statistic
% prChi2,prF: Chi2- and F-test probs. associated with lW 
% df1,df2: numerator and denominator d.f.

% set defaults:
if nargin<3 || isempty(p), p=1; end;
if nargin<4 || isempty(eps), eps=0; end;

if iscell(X)
    XY=cell(size(X));
    for i=1:length(X), XY{i}=[X{i} Y{i}]; end;
    nv1=size(X{1},2); nv2=size(Y{1},2);
else
    XY=[X Y];
    nv1=size(X,2); nv2=size(Y,2);
end;

% fit full {X,Y} MVAR model
[B,Zr,~,~,~,~,~,~,~,Xpred]=MVARfit(XY,p,eps);

% determine contrast matrix associated with Wald-type hypothesis test that
% predictors from Y significantly contribute predicting X
BB=B'; b=BB(1:end)';
K=[eye(nv1) zeros(nv1,nv2)];
KK=[]; for i=1:nv2, KK=blkdiag(KK,K); end;
KK=[zeros(nv1*nv2,nv1*(nv1+nv2)) KK];
C=[]; for i=1:p, C=blkdiag(C,KK); end;
C=[zeros(nv1*nv2*p,nv1+nv2) C];

% test-stats similar to Hotelling's T^2:
df1=rank(C);
% lW=(C*b)'*(C*kron((Xpred'*Xpred)^-1,Zr)*C')^-1*(C*b);  % does not work like this for large matrices!
XX=Xpred'*Xpred;
if eps>0, XX=XX+eps*eye(size(XX)); end; % add small reg. term if needed
V=XX^-1;
k=zeros(p*(nv1+nv2)+1,1); 
k(1+repmat(nv1+(1:nv2),1,p)+kron((0:p-1),repmat(nv1+nv2,1,nv2)))=1;
ZZ=Zr(1:nv1,1:nv1); if eps>0, ZZ=ZZ+eps*eye(size(ZZ)); end;
lW=(C*b)'*kron(V(find(k),find(k)),ZZ)^-1*(C*b);
prChi2=1-chi2cdf(lW,df1);   % Chi2 prob
if eps>0, df2=size(Xpred,1)-trace(Xpred*XX^-1*Xpred');
else df2=size(Xpred,1)-(nv1+nv2)*p-1; end;
prF=1-fcdf(lW/df1,df1,df2); % F prob


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
