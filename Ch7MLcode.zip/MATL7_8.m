clear all
close all

%% Fig. 7.9: Temporal Difference Error Learning

% create world for agent
World=zeros(5,10);
World(2,2:10)=99; World([3 4],2)=99;  World(4,4:10)=99;
World(1,10)=50; World(3,10)=80;
start=[5 10];   % initial position of agent

Ntrials=200;
par=[0.5 0.9 5];    % learning rate, discount factor, inverse temp. (beta)
[V,Nsteps,Goal,Trajec]=TDE0(World,Ntrials,par,start,0);
subplot(1,2,1), axis off
subplot(1,2,2), axis off


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
