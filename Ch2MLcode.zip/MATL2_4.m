clear all
close all

%% Fig 2.3: illustration of uni- vs. multivariate H0 acceptance regions
% (adopted from Krzanowski, 2000, Principles of Multivariate Analysis,
% Oxford, with permission)

figure(3), hold off cla
y=[norminv(0.05),norminv(0.05),2*norminv(0.95),2*norminv(0.95)];
rectangle('Position',y,'LineWidth',3,'EdgeColor','k','FaceColor','c');
x=-4:0.01:4; p=0.05;
S=[1 0.7; 0.7 2]; mu=[0 0];
hold on; [x1L,x1H]=NormContour(x,p,mu,S);
plot(x1L,x,'r','LineWidth',4), hold on;
plot(x1H,x,'r','LineWidth',4), hold on;
plot([0 0],[-4 4],'k','LineWidth',3)
plot([-4 4],[0 0],'k','LineWidth',3)
set(gca,'FontSize',20); box off; xlabel('\beta_1'); ylabel('\beta_2');
axis([-4 4 -4 4]); axis('off');
text(0.6,2.6,'\bf{multivar. H_0}','Color','r','FontSize',20)
text(1.6,2.2,'\bf{accept. region}','Color','r','FontSize',20)
text(0.5,-2.5,'\bf{univar. H_0}','Color','c','FontSize',20)
text(0.5,-3,'\bf{accept. region}','Color','c','FontSize',20)
text(3,-0.7,'\it{\beta}_1','Color','k','FontSize',20)
text(-0.7,3,'\it{\beta}_2','Color','k','FontSize',20)


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
