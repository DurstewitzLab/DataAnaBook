function y0=LocLinReg(X,y,x0,lam)
if nargin<4 || isempty(lam), lam=sqrt(0.1); end;
% Local linear regression model
% INPUTS:
% X: Nxp regressor data matrix
% y: vector of scalar outputs
% x0: set of target points at which prediction is desired
% lam: Gaussian kernel width
% OUTPUTS:
% y0: predictions at target points x0

[N,p]=size(X);
y0=zeros(size(x0,1),1);
ym=mean(y);
Xd=X-ones(N,1)*mean(X); % center data
x0d=x0-ones(size(x0,1),1)*mean(X);
for i=1:size(x0,1)
    d=(X-ones(N,1)*x0(i,:)).^2; % squared Eucl. distance
    if p>1, d=sum(d')'; end;
    K=exp(-d./lam^2);
    W0=diag(K./sum(K)); % kernel (weighting) matrix
    b0=(Xd'*W0*Xd)^-1*Xd'*W0*(y-ym);    % LLR coefficients at target
    y0(i)=x0d(i,:)'*b0+ym;  % prediction
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
