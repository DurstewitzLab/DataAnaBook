clear all
close all

%% Fig 2.1: How linear regression works

% generate data from linear model + Gaussian noise
x=(0:0.2:5)';
b0=1; b1=1; s=0.7;
y=b0+b1*x+s*randn(length(x),1);

% compute LSE estimate of b0,b1
X=[ones(length(x),1) x];
best=(X'*X)^-1*X'*y; ypred=X*best;

% plot everything
figure(1), hold off cla
plot(x,y,'bo','LineWidth',3);
hold on, plot(x,ypred,'r','LineWidth',3);
set(gca,'FontSize',20); box off; xlabel('\it{x}'); ylabel('\it{y}');
str1=['$$ \beta_0 = ' num2str(b0) ', \ \beta_1 = ' num2str(b1) ' $$'];
text(0,6.7,str1,'Color','r','FontSize',22,'Interpreter','latex')
best=round(1e3*best)*1e-3;
str2=['$$ \hat{\beta_0} \approx ' num2str(best(1)) ', \ \hat{\beta_1} \approx ' num2str(best(2)) '$$'];
text(0,5.4,str2,'Color','b','FontSize',22,'Interpreter','latex')
for i=1:length(x), plot([x(i) x(i)],[y(i) ypred(i)],'b','LineWidth',2); end;
axis([min(x)-0.2 max(x)+0.2 0 8])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
