clear all
close all

%% multivariate GLM

% set up some design matrix X and output matrix Y
X=zeros(60,3);
X(1:20,1)=1; X(21:40,2)=1; X(41:60,3)=1;
Y=randn(60,3);
Y(21:40,1)=Y(21:40,1)-0.5; Y(41:60,1)=Y(41:60,1)+0.5;
Y(21:40,3)=Y(21:40,3)+1; Y(41:60,3)=Y(41:60,3)+2;

% define contrasts to test
L=[1 -1 0; 0 1 -1];

% run multi-var. GLM
[B,Rv2,prV,Rw2,prW,Rt2,prT,Rf2,prF,GCR,prGCR]=mvGLM(X,Y,L);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
