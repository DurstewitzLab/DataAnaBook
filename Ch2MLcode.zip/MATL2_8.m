clear all
close all

%% Fig 2.7C-D: Fitting feedforward-NN via back-prop to rising sine-wave data

% create rising sine wave data
randn('state',10);
x=0:0.2:20; y=sin(x)+x./10+0.5*randn(size(x))+2;


%% train 2+1-layer NN by back-prop
ytar=(y-min(y))./range(y);  % scale y to sigmoid output range
k=100;    % # hidden units
b=1/2;    % slope of sigmoid
th=10;  % activation threshold
g=0.1;  % learning rate
niter=5000; % # training iterations
wh=randn(k,1);    % weight vector of hidden units
wo=randn(k,1);  % weight vector of output unit
Err=zeros(1,niter); % LSE vector
for i=1:niter
    zo=zeros(1,length(x));
    for j=1:length(x)   % loop through all samples
        zhinp=exp(b*(th-wh.*x(j)));
        zh=1./(1+zhinp); % hidden unit activation
        zoinp=exp(b*(th-wo'*zh));
        zo(j)=1/(1+zoinp);   % output unit activation
        delta=2*(ytar(j)-zo(j))*(b*zo(j)^2*zoinp);  % output error
        dErrdwo=-delta*zh;
        dErrdwh=-delta*x(j)*wo.*(b*zh.^2.*zhinp);
        wo=wo-g*dErrdwo;    % output weight update
        wh=wh-g*dErrdwh;    % hidden weight update
    end;
    ypred=range(y)*zo+min(y);   % predicted outputs, scaled back to original range
    Err(i)=sum((y-ypred).^2);   % total squared error
end;


%% Fig. 2.7C,D: plot results        
figure(7), hold off cla
subplot(3,2,4), plot(Err,'k','LineWidth',2), hold on
set(gca,'FontSize',20); box off; xlabel('iteration'); ylabel('LSE');
axis([0 niter 0 200])
subplot(3,2,6), plot(x,y,'ro','LineWidth',2), hold on
plot(x,ypred,'b','LineWidth',3)
set(gca,'FontSize',20); box off; xlabel('x'); ylabel('y');
axis([0 20 0 6])


%% Fig 2.7A: schema of feed-forward NN architecture

subplot(3,2,[1 3 5])
C=zeros(11,2)-5; C(4:9,1)=0; C(10:11,1)=5;
C(1:3,2)=-3:3:3; C(4:9,2)=-7.5:3:7.5; C(10:11,2)=-1.5:3:1.5;
ra=ones(11,1); viscircles(C,ra,'LineWidth',3,'EdgeColor','k');
axis([-7 7 -10 10]), axis off, box off
hold on
d=0.6;
for i=1:3, for j=4:9
        plot([C(i,1)+d C(j,1)-d],[C(i,2) C(j,2)],'k','LineWidth',3);
end; end;
for i=4:9, for j=10:11
        plot([C(i,1)+d C(j,1)-d],[C(i,2) C(j,2)],'k','LineWidth',3);
end; end;
text(C(2,1)-0.35,C(2,2)-0.1,'x_i','FontSize',20,'Color','k')
text(C(7,1)-0.35,C(7,2)-0.1,'y_j','FontSize',20,'Color','k')
text(C(10,1)-0.35,C(10,2)-0.1,'z_k','FontSize',20,'Color','k')
text(3,5,'\beta_k_j^(^z^)','FontSize',20,'Color','k')
text(-3.8,6.2,'\beta_j_i^(^y^)','FontSize',20,'Color','k')

text(-5,10,'\bf{A}','FontSize',26,'Color','k')
text(7,10,'\bf{B}','FontSize',26,'Color','k')
text(7,3,'\bf{C}','FontSize',26,'Color','k')
text(7,-4,'\bf{D}','FontSize',26,'Color','k')


%% Fig 2.7B: sigmoid I/O functions

subplot(3,2,2)
sigm=inline('1./(1+exp(b*(th-x)))','x','b','th');
bL=[2 0.5 0.1]; clr={'k','c','b'};
for i=1:length(bL), plot(x,sigm(x,bL(i),th),clr{i},'LineWidth',3); hold on; end;
set(gca,'FontSize',20); box off; xlabel('x'); ylabel('g(x)');
legend('\lambda=2','\lambda=0.5','\lambda=0.1');
legend('Location','SouthEastOutside'); legend('boxoff');
axis([0 20 0 1])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
