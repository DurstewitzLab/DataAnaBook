clear all
close all

%% Fig 2.4: Canonical Correlation Analysis

% set up correlated mixture model
MU=[0 0]'; SIG=[1 0.5;0.5 2];
X=mvnrnd(MU,SIG,100);
B=[1 0.5;-0.8 1]; s=0.3;
Y=X*B+s*randn(size(X));
corr([X Y])

% perform CCA
[~,p]=size(X); [~,q]=size(Y);
Stot=cov([X Y]);
Sxx=Stot(1:p,1:p);
Syy=Stot(p+1:p+q,p+1:p+q)+eps*eye(q);
Sxy=Stot(1:p,p+1:p+q);
Syx=Stot(p+1:p+q,1:p);
[U,A]=eig(Sxx^-1*Sxy*Syy^-1*Syx);
[V,B]=eig(Syy^-1*Syx*Sxx^-1*Sxy);

% plot everything
[R,k]=max(diag(A));
figure(4), hold off cla
subplot(1,2,1), plot(X(:,1),X(:,2),'bo','LineWidth',3), hold on;
set(gca,'FontSize',20); box off; xlabel('x_1'); ylabel('x_2');
ux=U(:,k); plot(4*[0 ux(1)],4*[0 ux(2)],'r','LineWidth',3)
axis([-6 6 -6 6]);
plot(-4*[0 ux(1)],-4*[0 ux(2)],'r','LineWidth',3)
subplot(1,2,2), plot(Y(:,1),Y(:,2),'bo','LineWidth',3), hold on;
set(gca,'FontSize',20); box off; xlabel('y_1'); ylabel('y_2');
vx=V(:,k); plot(4*[0 vx(1)],4*[0 vx(2)],'r','LineWidth',3)
plot(-4*[0 vx(1)],-4*[0 vx(2)],'r','LineWidth',3)
axis([-6 6 -6 6]);
str=['R^2 \approx ' num2str(round(R*1e3)*1e-3)];
text(-5,-5,str,'Color','k','FontSize',20);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
