function y0=CubicSpline(x,y,x0,nknots)
if nargin<4, nknots=2; end;
% --- Cubic spline model
% INPUTS:
% X: N-vector of inputs (regressors)
% y: N-vector of outputs
% x0: set of target points at which prediction is desired
% nknots: number of knots
% OUTPUTS:
% y0: predictions at target points x0

N=length(x);

% determine position of knots
xs=sort(x);
pc=N/(nknots+1);
kn=[]; for i=1:nknots, kn(i)=xs(round(i*pc)); end;

% set up piecewise cubic model & compute coefficients
X=ones(N,1); X(:,2)=x;  X(:,3)=x.^2;  X(:,4)=x.^3;
for i=1:nknots, X(:,4+i)=max(0,x-kn(i)).^3; end;
b=(X'*X)^-1*X'*y;

% determine predictions at targets using estimated coefficients b
X=ones(length(x0),1); X(:,2)=x0;  X(:,3)=x0.^2;  X(:,4)=x0.^3;
for i=1:nknots, X(:,4+i)=max(0,x0-kn(i)).^3; end;
y0=X*b;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
