function [B,Rv2,prV,Rw2,prW,Rt2,prT,Rf2,prF,GCR,prGCR]=mvGLM(X0,Y0,L)
% implements test stats for multivariate GLM (acc. to Haase, 2011,
% Multivariate General Linear Models. Sage.)
% --- INPUTS:
% X0: Nxp matrix of predictors/ design matrix
% Y0: Nxq matrix of outputs
% L: hypothesis (contrast) matrix
% --- OUTPUTS:
% Rv2,prV: Pillai's test stat & prob
% Rw2,prW: Wilk's test stat & prob
% Rt2,prT: Hotelling's test stat & prob 
% Rf2,prF: F test stats & probs on single outputs
% GCR,prGCR: Roy's test stat & prob 

[N,p]=size(X0); ph=size(L,1);

% compute regr. (B) coefficients and relevant matrices
XX=(X0'*X0)^-1;
B=XX*X0'*Y0;
SQhyp=(L*B)'*(L*XX*L')^-1*(L*B);
SQerr=(Y0-X0*B)'*(Y0-X0*B);
q=size(Y0,2); s=min(q,ph); dfh=q*ph;
C=(SQhyp+SQerr)^-1*SQhyp;

%% Pillai's trace
V=trace(C);
Rv2=V/s; dfe=s*(N-p+s-q);
Fv=(dfe/dfh)*Rv2/(1-Rv2);
prV=1-fcdf(Fv,dfh,dfe);

%% Wilk's lambda
W=det(SQerr)/det(SQerr+SQhyp);
Rw2=1-W^(1/s);
t=N-1-(q+ph+1)/2; r=q^2*ph^2;
if r==4, d=1; else d=sqrt((r-4)/(q^2+ph^2-5)); end;
dfe=1+t*d-q*ph/2;
Fw=(dfe/dfh)*Rw2/(1-Rw2);
prW=1-fcdf(Fw,dfh,dfe);

%% Hotelling's trace
T=trace(SQerr^-1*SQhyp);
Rt2=T/(T+s); dfe=s*(N-ph-2-q)+2;
Ft=(dfe/dfh)*Rt2/(1-Rt2);
prT=1-fcdf(Ft,dfh,dfe);

%% Roy's greatest characteristic root (union-intersection test)
GCR=max(eig(C));
dfh=q; dfe=N-1-q+ph-p;
Fgcr=(dfe/dfh)*GCR/(1-GCR);
prGCR=1-fcdf(Fgcr,dfh,dfe);

%% univariate tests
dfh=ph; dfe=N-p;
Funi=(dfe/dfh)*diag(SQhyp)./diag(SQerr);
prF=1-fcdf(Funi,dfh,dfe);
Rf2=diag(SQhyp)./(diag(SQhyp)+diag(SQerr));


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
