clear all
close all

%% Fig 2.6: Fit kNN to rising sine-wave data (running average)

% create rising sine wave data
x=0:0.2:20; y=sin(x)+x./10+0.5*randn(size(x))+2;
x0=0:0.1:20;    % target points


%% kNN fit with k=5
figure(6), hold off cla
k=5;
subplot(1,2,1), plot(x,y,'ro','LineWidth',2), hold on
y0=zeros(1,length(x0));
for i=1:length(x0)  % search for k nearest x-data values to targets x0 
    d=abs(x0(i)-x); [~,m]=sort(d,'ascend');
    y0(i)=mean(y(m(1:k)));
end;
plot(x0,y0,'b','LineWidth',3);
set(gca,'FontSize',20); box off; xlabel('x'); ylabel('y');
text(2,5.5,'\it{k}=5','FontSize',20); axis([0 20 0 6])

%% kNN fit with k=20
k=20;
subplot(1,2,2), plot(x,y,'ro','LineWidth',2), hold on
y0=zeros(1,length(x0));
for i=1:length(x0)
    d=abs(x0(i)-x); [~,m]=sort(d,'ascend');
    y0(i)=mean(y(m(1:k)));
end;
plot(x0,y0,'b','LineWidth',3);
set(gca,'FontSize',20); box off; xlabel('x'); ylabel('y');
text(2,5.5,'\it{k}=20','FontSize',20); axis([0 20 0 6])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
