clear all
close all

%% Fig 2.2: Q-Q-plots, normal vs. normal, gamma vs. normal

N=200;
y=sort(zscore(gamrnd(2,2,N,1)),'ascend');  % draw from gamma distribution
py=(1:N)./N;
figure(2), hold off cla, subplot(1,2,1)
plot(y,norminv(py),'bo','LineWidth',3);
hold on, plot(-4:0.1:4,-4:0.1:4,'r','LineWidth',3);
axis([-4 4 -4 4]); set(gca,'FontSize',22); 
title('$$ y \sim gammapdf(2,2) $$','Interpreter','latex');
xlabel('std-norm quantiles'); ylabel('empirical quantiles');

y=sort(zscore(normrnd(3,4,N,1)),'ascend');  % draw from normal distribution
subplot(1,2,2)
plot(y,norminv(py),'bo','LineWidth',3);
hold on, plot(-4:0.1:4,-4:0.1:4,'r','LineWidth',3);
axis([-4 4 -4 4]); set(gca,'FontSize',22); 
title('$$ y \sim normpdf(0,1) $$','Interpreter','latex');
xlabel('std-norm quantiles'); ylabel('empirical quantiles');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
