clear all
close all

%% Fig 2.5A: Fitting LLR to rising sine-wave data

% create data
x=0:0.2:20; y=sin(x)+x./10+0.5*randn(size(x))+2;

% compute LLR fit for 3 different lambdas & lot
figure(5), hold off cla
subplot(2,2,1), plot(x,y,'ro','LineWidth',2), hold on
x0=0:0.1:20;
lam=[100 0.1 0.5]; clr={'k',[0.7 0.7 0.7],'b'};
for i=1:length(lam)
    y0=LocLinReg(x',y',x0',lam(i));
    plot(x0,y0,'Color',clr{i},'LineWidth',3);
end;
set(gca,'FontSize',20); box off; xlabel('\it{x}'); ylabel('\it{y}');
axis([0 20 0 6])
text(0.5,5.6,'$$ y=2+sin(x)+x/10+\epsilon $$','FontSize',20,'Interpreter','latex');
text(-5,6,'\bf{A}','FontSize',26,'Color','k')


%% Fig 2.5B: Locally constant fit to rising sine-wave data

subplot(2,2,2), plot(x,y,'ro','LineWidth',2), hold on
B=16;
for i=1:ceil(length(x)/B)
    r=(i-1)*B+(1:B); r=intersect(r,1:length(x));
    ym=mean(y(r));
    plot(x(r),zeros(1,length(r))+ym,'k','LineWidth',3);
end;
set(gca,'FontSize',20); box off; xlabel('\it{x}'); ylabel('\it{y}');
text(-5,6,'\bf{B}','FontSize',26,'Color','k')
axis([0 20 0 6])


%% Fig 2.5C-D: Fitting cubic splines to rising sine-wave data

% ... with 3 knots
subplot(2,2,3), plot(x,y,'ro','LineWidth',2), hold on
nknots=3; y0=CubicSpline(x',y',x0',nknots);
plot(x0,y0,'b','LineWidth',3);
pc=length(x)/(nknots+1); kn=zeros(1,nknots);
for i=1:nknots
    kn=x(round(i*pc)); plot([kn kn],[6 6],'k','LineWidth',2);
end;
set(gca,'FontSize',20); box off; xlabel('\it{x}'); ylabel('\it{y}');
text(-5,6,'\bf{C}','FontSize',26,'Color','k')
axis([0 20 0 6])

% ... with 9 knots
subplot(2,2,4), plot(x,y,'ro','LineWidth',2), hold on
nknots=9; y0=CubicSpline(x',y',x0',nknots);
plot(x0,y0,'b','LineWidth',3);
pc=length(x)/(nknots+1); kn=zeros(1,nknots);
for i=1:nknots
    kn=x(round(i*pc)); plot([kn kn],[6 6],'k','LineWidth',2);
end;
set(gca,'FontSize',20); box off; xlabel('\it{x}'); ylabel('\it{y}');
text(-5,6,'\bf{D}','FontSize',26,'Color','k')
axis([0 20 0 6])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
