function [cp,S,T1,T2,T3,T4,T5]=CUSUMstats(y,g)
% computes various CUSUM-based test stats as given in Husková & Kirch, 2008;
% Kirch 2007, 2008; Kirch & Kamgaing 2016 (see book for full refs).
% --- INPUTS
% y: time series
% g: exponent that weighs CUSUM term to remove center-bias
% --- OUTPUTS
% cp: estimated change point location
% S: weighted CUSUM curve (see eq. 8.9)
% T1-T5: various test stats as defined in the lit. (T1 should be the
% default choice)

N=length(y); k=1:N;
z=abs(cumsum(y-mean(y)))';
S=z.*(N./(k.*(N-k))).^g; S(end)=0;
[T1,cp]=max(S);
T2=max(z./sqrt(N));
t=k./N;
Q=z./(sqrt(N)*(t.*(1-t)).^(1/4)); Q(end)=0;
T3=max(Q);
T4=max(z)/N;
ml=mean(y(1:cp)); mr=mean(y(cp+1:end));
T5=mr-ml;   % estimated difference in mean across CP


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University