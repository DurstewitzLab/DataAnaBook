function outp=StateL(ModFN,SeqFN,DatFN)
% reads into MatLab results from MVNHMM output (MVNHMM Toolbox, S. Kirshner, 
% www.stat.purdue.edu/~skirshne/MVNHMM)
% ModFN: name of file with estimated model parameters
% SeqFN: name of file with est. Viterbi sequence
% DatFN: original data file
% outp: output structure containing all HMM fitting results

fid=fopen(ModFN,'r');
L=fgets(fid); while isempty(L) | L(1)=='#' | uint8(L(1))==10, L=fgets(fid); end;
p0=str2num(L);
L=fgets(fid); while isempty(L) | L(1)=='#' | uint8(L(1))==10, L=fgets(fid); end;
outp.ptrans=[];
Nst=length(p0);
for i=1:Nst
    outp.ptrans(i,:)=str2num(L);
    L=fgets(fid);
end;
outp.dpar=[];
for i=1:Nst
    for j=1:2
        while isempty(L) | L(1)=='#' | uint8(L(1))==10, L=fgets(fid); end;
        outp.dpar(i,j)=str2num(L);
        L=fgets(fid);
    end;
end;
fclose(fid);
outp.seq=load(SeqFN)+1;
x=load(DatFN);

outp.pst=[];
for i=1:Nst, outp.pst(i)=length(find(outp.seq==i))/length(outp.seq); end;
    
outp.Ppxs=[]; outp.Ppx=[]; dx=1e-1;
for i=1:length(x)
    if i==1, [a,s]=max(p0); else s=outp.seq(i-1); end;
    px=normpdf(x(i),outp.dpar(:,1),sqrt(outp.dpar(:,2)))';
    pxs=outp.ptrans(s,:).*px;
    outp.Ppxs(:,i)=pxs'./sum(pxs);
    outp.Ppx(:,i)=px.*outp.pst./sum(px.*outp.pst);
end;

% this MatLab parser: (c) D. Durstewitz, CIMH/ Heidelberg University
