clear all
close all

load FigsCh8data

%% Fig. 8.2: CUSUM-based test statistics for change points in time series

% fit sigmoid model to behavioral data
[par,res]=FitSigmoid(y);
amp=par(1);     % amplitude of sigmoid
slope=par(2);   % slope
day=par(3);     % change point (inflection point of sigmoid)
base=par(4);    % base rate
x=1:length(y);
ypred=amp./(1+exp(-slope.*(day-x)))+base;   % sigmoid prediction

% plot fitted sigmoid with data
subplot(2,2,1), hold off cla
plot(x,y,'bo',x,ypred,'r','LineWidth',2); box off
set(gca,'FontSize',20), axis([0 max(x)+1 -1 1]); ylabel('Performance');
legend('data','sigmoid fit','Location','NorthWest'); legend('boxoff');
title('Behav. performance');

%% plot CUSUM curve & test stats
subplot(2,2,2), hold off cla
cu=cumsum(y-mean(y));   % CUSUM
plot(x,cu,'LineWidth',3); box off
set(gca,'FontSize',20), axis([0 max(x)+1 -3.5 0.1]); ylabel('CUSUM(Perf)');
g=0; [cp,S,T1,T2,T3,T4,T5]=CUSUMstats(y',g);    % compute various test stats
hold on, plot(cp,cu(cp),'ro','LineWidth',2,'Markersize',10);
plot([cp cp],[cu(cp) cu(cp)+T1],'r','LineWidth',2);
title('CUSUM graph');
text(9.5,-1,'\color{red}S_C_P','FontSize',20)

%% perform block-permutation on residuals and determine CI for params.
yres=y-ypred;   % residuals from sigmoid
blL=3; Nbs=1000;
ybs=BlockPerm(yres,blL,Nbs,0); % could in principle be enumerated (6!)
sf=std(y)/std(yres);
for b=1:Nbs  % loop through all BS series
    disp(b);
    
    % compute test stats for BS series
    ybs0=sf*ybs{b}; % re-scale to original stdv
    [~,~,T1bs(b)]=CUSUMstats(ybs0',g);
    cuBS=cumsum(ybs0-mean(ybs0));
    subplot(2,2,3), plot(x,cuBS,'Color',[0.7 0.7 0.7],'LineWidth',1); hold on;
    
    % add on sigmoid again for deriving BS-based confidence bands
    ybs1=ypred+ybs{b};
    cpBS(b)=CUSUMstats(ybs1',g);
    parBS=FitSigmoid(ybs1);
    ypredBS=parBS(1)./(1+exp(-parBS(2).*(parBS(3)-x)))+parBS(4);
    subplot(2,2,4), plot(x,ypredBS,'Color',[0.7 0.7 0.7],'LineWidth',1); hold on;
end;
subplot(2,2,3), plot(x,cu,'b','LineWidth',3); box off
set(gca,'FontSize',20), axis([0 max(x)+1 -3.5 2.5]); xlabel('Day'); ylabel('CUSUM(Perf)');
pr=(length(find(T1bs>=T1))+1)/Nbs;
title('Bootstrapped CUSUM');

% count number of distinct BS series
YY=cell2mat(ybs); D=pdist(YY); D2=squareform(D);
r=[]; for i=1:length(ybs), r(i)=length(find(D2(i,:)==0)); end;
u=0; for i=1:max(r), u=u+length(find(r==i))/i; end;
text(12,-3,['p < ' num2str(ceil(1000*max(pr,1/u))/1000)],'FontSize',20);

subplot(2,2,4), plot(x,ypred,'b','LineWidth',3); box off;
set(gca,'FontSize',20), axis([0 max(x)+1 -1 1]); xlabel('Day'); ylabel('Sigmoid fit');
s=find(r==1);
SE=std(cpBS(s)); % compute only from unique BS series
title('CP confidence bands');
text(10,-0.8,['SE_C_P = ' num2str(round(100*SE)/100)],'FontSize',20);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University