clear all
close all

load FigsCh8data

%% Fig. 8.4: Fitting Hidden Markov Model (HMM) to in-vivo membrane pot. recordings
% uses MVNHMM Toolbox by S. Kirshner, www.stat.purdue.edu/~skirshne/MVNHMM

nst=2;  % number latent states
outp=runHMM(V(:,3),nst); % fit HMM to voltage data

% plot voltage data color-coded acc. to estimated state sequence
subplot(2,4,[1 2]), hold off cla
k=(outp.seq==1); plot(T(k),V(k,3),'b.'), hold on
k=(outp.seq==2); plot(T(k),V(k,3),'r.')
box off; set(gca,'FontSize',20), axis([T(1) T(end) -65 -40]); ylabel('V_m (mV)');
title('HMM 2 states');

% graph state transition prob. matrix
subplot(2,4,3), hold off cla
imagesc(outp.ptrans); colorbar
set(gca,'XTick',1:nst,'YTick',1:nst,'FontSize',20)
title('Transition mtx');

% plot emission distributions
subplot(2,4,4), hold off cla
vv=min(V(:,3)):0.1:max(V(:,3));
clr={'b','r','g'};
for s=1:nst
    emf=normpdf(vv,outp.dpar(s,1),sqrt(outp.dpar(s,2)));
    plot(vv,emf,clr{s},'LineWidth',3); hold on
end;
set(gca,'FontSize',20), box off
xlabel('V_m (mV)'); ylabel('emission density'); axis([min(vv) max(vv) 0 1]);
title('Emissions');

%% fit HMM with 3 states
nst=3;
outp=runHMM(V(:,3),nst);

% plot voltage data color-coded acc. to estimated state sequence
subplot(2,4,[5 6]), hold off cla
clr={'b','r','g'};
for i=1:nst, k=(outp.seq==i); plot(T(k),V(k,3),'.','Color',clr{i}), hold on; end;
box off; set(gca,'FontSize',20), axis([T(1) T(end) -65 -40]); xlabel('Time (s)'); ylabel('V_m (mV)');
title('HMM 3 states');

% graph state transition prob. matrix
subplot(2,4,7), hold off cla
imagesc(outp.ptrans); colorbar
set(gca,'XTick',1:nst,'YTick',1:nst,'FontSize',20)

% plot emission distributions
subplot(2,4,8), hold off cla
vv=min(V(:,3)):0.1:max(V(:,3));
for s=1:nst
    emf=normpdf(vv,outp.dpar(s,1),sqrt(outp.dpar(s,2)));
    plot(vv,emf,clr{s},'LineWidth',3); hold on
end;
set(gca,'FontSize',20), box off
xlabel('V_m (mV)'); ylabel('emission density'); axis([min(vv) max(vv) 0 1.2]);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University