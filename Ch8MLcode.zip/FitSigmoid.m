function [par,res]=FitSigmoid(y)
% simple sigmoid function fit
% y: time series
% par: vector containing estimated amplitude, slope, inflection point, and
% baseline parameters of sigmoid
% res: sum of squared residuals

s=-[0 0.5 100]; % start from 3 different initial conditions for slope
a1=mean(y(end-4:end)); % for initial estimate of amplitude
a0L=mean(y(1:2));   % initial baseline estimate
lb=[0 -100 0 min(y)];   % reasonable lower bounds on params.
ub=[max(y)-min(y) 100 length(y)+1 mean(y)];   % upper bounds on params.
for i=1:length(s)
    par0=[a1-a0L s(i) 1 a0L];   % initial param. vector
    [par1(i,:),res1(i)]=lsqcurvefit(@sigm,par0,1:length(y),y,lb,ub);
end;
[res,k]=min(res1);
par=par1(k,:);

function y0=sigm(par,x0)  % sigmoid func.
y0=par(1)./(1+exp(-par(2).*(par(3)-x0)))+par(4);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University