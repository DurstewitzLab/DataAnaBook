function outp=runHMM(data,Nst)
% runs the C code from the MVNHMM Toolbox by S. Kirshner, 
% www.stat.purdue.edu/~skirshne/MVNHMM
% (this wrapper created by D. Durstewitz, CIMH/ Heidelberg Univ.)
%
% data: time series
% Nst: number latent states
% outp: output structure:
%       .ptrans - matrix of transition prob.s
%       .dpar - emission distribution param.s (mean & var of Gaussian)
%       .seq - Viterbi sequence
%       .pst - a-priori state prob.s

Ldat=length(data);
pat='../HMM/';  % path where to find input and output files for MVNHMM
save([pat 'data.txt'],'data','-ascii','-double');

replace([pat 'learnHMM'],Nst,Ldat); % replace params. in HMM input file
replace([pat 'vibHMM'],Nst,Ldat);   % replace params. in Viterbi par. file
unix('/home/dd/bin/MLana/mvnhmm/bin/mvnhmm ../HMM/learnHMM');   % run C code for fitting HMM
unix('/home/dd/bin/MLana/mvnhmm/bin/mvnhmm ../HMM/vibHMM'); % run C code for Viterbi seq.
% read in results from MVNHMM output:
outp=StateL([pat 'ModParEstim.txt'],[pat 'seq.txt'],[pat 'data.txt']);


function fid=replace(fn,Nst,Ldat)
fid=fopen(fn,'r');
L{1}=fgets(fid); i=1;
while L{i}~=-1, i=i+1; L{i}=fgets(fid); end;
x=[];
for i=1:length(L)
    if strncmp(L{i},'num_states',10), x=[x i];
        L{i}=['num_states ' num2str(Nst)]; end;
    if strncmp(L{i},'data_sequence_length',20), x=[x i];
        L{i}=['data_sequence_length ' num2str(Ldat)]; end;
end;
fclose(fid);
fid=fopen(fn,'w');
for i=1:length(L)-1
    if ismember(i,x), fprintf(fid,'%s\n',L{i});
    else fprintf(fid,'%s',L{i}); end;
end;
fclose(fid);
