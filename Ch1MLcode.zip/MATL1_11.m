clear all
close all

%% compare parametric, exact and bootstrap-based test statistics on same data

% create 2 uniform but clearly different samples (violating normal-pdf
% assumptions!)
rand('state',6);
x1=round(50*(rand(1,13)-0.5))+1; x1(11:13)=[3 69 174];
x2=round(10*(rand(1,13)-0.5))+1;


%% evaluate parametric test stats on these non-normal samples (assuming
% paired or non-paired obs)
[~,p_t,~,tstat]=ttest(x1',x2')  % paired
[~,p_t2,~,t2stat]=ttest2(x1',x2')   % non-paired

%% evaluate exact test stats on these non-normal samples (assuming
% paired or non-paired obs)
p_s=signtest(x1',x2')  % paired
[p_W,~,Wstat]=ranksum(x1',x2')   % non-paired


%% create BS distribution for H0:m1=m2
Nbs=1000;
n=length(x1);
x12m=mean([x1 x2]);
torg=abs(mean(x1)-mean(x2))/sqrt((var(x1)+var(x2))/n);
x1_=x1-mean(x1)+x12m; x2_=x2-mean(x2)+x12m; % add on common mean
tbs=zeros(1,Nbs);
for b=1:Nbs % draw Nbs bootstrap samples
    z1=randsample(x1_,n,'true'); z2=randsample(x2_,n,'true');
    tbs(b)=abs(mean(z1)-mean(z2))/sqrt((var(z1)+var(z2))/n);
end;
prBS1m=length(find(tbs>=torg))/Nbs

%% create BS distributions for H0:F1=F2, and test for differences in both mean and variance
xcomb=[x1 x2];
tbs=zeros(1,Nbs); Fbs=tbs;
Forg=var(x1)/var(x2);
for b=1:Nbs
    z1=randsample(xcomb,n); z2=setdiff(xcomb,z1);
    tbs(b)=abs(mean(z1)-mean(z2))/sqrt((var(z1)+var(z2))/n);
    Fbs(b)=var(z1)/var(z2);
end;
prBS2m=length(find(tbs>=torg))/Nbs
prBSvar=length(find(Fbs>=Forg))/Nbs

% --> note that the BS tests suggest that the differences between the 2
% samples are due more to differences in variance rather than mean


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
