clear all
close all

%% Fig. 1.10: Rotating axes by PCA for BS sampling

% draw data from MV-normal pdf & plot
MU=[0 0]'; SIG=[1 1;1 2];
X=mvnrnd(MU,SIG,1000);
figure(11), hold off cla
plot(X(:,1),X(:,2),'bo','LineWidth',2);
set(gca,'FontSize',20);
xlabel('x_1'); ylabel('x_2'); box off
axis([-6 6 -6 6])
r1=round(1000*corr(X(:,1),X(:,2)))/1000;

%% rotate axes using PCA
[V,e]=eig(cov(X));  % eigenvectors of data COV-matrix
hold on, plot([0 4*V(1,1)],[0 4*V(2,1)],'r','LineWidth',3);
plot([0 -4*V(1,1)],[0 -4*V(2,1)],'r','LineWidth',3);
plot([0 4*V(1,2)],[0 4*V(2,2)],'r','LineWidth',3);
plot([0 -4*V(1,2)],[0 -4*V(2,2)],'r','LineWidth',3);
Z=X*V;  % transform coord. system
r2=round(1000*corr(Z(:,1),Z(:,2)))/1000;  % re-compute correlations between transformed coord.
text(0,-4,['corr(x_1,x_2) = ' num2str(r1)],'Color','b','FontSize',20);
text(0,-5,['corr(z_1,z_2) = ' num2str(r2)],'Color','r','FontSize',20);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University