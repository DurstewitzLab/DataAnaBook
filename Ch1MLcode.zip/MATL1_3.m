clear all
close all

%% Fig. 1.3: Optimization landscape for sigmoid function fit

randn('state',0);

figure(1)

% plot data drawn from sigmoid+Gaussian model
subplot(1,2,1), hold off cla
t=(1:100)./100;x=0.1*randn(1,100)+1./(1+exp(10*(0.65-t)));
plot(t,x,'bo','LineWidth',2)

% fit sigmoid model using second-order (Hessian) method
subplot(1,2,2), hold off cla
[v,Err,v1,v2,E]=NRonSigm(x,[35 0.85]);
xlim([0 40]); zlim([0 40]);

% add estimated sigmoid function to data graph
subplot(1,2,1), hold on
sigm=@(v,t0)1./(1+exp(v(1).*(v(2)-t0)));
x0=sigm(v(:,end),t);
plot(t,x0,'r','LineWidth',2);
v(:,end)
set(gca,'FontSize',20);
xlabel('x'); ylabel('y'); box off
axis([0 1 -0.3 1.2]);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University