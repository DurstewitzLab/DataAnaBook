clear all
close all

%% Fig. 1.6: Important probability densities

% chi2 distribution
figure(5)
subplot(1,3,1), hold off cla
x=0:0.01:20; df=[1 5 10];
clr={'b','r','g'};
for i=1:length(df)
    h=chi2pdf(x,df(i));
    plot(x,h,clr{i},'LineWidth',3); hold on;
end;
set(gca,'FontSize',24);
xlabel('x'); ylabel('\chi^2(x)'); box off
legend(['\it{df}=' num2str(df(1))],['\it{df}=' num2str(df(2))],['\it{df}=' num2str(df(3))]);
legend('boxoff')
title('$$ \chi^2 \ distribution $$','Interpreter','latex')
axis([0 20 0 0.5])

% t distribution
subplot(1,3,2), hold off cla
x=-10:0.01:10; df=[1 4 100];
clr={'b','r','g'};
for i=1:length(df)
    h=tpdf(x,df(i));
    plot(x,h,clr{i},'LineWidth',3); hold on;
end;
set(gca,'FontSize',24);
xlabel('x'); ylabel('\it{t}(x)'); box off
legend(['\it{df}=' num2str(df(1))],['\it{df}=' num2str(df(2))],['\it{df}=' num2str(df(3))]);
legend('boxoff')
title('$$ t \ distribution $$','Interpreter','latex')
axis([-10 10 0 0.5])

% F distribution
subplot(1,3,3), hold off cla
x=0:0.01:20; dfN=[5 10 60]; dfD=[5 50 30];
clr={'b','r','g'};
for i=1:length(df)
    h=fpdf(x,dfN(i),dfD(i));
    plot(x,h,clr{i},'LineWidth',3); hold on;
end;
set(gca,'FontSize',24);
xlabel('x'); ylabel('\it{F}(x)'); box off
legend(['\it{df}=(' num2str(dfN(1)) ',' num2str(dfD(1)) ')'], ...
    ['\it{df}=(' num2str(dfN(2)) ',' num2str(dfD(2)) ')'], ...
    ['\it{df}=(' num2str(dfN(3)) ',' num2str(dfD(3)) ')']);
legend('boxoff')
title('$$ F \ distribution $$','Interpreter','latex')
axis([0 5 0 1.5])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University