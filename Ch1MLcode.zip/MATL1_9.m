clear all
close all

%% Fig. 1.9: Different H0 vs. H1 distribution

figure(10), hold off cla
r=-3:0.1:10;
mu1=0; s1=1; mu2=2; s2=2;
plot(r,normpdf(r,mu1,s1),'b',r,normpdf(r,mu2,s2),'r','LineWidth',3);
yy=0:0.01:0.5;
hold on, plot(2*ones(1,length(yy)),yy,'g--','LineWidth',3);
set(gca,'FontSize',20);
xlabel('$$\hat{\rho}$$','Interpreter','latex'); ylabel('density'); box off
axis([min(r) max(r) 0 0.5])
pH0=round(1000*(1-normcdf(mu2,mu1,s1)))/1000;
pH1=round(1000*normcdf(mu1,mu2,s2))/1000;
legend('H_0 distribution','H_1 distribution'); legend('boxoff');
text(3,0.21,['$$Pr(\hat{\rho} \ge 2|H_0) \ \approx \ ' num2str(pH0) '$$'],'Interpreter','latex','FontSize',20)
text(3,0.28,['$$Pr(\hat{\rho} \le 0|H_1) \ \approx \ ' num2str(pH1) '$$'],'Interpreter','latex','FontSize',20);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University