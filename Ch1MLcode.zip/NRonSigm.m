function [v,Err,v1,v2,E]=NRonSigm(x,v0)
% Second-order method for estimating sigmoid func. params. from data x
% v0 = initial estimates
% outputs:
% - v= final estimate
% - v1,v2,Err= param. vectors and errors for visualizing Err surface 
% - E= final squared error

dErr=zeros(1,2);
t=(1:length(x))./length(x);
j=1; v(:,1)=v0;
H=zeros(2);
while j<2000
    % compute current func. fit and error
    m=sigm(v(:,j),t); q=exp(v(1,j)*(v(2,j)-t));
    E(j)=sum((x-m).^2);
    
    % determine gradients
    Z=2*(x-m).*m.^2.*q;
    dErr(1)=sum(Z.*(v(2,j)-t));
    dErr(2)=sum(Z.*v(1,j));
    
    % compute Hessian
    S1=x.*(m.^2).*q-(m.^3).*q; S2=3.*(m.^4).*(q.^2)-2.*x.*(m.^3).*(q.^2);
    M=S1+S2;
    H(1,1)=2*(v(2,j)-t).^2*M';
    H(2,2)=2*v(1,j)^2*sum(M);
    H(1,2)=2*sum(S1+v(1,j).*(v(2,j)-t).*M);
    H(2,1)=H(1,2);
    if rank(H)<2, break; end;   % should have an inverse
    
    % update estimates using inverse Hessian forced to be positive-semidefinite
    % (see Pascanu et al. 2014,arXiv:1405.4604v2)
    [U,L]=eig(H);
    v(:,j+1)=v(:,j)-0.01*(U*abs(L)*U^-1)^-1*dErr';
    
    % display current error and param.s
    disp([E(j) v(:,j)']);
    j=j+1;
end;
E(j)=sum((x-m).^2);


%% plot 3D error surface over model param.s
v1=0:0.1:100;
v2=0:0.01:1;
for i=1:length(v1)
    for j=1:length(v2)
        m=sigm([v1(i) v2(j)],t);
        Err(i,j)=sum((x-m).^2);
    end;
end;
hold off cla
mesh(v1'*ones(1,length(v2)),ones(length(v1),1)*v2,Err)
hold on, plot3(v(1,:),v(2,:),1.01*E,'r','LineWidth',6)
set(gca,'FontSize',20);
xlabel('slope (\beta)'); ylabel('threshold (\theta)'); zlabel('Error');


%% sigmoid function    
function x0=sigm(v,t0)
x0=1./(1+exp(v(1).*(v(2)-t0)));
end

end

%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University