clear all
close all

%% Fig. 1.8: Convergence of EDF to normal CDF

x=-3:0.01:3; n1=10; n2=200; % draw n1 or n2 samples from normal distrib.
y1=sort(randn(1,n1),'ascend'); y2=sort(randn(1,n2),'ascend');
figure(9), hold off cla
plot(y2,(1:n2)./n2,'mo','LineWidth',2); % plot EDF of samples
hold on, plot(y1,(1:n1)./n1,'r*','MarkerSize',10,'LineWidth',3);
plot(x,normcdf(x,0,1),'b','LineWidth',3);   % plot resp. normal CDF
set(gca,'FontSize',20);
xlabel('\it{x}'); ylabel('EDF / norm-CDF'); box off
axis([min(x) max(x) 0 1])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University