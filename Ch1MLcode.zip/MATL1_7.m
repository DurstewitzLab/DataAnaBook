clear all
close all

%% Fig. 1.7: Box-Cox transform

N=10000; bw=0.1; x=-3:bw:6;
y=gamrnd(2,2,N,1);  % draw from a gamma distribution

% Box-Cox-transform across range of parameter q
q=0:0.1:3; z=cell(1,length(q));
z{1}=log(y);
for i=2:length(q), z{i}=(y.^q(i)-1)./q(i); end;

% compute log-likelihood
LL=zeros(1,length(q));
for i=1:length(q), LL(i)=sum(-log(sqrt(2*pi)*std(z{i}))+(1/2)*zscore(z{i}).^2); end;

% plot LL graph & original & optimal transformed distribution
figure(8), hold off cla
subplot(1,2,1), plot(q,LL,'LineWidth',3);
set(gca,'FontSize',20);
xlabel('\it{q}'); ylabel('log-like(\it{q})'); box off; xlim([min(q) max(q)]);
horg=histc(y,x)./(length(y)*bw);
[~,r]=max(LL); hboxcox=histc(z{r},x)./(length(z{r})*bw);
hnrm=normpdf(x,mean(z{r}),std(z{r}));
subplot(1,2,2), plot(x,horg,'co','LineWidth',2);
hold on, plot(x,hboxcox,'bo','LineWidth',2);
plot(x,hnrm,'r','LineWidth',3);
set(gca,'FontSize',20);
xlabel('\it{x}'); ylabel('density'); box off; axis([min(x) max(x) 0 0.6]);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University