clear all
close all

%% Fig. 1.5: CLT demo & normal pdf

% draw numbers from exponential distribution & plot
N=10e3; bw=0.1; x=0:bw:10; y=exprnd(1,N,1);
h=histc(y,x)./(length(y)*bw);
figure(4), subplot(1,2,1), hold off cla
plot(x,h,'bo','MarkerSize',5,'LineWidth',2);
set(gca,'FontSize',20); box off; xlabel('y'); ylabel('emp. dens.');
title('$$ y \sim exppdf(1) $$','Interpreter','latex');

%% take sums of m numbers, plot distribution, compare to normal pdf
m=10; x=-5:bw:5;
z=sum(reshape(y,m,N/m));
mu=mean(z); s=std(z); z=(z-mu)/s;   % standardize (--> zscore)
hemp=histc(z,x)./(length(z)*bw);
hnrm=normpdf(x,0,1);
subplot(1,2,2), hold off cla
plot(x,hemp,'bo','MarkerSize',5,'LineWidth',2)
hold on, plot(x,hnrm,'r','LineWidth',3);
set(gca,'FontSize',20); box off; xlabel('z'); ylabel('emp./norm. dens.');
title('$$ z=\sum(y-\bar{y})/s $$','Interpreter','latex');
axis([-5 5 0 0.6]);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University