clear all
close all

%% Fig. 1.2: bell-shaped data with linear and quadratic fit

% generate data from quadratic model with Gaussian noise
x=(0:0.1:6)';
y=12-(x-3).^2+randn(length(x),1);
figure(2), hold off cla
plot(x,y,'bo','MarkerSize',5,'LineWidth',2)
set(gca,'FontSize',20); box off; xlabel('x'); ylabel('y');

% fit linear model to data
X=[ones(length(x),1) x];
b=(X'*X)^-1*X'*y; ypred=X*b;
hold on, plot(x,ypred,'g','LineWidth',3);

% fit quadratic model to data
X=[ones(length(x),1) x (x.*x)];
b=(X'*X)^-1*X'*y; ypred=X*b;
hold on, plot(x,ypred,'r','LineWidth',3);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University