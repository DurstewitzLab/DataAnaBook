clear all
close all

%% Fig. 1.4: Nasty optimization function
% LL of Ricker map with Poisson observation process (borrowed from Wood 2010, Nature)

% generate data from Ricker map latent state model in chaotic regime
s=0.3; r=exp(3.8); phi=0.1; T=1000;
x0=rand*2;
eps=s*randn(1,T); x=zeros(1,T); x(1)=x0;
y=zeros(1,T); y(1)=poissrnd(phi*x(1));
for t=2:1000
    x(t)=r*x(t-1)*exp(-x(t-1)+eps(t));
    y(t)=poissrnd(phi*x(t));
end;

LL0=-T/2*(log(var(eps,1))+log(2*pi)+1); % LL-contrib from Gaussian term 
% (assumed to be constant and known here)


%% compute and plot joint LL across {eps,y} as func. of r
rL=20:150; LL=zeros(1,length(rL))+LL0+log(poisspdf(y(1),phi*x(1)));
for i=1:length(rL)
    x=zeros(1,T); x(1)=x0;
    for t=2:1000
        x(t)=rL(i)*x(t-1)*exp(-x(t-1)+eps(t));
        LL(i)=LL(i)+log(poisspdf(y(t),phi*x(t)));
    end;
end;
figure(3), hold off cla
plot(log(rL),LL,'LineWidth',3);
set(gca,'FontSize',20); box off; xlabel('log(r)'); ylabel('log \it{L(r)}');
axis([2.9 5.1 -10000 0])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University