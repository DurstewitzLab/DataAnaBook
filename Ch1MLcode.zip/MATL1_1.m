clear all
close all

%% Fig. 1.1: samples and popluation

figure(1), hold off cla
viscircles([0 0],1,'LineWidth',4,'EdgeColor','b')
hold on, viscircles([-2 0],5,'LineWidth',4,'EdgeColor','b')
text(-0.7,-0.1,'\bf{\mu}, \bf{\sigma}','FontSize',28,'Color','b')
text(-0.7,0.1,'\^    \^','FontSize',20,'Color','b')
text(-3.5,2.3,'\bf{\mu}, \bf{\sigma}','FontSize',28,'Color','b')
text(-4,3.5,'\bf{population}','FontSize',28,'Color','b')
text(-1.2,1.5,'\bf{sample}','FontSize',28,'Color','b')
axis off, box off


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
