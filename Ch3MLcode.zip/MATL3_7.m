clear all
close all

load ExampleDistrib   % example data file created by MATL3_1


%% Fig 3.6: LDA with polynomial basis expansion 

figure(6), hold off cla

% select data
i=3;
bwx=0.1; bwy=0.1; x1=-10:bwx:10; y1=-5:bwy:8;
n1=length(x1); n2=length(y1);
X0=zeros(n1*n2,2); X0(:,1)=repmat(x1',n2,1);
xx=repmat(y1,n1,1); X0(:,2)=xx(1:end)';
K=length(X3);
X3{i}=X0';
for i=1:K+1 % create multinomial basis expansion up to 3rd order
    X3{i}(3,:)=X3{i}(1,:).^2; X3{i}(4,:)=X3{i}(2,:).^2;
    X3{i}(5,:)=X3{i}(1,:).*X3{i}(2,:);
    X3{i}(6,:)=X3{i}(1,:).^3; X3{i}(7,:)=X3{i}(2,:).^3;
    X3{i}(8,:)=X3{i}(1,:).*X3{i}(1,:).*X3{i}(2,:);
    X3{i}(9,:)=X3{i}(1,:).*X3{i}(2,:).*X3{i}(2,:);
end;
X0=X3{K+1}'; X3=X3(1:K);
% compute pooled within-class cov matrix C and mean vectors xm of expanded data
C=zeros(9); xm=zeros(9,K); N=cellfun(@length,X3);
for i=1:K, C=C+(N(i)-1)*cov(X3{i}'); xm(:,i)=mean(X3{i}'); end;
C=C./(sum(N)-K);

%% plot data and decision surfaces from expanded classifier in original 2D space
cmp=colormap('jet');
clr={cmp(24,:),cmp(40,:)};
for i=1:n1*n2
    D=-1/2*diag((ones(K,1)*X0(i,:)-xm')*C^-1*(ones(K,1)*X0(i,:)-xm')')+ ...
        [log(N(1)/sum(N)) log(N(2)/sum(N))]';   % LDA decision function
    [~,r]=max(D);
    rectangle('Position',[X0(i,1)-bwx/2,X0(i,2)-bwy/2,bwx,bwy], ...
        'FaceColor',clr{r},'EdgeColor',clr{r});
end;
clr2={'b.','g.'};
hold on; for i=1:K, plot(X3{i}(1,:),X3{i}(2,:),clr2{i},'MarkerSize',10); end;
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2'); axis([-7 7 -3 8])

%% compute relative classific. error from expanded LDA classifier
Err=0; cl=ones(sum(N),1); cl(N(1)+1:end)=2; XX=[X3{1} X3{2}];
for i=1:sum(N)
    D=-1/2*diag((ones(K,1)*XX(:,i)'-xm')*C^-1*(ones(K,1)*XX(:,i)'-xm')')+ ...
        [log(N(1)/sum(N)) log(N(2)/sum(N))]';
    [~,r]=max(D); Err=Err+(r~=cl(i));
end;
Err=Err/sum(N);
title(['Rel. Class. Err. = ' num2str(round(Err*1e3)*1e-3)]);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
