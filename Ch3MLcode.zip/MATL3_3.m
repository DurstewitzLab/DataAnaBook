clear all
close all

%% Fisher discriminant space

% example data
X{1}=randn(10,5); X{2}=randn(20,5)+1; X{3}=randn(30,5)+1; XX=cell2mat(X');

% compute between (B) and within (W) covariance matrices
B=zeros(5); W=zeros(5);
for i=1:3
    nk=size(X{i},1);
    B=B+nk*(mean(X{i})-mean(XX))'*(mean(X{i})-mean(XX));
    W=W+nk*cov(X{i},1);
end;
B=B./size(XX,1);
W=W./size(XX,1);
T=cov(XX,1);    % note that T=B+W

[V,E]=eig(W^-1*B);  % note there are only K-1=2 non-zero eigenvalues

% --> see MATL6_1 for graphical illustration


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
