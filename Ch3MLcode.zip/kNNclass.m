function ypred=kNNclass(X0,X,y,k,opt)
if nargin<5 || isempty(opt), opt='class'; end;
% k nearest neighbors regression/ classification
% --- INPUTS
% X0: Mxp matrix of query points
% X: Nxp matrix of data points
% y: Nx1 vector of class labels or scalar outputs
% k: number of neighbors
% opt: if set to 'class' gives classifier, otherwise regression
% --- OUTPUTS
% ypred: Mx1 vector of predicted outputs/ class labels

M=size(X0,1); N=size(X,1);
ypred=zeros(M,1);
for i=1:M
    % retrieve k-NN of current query point
    d=sqrt(sum((ones(N,1)*X0(i,:)-X).^2,2));
    [~,r]=sort(d,'ascend');
    % perform classification/ regression
    if strcmp(opt,'class'), ypred(i)=mode(y(r(1:k)));
    else ypred(i)=mean(y(r(1:k))); end;
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
