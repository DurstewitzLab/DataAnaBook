function [X1,X2,X3]=CreateDistrib(N,s)

randn('state',s);

% create example distributions:
% - 3 MV Gaussians with identical cov, well separable
mu1={[0;0],[-4;4],[4;5]};    % group means
SI1={[1 0.2;0.2 1],[1 0.2;0.2 1],[1 0.2;0.2 1]}; % cov-matrices
X1=cell(1,3); for i=1:3, X1{i}=mvnrnd(mu1{i},SI1{i},N)'; end;
% - 3 MV Gaussians with unequal cov, not well separable
mu2={[0;0],[-3;3],[3;3]};    % group means
SI2={[4 1.2;1.2 1.5],[2 0;0 3],[1 1;1 4]}; % cov-matrices
X2=cell(1,3); for i=1:3, X2{i}=mvnrnd(mu2{i},SI2{i},N)'; end;
% - 2 nonlinear classes
X3{1}=mvnrnd([0 0]',[6 0;0 3],5*N)';
k=(X3{1}(2,:)<X3{1}(1,:).^2); X3{1}=X3{1}(:,k);
X3{2}=mvnrnd([0 0]',[6 0;0 3],10*N)';
k=(X3{2}(2,:)>X3{2}(1,:).^2); X3{2}=X3{2}(:,k);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
