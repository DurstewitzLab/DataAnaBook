clear all
close all

load ExampleDistrib   % example data file created by MATL3_1


%% Fig 3.2: QDA decision boundaries

figure(2), hold off cla

subplot(1,3,1), hold off cla, [x1,x2L,x2U,Err1]=QDAdecbd(X1); axis([-7 7 -3 8])
r=find(x2L{1,2}>x2L{2,3} & imag(x2L{1,2})==0);
plot(x1(r),x2L{1,2}(r),'k','LineWidth',2);
r=find(x2L{1,2}<=x2L{2,3} & imag(x2L{2,3})==0);
plot(x1(r),x2L{2,3}(r),'k','LineWidth',2);
r=find(imag(x2U{2,3})==0);
plot(x1(r),x2U{2,3}(r),'k','LineWidth',2);
r=find(x2L{1,2}>x2U{1,3} & imag(x2U{1,3})==0);
plot(x1(r),x2U{1,3}(r),'k','LineWidth',2);

subplot(1,3,2), hold off cla, [x1,x2L,x2U,Err2]=QDAdecbd(X2); axis([-8 8 -4 10])
r=find(x2U{1,2}<x2U{1,3} & imag(x2U{1,2})==0);
plot(x1(r),x2U{1,2}(r),'k','LineWidth',2);
r=find(imag(x2U{1,3})==0 & x1>0.596);
plot(x1(r),x2U{1,3}(r),'k','LineWidth',2);
r=find(x2U{1,3}<x2L{2,3} & imag(x2L{2,3})==0);
plot(x1(r),x2L{2,3}(r),'k','LineWidth',2);

subplot(1,3,3), hold off cla, [x1,x2L,x2U,Err3]=QDAdecbd(X3); axis([-10 10 -5 8])
r=find(imag(x2U{1,2})==0);
plot(x1(r),x2U{1,2}(r),'k','LineWidth',2);
r=find(imag(x2L{1,2})==0);
plot(x1(r),x2L{1,2}(r),'k','LineWidth',2);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
