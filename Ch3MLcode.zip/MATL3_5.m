clear all
close all

load ExampleDistrib   % example data file created by MATL3_1


%% Fig 3.4: kNN decision boundaries (see fig. legend in text for details)

figure(4), hold off cla
bwx=0.1; bwy=0.1; x1=-10:bwx:10; y1=-5:bwy:10;
n1=length(x1); n2=length(y1);
X0=zeros(n1*n2,2); X0(:,1)=repmat(x1',n2,1);
xx=repmat(y1,n1,1); X0(:,2)=xx(1:end)';

subplot(2,2,1)
k=5;
cl=zeros(3*N,1); cl(N+1:2*N)=1; cl(2*N+1:3*N)=2;
ypred=kNNclass(X0,[X2{1} X2{2} X2{3}]',cl,k);
cmp=colormap('jet'); clr={cmp(24,:),cmp(35,:),cmp(48,:)};
for i=1:n1*n2
    rectangle('Position',[X0(i,1)-bwx/2,X0(i,2)-bwy/2,bwx,bwy], ...
        'FaceColor',clr{ypred(i)+1},'EdgeColor',clr{ypred(i)+1});
end;
clr2={'b.','g.','r.'};
hold on; for i=1:length(X2), plot(X2{i}(1,:),X2{i}(2,:),clr2{i},'MarkerSize',10); end;
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2'); axis([-7 7 -3 8])
title(['k = ' num2str(k)]);

subplot(2,2,2)
k=50;
ypred=kNNclass(X0,[X2{1} X2{2} X2{3}]',cl,k);
for i=1:n1*n2
    rectangle('Position',[X0(i,1)-bwx/2,X0(i,2)-bwy/2,bwx,bwy], ...
        'FaceColor',clr{ypred(i)+1},'EdgeColor',clr{ypred(i)+1});
end;
hold on; for i=1:length(X2), plot(X2{i}(1,:),X2{i}(2,:),clr2{i},'MarkerSize',10); end;
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2'); axis([-7 7 -3 8])
title(['k = ' num2str(k)]);

subplot(2,2,3)
k=5;
m1=length(X3{1}); m2=length(X3{2}); cl=zeros(m1+m2,1); cl(m1+1:m1+m2)=1;
ypred=kNNclass(X0,[X3{1} X3{2}]',cl,k);
cmp=colormap('jet'); clr={cmp(24,:),cmp(35,:),cmp(48,:)};
for i=1:n1*n2
    rectangle('Position',[X0(i,1)-bwx/2,X0(i,2)-bwy/2,bwx,bwy], ...
        'FaceColor',clr{ypred(i)+1},'EdgeColor',clr{ypred(i)+1});
end;
clr2={'b.','g.','r.'};
hold on; for i=1:length(X3), plot(X3{i}(1,:),X3{i}(2,:),clr2{i},'MarkerSize',10); end;
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2'); axis([-10 10 -5 8])
title(['k = ' num2str(k)]);

subplot(2,2,4)
k=50;
ypred=kNNclass(X0,[X3{1} X3{2}]',cl,k);
for i=1:n1*n2
    rectangle('Position',[X0(i,1)-bwx/2,X0(i,2)-bwy/2,bwx,bwy], ...
        'FaceColor',clr{ypred(i)+1},'EdgeColor',clr{ypred(i)+1});
end;
clr2={'b.','g.','r.'};
hold on; for i=1:length(X3), plot(X3{i}(1,:),X3{i}(2,:),clr2{i},'MarkerSize',10); end;
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2'); axis([-10 10 -5 8])
title(['k = ' num2str(k)]);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
