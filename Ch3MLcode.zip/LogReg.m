function [p,b,LL,Err]=LogReg(X,y)
% fitting binary logistic regression model
% --- INPUTS
% X: Nxq matrix of regressors
% y: Nx1 vector of {0,1} outputs (class-memberships)
% --- OUTPUTS
% p: Nx1 vector of class posterior prob.s
% b: regression coefficients
% LL: model log-likelihood across iterations
% Err: rel. classification error

tol=1e-8;   % tolerance for log-likelihood convergence
eps=1e-8;   % regularization factor to avoid singularity of W
[N,q]=size(X);
X=[ones(N,1) X];    % add column of 1's

%% iterate Newton-Raphson steps
j=1; dLL=1e8;
p=zeros(N,1)+0.5;   % initialize p(Ci|xi)
b=zeros(q+1,1);
LL=[]; LL(1)=-N*log(2);
while dLL>tol
    % update parameters of model
    W=diag(p.*(1-p))+eps*eye(N);
    z=X*b+W^-1*(y-p);
    b=(X'*W*X)^-1*X'*W*z;
    % estimate p(Ci=k|xi,b)
    v=exp(X*b);
    p=v./(1+v);
    % compute log-likelihood
    j=j+1; LL(j)=sum(y.*(X*b)-log(1+exp(X*b)));
    dLL=LL(j)-LL(j-1);
end;
% relative error
ypred=zeros(size(y)); ypred(p>0.5)=1;
Err=sum(abs(y-ypred))/N;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
