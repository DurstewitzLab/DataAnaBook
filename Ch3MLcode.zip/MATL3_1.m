clear all
close all

% create example data sets
N=200;
[X1,X2,X3]=CreateDistrib(N,0);
save ExampleDistrib X1 X2 X3 N


%% Fig 3.1: LDA decision boundaries

figure(1), hold off cla
subplot(1,3,1), [x1_1,x2_1,Err1]=LDAdecbd(X1); axis([-7 7 -3 8])
subplot(1,3,2), [x1_2,x2_2,Err2]=LDAdecbd(X2); axis([-8 8 -4 10])
subplot(1,3,3), [x1_3,x2_3,Err3]=LDAdecbd(X3); axis([-10 10 -5 8])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
