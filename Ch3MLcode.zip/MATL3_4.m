clear all
close all

load ExampleDistrib   % example data file created by MATL3_1


%% Fig 3.3: Logistic regression decision boundaries

figure(3), hold off cla
x1=-10:0.001:10;

% example 1
y=zeros(2*N,1); y(N+1:end)=1;
[p,b,LL,Err]=LogReg([X1{1} X1{3}]',y);
x2=(-b(1)-b(2)*x1)./b(3);
subplot(1,3,1), plot(X1{1}(1,:),X1{1}(2,:),'b.',X1{3}(1,:),X1{3}(2,:),'r.','MarkerSize',10);
hold on; plot(x1,x2,'k','LineWidth',2); axis([-7 7 -3 8])
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2');
title(['Rel. Class. Err. = ' num2str(round(Err*1e3)*1e-3)]);

% example 2
y=zeros(2*N,1); y(N+1:end)=1;
[p,b,LL,Err]=LogReg([X2{1} X2{3}]',y);
x2=(-b(1)-b(2)*x1)./b(3);
subplot(1,3,2), plot(X2{1}(1,:),X2{1}(2,:),'b.',X2{3}(1,:),X2{3}(2,:),'r.','MarkerSize',10);
hold on; plot(x1,x2,'k','LineWidth',2); axis([-8 8 -4 10])
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2');
title(['Rel. Class. Err. = ' num2str(round(Err*1e3)*1e-3)]);

% example 3
n1=length(X3{1}); n2=length(X3{2});
y=zeros(n1+n2,1); y(n1+1:end)=1;
[p,b,LL,Err]=LogReg([X3{1} X3{2}]',y);
x2=(-b(1)-b(2)*x1)./b(3);
subplot(1,3,3), plot(X3{1}(1,:),X3{1}(2,:),'b.',X3{2}(1,:),X3{2}(2,:),'g.','MarkerSize',10);
hold on; plot(x1,x2,'k','LineWidth',2); axis([-10 10 -5 8])
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2');
title(['Rel. Class. Err. = ' num2str(round(Err*1e3)*1e-3)]);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
