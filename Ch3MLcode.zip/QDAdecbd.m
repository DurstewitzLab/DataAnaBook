function [x1,x2L,x2U,Err]=QDAdecbd(X)
% compute quadratic decision boundaries in 2D space
% X: cell array of 2D data matrices from K classes
% x1: x-coordinates of boundaries
% x2L: (K-1)xK cell array of y-coord. of lower-half boundaries
% x2U: (K-1)xK cell array of y-coord. of upper-half boundaries
% Err: relative classification error

K=length(X); p=size(X{1},1); N=cellfun(@length,X);

%% plot example data
clr={'b.','g.','r.'};
for i=1:K, plot(X{i}(1,:),X{i}(2,:),clr{i},'MarkerSize',10); hold on; end;
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2');

%% estimate K cov-matrices & class-means
C=cell(1,K); xm=zeros(p,K);
for i=1:K, C{i}=cov(X{i}'); xm(:,i)=mean(X{i}'); end;

% a-priori probs
apr=N./sum(N);

%% compute quadratic decision boundaries
x1=-10:0.001:10; x2L=cell(K-1,K); x2U=x2L;
for i=1:K-1
    for j=i+1:K
        A=1/2*(C{j}^-1-C{i}^-1);    % A(1,2)=A(2,1)
        B=C{i}^-1*xm(:,i)-C{j}^-1*xm(:,j);
        H=1/2*(xm(:,j)'*C{j}^-1*xm(:,j)-xm(:,i)'*C{i}^-1*xm(:,i))+ ...
            log(apr(i))-log(apr(j))-log(det(C{i}))/2+log(det(C{j}))/2;
        a=((A(1,2)+A(2,1)).*x1+B(2))./A(2,2);
        b=(A(1,1)*x1.^2+B(1)*x1+H)./A(2,2);
        x2L{i,j}=-a./2-sqrt(a.^2./4-b);
        x2U{i,j}=-a./2+sqrt(a.^2./4-b);
    end;
end;

%% compute classification error
Err=0;
for i=1:K
    D=zeros(K,N(i));
    for j=1:K
        v=X{i}-xm(:,j)*ones(1,N(i));
        D(j,:)=diag(-1/2*v'*C{j}^-1*v-1/2*log(det(C{j}))+log(apr(j)))';
    end;
    [~,m]=max(D);
    Err=Err+sum(m~=i);
end;
Err=Err/sum(N);
title(['Rel. Class. Err. = ' num2str(round(Err*1e3)*1e-3)]);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
