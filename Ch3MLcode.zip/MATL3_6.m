clear all
close all

load ExampleDistrib   % example data file created by MATL3_1


%% Fig 3.5: Illustration of maximum margin principle

figure(5), hold off cla
% compute support vectors for data example using linear kernel
lam=0;  % tradeoff between misclassification rate & margin criterion
cl=zeros(40,1); cl(21:end)=1;   % class labels
XX=[X1{1}(:,1:20) X1{3}(:,1:20)]';
SVMstruc=svmtrain(XX,cl,'kernel_function','linear','kktviolationlevel',lam,'autoscale',0);
SV=SVMstruc.SupportVectors; a=SVMstruc.Alpha; b0=SVMstruc.Bias;
b=SV'*a;    % determine classifier from support vectors
x1=-10:0.1:10; x2=(-b0-b(1)*x1)./b(2);  % compute decision surface

%% plot everything
subplot(1,2,2)
plot(XX(1:20,1),XX(1:20,2),'b.',XX(21:40,1),XX(21:40,2),'r.','MarkerSize',20);
hold on; plot(x1,x2,'k','LineWidth',2); axis([-2.5 8 -2.5 8]);
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2');
d=(SV*b+b0)./norm(b); y1=SV(1,:)'-d(1)*b./norm(b); y2=SV(2,:)'-d(2)*b./norm(b);
plot([SV(1,1) y1(1)],[SV(1,2) y1(2)],'k--',[SV(2,1) y2(1)],[SV(2,2) y2(2)],'k--','LineWidth',2);
text(2.5,1.1,'SV_1','FontSize',20); text(3.3,2.8,'SV_2','FontSize',20);

subplot(1,2,1)
plot(XX(1:20,1),XX(1:20,2),'b.',XX(21:40,1),XX(21:40,2),'r.','MarkerSize',20);
hold on; plot(x1,x2,'k','LineWidth',2); axis([1 4 1 4]);
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2');
plot([SV(1,1) y1(1)],[SV(1,2) y1(2)],'k--','LineWidth',2);
plot(y1(1),y1(2),'k.','MarkerSize',20);
r=find(x1==3.5); plot(x1(r),x2(r),'k.','MarkerSize',20);
text(2.2,1.2,'x_0','FontSize',20); text(2.7,2.7,'x_T','FontSize',20);
text(3.5,2.35,'x_K','FontSize',20);
text(2.7,3.35,'\beta','FontSize',20);

annotation(gcf,'arrow',[0.273547094188377 0.295591182364729],[0.601380952380952 0.704761904761905],'LineWidth',2);
annotation(gcf,'arrow',[0.273547094188377 0.317635270541082],[0.603761904761905 0.804761904761905],'LineWidth',2);
annotation(gcf,'arrow',[0.273547094188377 0.339679358717435],[0.603761904761905 0.904761904761905],'LineWidth',2);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
