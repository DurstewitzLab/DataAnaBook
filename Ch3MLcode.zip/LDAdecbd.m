function [x1,x2,Err]=LDAdecbd(X)
% compute linear decision boundaries in 2D space
% X: cell array of 2D data matrices from K classes
% x1: x-coordinates of boundaries
% x2: (K-1)xK cell array of y-coord. of boundaries
% Err: relative classification error

K=length(X); p=size(X{1},1); N=cellfun(@length,X);

%% plot data
clr={'b.','g.','r.'};
for i=1:K, plot(X{i}(1,:),X{i}(2,:),clr{i},'MarkerSize',10); hold on; end;

%% estimate common pooled cov-matrix & class-means
C=zeros(p); xm=zeros(p,K);
for i=1:K, C=C+(N(i)-1)*cov(X{i}'); xm(:,i)=mean(X{i}'); end;
C=C./(sum(N)-K);

% a-priori probs
apr=N./sum(N);

%% compute linear decision boundaries
x1=-10:0.01:10; x2=cell(K-1,K);
for i=1:K-1
    for j=i+1:K
        A=C^-1*(xm(:,i)-xm(:,j));
        B=-1/2*(xm(:,i)'*C^-1*xm(:,i)-xm(:,j)'*C^-1*xm(:,j))+ ...
            log(apr(i))-log(apr(j));
        x2{i,j}=-(A(1).*x1+B)./A(2);
    end;
end;

% add them to data graph
if K>2
    r=find(x2{1,2}<x2{1,3}); plot(x1(r),x2{1,2}(r),'k','LineWidth',2);
    r=find(x2{1,2}>=x2{1,3}); plot(x1(r),x2{1,3}(r),'k','LineWidth',2);
    r=find(x2{2,3}>=x2{1,2}); plot(x1(r),x2{2,3}(r),'k','LineWidth',2);
else
    plot(x1,x2{1,2},'k','LineWidth',2);
end;
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2');

%% compute classification error
Err=0;
for i=1:K
    D=zeros(K,N(i));
    for j=1:K
        v=X{i}-xm(:,j)*ones(1,N(i));
        D(j,:)=diag(-1/2*v'*C^-1*v+log(apr(j)))';
    end;
    [~,m]=max(D);
    Err=Err+sum(m~=i);
end;
Err=Err/sum(N);
title(['Rel. Class. Err. = ' num2str(round(Err*1e3)*1e-3)]);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
