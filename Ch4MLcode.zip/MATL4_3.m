clear all
close all


%% Fig 4.3: K-fold cross-validation for LLR, for K=5,10,N

% determine CVE across range of LLR kernel widths and K's
x=0:0.2:20;
s=0.5;  % stdv of Gaussian noise
N=100;  % number of samples
lam=0.1:0.1:4;  % range of LLR kernel widths to test
m=length(x);
K=[5 10 m]; % range for K-fold CV
CVE=cell(1,length(K));
for n=1:N
    disp(n);
    randn('state',n);
    y=sin(x)+x./10+s*randn(size(x))+2;  % sample from rising sine data
    for k=1:length(K)
        for l=1:length(lam)
            AllIdc=1:m; cve=zeros(1,K(k));
            for r=1:K(k)    % K-fold CV
                if length(AllIdc)==1; w=AllIdc;
                else w=randsample(AllIdc,round(m/K(k))); end;
                AllIdc=setdiff(AllIdc,w);
                nw=setdiff(1:m,w);
                y0=LocLinReg(x(nw)',y(nw)',x(w)',lam(l));   % fit LLR model
                cve(r)=sum((y(w)-y0').^2);
            end;
            CVE{k}(n,l)=sum(cve)/(K(k)*round(m/K(k)));
        end;
    end;
end;

%% plot CVE curves for different K
figure(3), hold off cla
subplot(1,2,1)
clr={[0.5 0.5 0.5],[0.7 0.7 0.7],[0 0 0]};
for k=1:length(K)
    plot(lam,mean(CVE{k}),'Color',clr{k},'LineWidth',3); hold on
end;
box off; axis([0 max(lam) 0.2 0.8]); set(gca,'FontSize',24); 
xlabel('\lambda','FontSize',24); ylabel('CVE','FontSize',24);
legend('K=5','K=10','K=N','Location','SouthEast')
legend('boxoff','FontSize',24,'Location','SouthEast')

%% plot optimal (acc. to CVE) LLR fit with true curve & noisy data
subplot(1,2,2)
[~,lopt]=min(mean(CVE{2}));
y0=LocLinReg(x',y',x',lam(lopt));
ytrue=sin(x)+x./10+2;
plot(x,ytrue,'g',x,y,'bo',x,y0,'r','LineWidth',3);
box off; axis([0 20 0 6]); set(gca,'FontSize',24); 
xlabel('x','FontSize',24); ylabel('y','FontSize',24);
legend('true','data','LLR','Location','SouthEast','Orientation','horizontal')


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
