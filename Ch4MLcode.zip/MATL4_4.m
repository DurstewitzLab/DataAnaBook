clear all
close all


%% Fig 4.4: Curse of dimensionality: Illustration of clustering of pts. at outer rim

figure(4), hold off cla
eps=0.01;
rand('state',0);
X=rand(10^4,50);
D=abs(X-0.5);
x0=zeros(10^4,2);
for i=1:size(X,1)
    [~,r]=max(D(i,:)); k1=round(rand+1); k2=3-k1;
    % choose one dim with max-distance to center, and one arbitrarily
    x0(i,k1)=X(i,r); x0(i,k2)=X(i,randsample(setdiff(1:50,r),1));
end;
plot(x0(:,1),x0(:,2),'k.','LineWidth',5);
axis([0 1 0 1]); set(gca,'FontSize',20); 
xlabel('x_1','FontSize',20); ylabel('x_2','FontSize',20);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
