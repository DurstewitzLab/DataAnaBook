clear all
close all


%% 'Nearest shrunken centroids' (NSC) procedure
% see Hastie et al. (2009), Elements of Statistical Learning, Ch.18; 
% or Witten & Tibshirani (2011), J. R. Statist. Soc. B

% create K classes
randn('state',0);
K=3; % number classes
p=6; % number dimensions/variables
n=20;   % number samples
ME=zeros(K,p);
ME(2,:)=[0 0 1.7 2 -1 0];
ME(3,:)=[-1.5 0 0 -1.2 0 0];
X=cell(K,1);
for k=1:3, X{k}=mvnrnd(ME(k,:),eye(p),n); end

Xm=zeros(K,p);  % class means
Xvar=zeros(1,p);    % pooled single-var. variances
Nk=zeros(1,K);
% compute class means and pooled variances
for i=1:K
    Nk(i)=size(X{i},1); % size of class
    if Nk(i)>1, Xm(i,:)=mean(X{i}); else Xm(i,:)=X{i}; end;
    Xvar=Xvar+(Nk(i)-1)*var(X{i});
end;
Xvar=Xvar./(sum(Nk)-K);
Xgrd=mean(cell2mat(X));    % grand mean

% standardize distances between class mean and grand mean variables
D=Xm-ones(K,1)*Xgrd;
mk=sqrt(1./Nk-1/sum(Nk))';
sk=sqrt(Xvar);
D=D./(mk*(sk+median(sk)));

% shrink distances toward 0 (drop out var with d=0 for all k)
delta=2;  % shrinkage threshold
Dnew=sign(D).*max(abs(D)-delta,0);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
