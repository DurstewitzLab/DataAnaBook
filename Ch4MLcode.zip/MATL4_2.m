clear all
close all


%% Fig 4.2: Schema K-fold CV - splitting of data sets

figure(2), hold off cla
rectangle('Position',[-5 -2 10 4],'FaceColor','y')
axis([-6 6 -6 6]); axis('off'), hold on
for x=-5:2:5
    plot([x x],[-2.5 2.5],'k','LineWidth',3);
    if x<5, text(x+1,0,['S_' num2str(round((5+x)/2)+1)],'FontSize',20); end;
end;
plot([-5 -3],[-2 2],'k','LineWidth',3);
plot([-5 -3],[2 -2],'k','LineWidth',3);
plot([-3 5],[3.4 3.4],'b','LineWidth',2);
plot([-3 -3],[2.7 3.4],'b','LineWidth',2);
plot([5 5],[2.7 3.4],'b','LineWidth',2);
text(1,4.2,'S^-^1','FontSize',20,'Color','b')
text(-0.3,-3.5,'K = 5','FontSize',24);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
