clear all
close all


%% Fig 4.1: Bias-variance-tradeoff in kNN

% create rising sine-wave data
x=0:0.2:20; s=0.5;
y=sin(x)+x./10+s*randn(size(x))+2;

% compute training error & CVE
m=length(x);
N=500;  % #samples
Kmax=30;    % max. #neighbors to test
R=10;   % R-fold cross-val.
ypred=cell(1,Kmax); Err=zeros(N,Kmax); CVE=Err;
for n=1:N % move through all random samples
    disp(n);
    randn('state',n);
    for k=1:Kmax % move through range of k-values
        ypred{k}(n,:)=kNNclass(x',x',y',k,'regr');  % call kNN in regression mode
        Err(n,k)=sum((y-ypred{k}(n,:)).^2); % training-set error
        % compute R-fold CV error:
        AllIdc=1:m; cve=zeros(1,R);
        for r=1:R
            w=randsample(AllIdc,round(m/R)); AllIdc=setdiff(AllIdc,w);
            nw=setdiff(1:m,w);
            y0=kNNclass(x(w)',x(nw)',y(nw)',k,'regr');  % call kNN in regression mode
            cve(r)=sum((y(w)-y0').^2);
        end;
        CVE(n,k)=sum(cve)/(round(m/R)*R);
    end;
end;

% compute 'analytical' prediction error curves 
ypavg=cell2mat(cellfun(@mean,ypred,'UniformOutput',false)');
ytrue=sin(x)+x./10+2;
ExpPE=mean((ones(Kmax,1)*ytrue-ypavg)'.^2)+s^2./(1:Kmax)+s^2; % theoretical PE (eq. 4.1)
AIC=mean(Err)./m+2*s^2./(1:Kmax);   % eq. 4.2
BIC=mean(Err)./m+log(m)*s^2./(1:Kmax);  % eq. 4.3
%save BiasVarTO_kNN AIC BIC CVE ExpPE


%% plot results
%load BiasVarTO_kNN
figure(1), hold off cla
subplot(1,2,1)
plot(1:Kmax,AIC,'Color',[0.7 0.7 0.7],'LineWidth',3); hold on
plot(1:Kmax,BIC,':','Color',[0.7 0.7 0.7],'LineWidth',3);
plot(1:Kmax,mean(CVE),'--','Color',[0.7 0.7 0.7],'LineWidth',3);
plot(1:Kmax,ExpPE,'k','LineWidth',3);
box off; axis([1 30 0.2 1]); set(gca,'FontSize',22); 
xlabel('\it{k}','FontSize',22); ylabel('Prediction Error','FontSize',22);
legend('AIC','BIC','CVE','true','Location','best')
legend('boxoff','FontSize',22)

subplot(1,2,2)
[~,kopt]=min(ExpPE);
ypopt=kNNclass(x',x',y',kopt,'regr');
yp1=kNNclass(x',x',y',1,'regr');
ypN=kNNclass(x',x',y',m,'regr');
plot(x,yp1,'k','LineWidth',2); hold on
plot(x,ypN,'Color',[0.7 0.7 0.7],'LineWidth',2);
plot(x,y,'bo',x,ypopt,'r','LineWidth',3);
legend('\it{k}=1','\it{k}=\it{N}','original','\it{k}=opt','Location','best')
legend('boxoff','FontSize',18)
box off; axis([0 20 0 5.5]); set(gca,'FontSize',22); 
xlabel('x','FontSize',22); ylabel('y','FontSize',22);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
