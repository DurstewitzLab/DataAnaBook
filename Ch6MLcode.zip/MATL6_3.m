clear all
close all
path(path,'/home/dd/bin/MLana') % paths need to be adjusted!
path(path,'/home/dd/bin/MLana/LLE')
path(path,'/home/dd/bin/MLana/Isomap')

%% Fig. 6.3: Illustration of PCA failure on NONlinear curve/manifold, kernel-PCA

% arrange 'horseshoe' data
figure(3), hold off cla
subplot(2,4,[1 5]), hold off cla
randn('state',0);
a=2; b=10;
x=[-2:0.005:-1.5 -1.5:0.01:-1 -1:0.02:1 1:0.01:1.5 1.5:0.005:2];
y=b*sqrt(1-x.^2/a^2);
z=zeros(1,length(x));
X0=mvnrnd([x;y;z]',[0.1 0 0;0 0.1 0;0 0 2.3],length(x));
plot3(X0(:,1),X0(:,2),X0(:,3),'.','MarkerSize',10);
hold on, plot3(X0([1 end],1),X0([1 end],2),X0([1 end],3),'ro','LineWidth',2);
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2'); zlabel('x_3'); box off
subplot(2,4,[1 5]), xlim([-3 3]), ylim([0 13]), zlim([-4 4])
title('original 3D space');

%% regular PCA (using inbuild ML func.)
subplot(2,4,2), hold off cla
[coeff,score,ev]=princomp(X0);
plot(score(:,1),score(:,2),'.','MarkerSize',10)
hold on, plot(score([1 end],1),score([1 end],2),'ro','LineWidth',2);
set(gca,'FontSize',20); xlabel('pc_1'); ylabel('pc_2'); box off
subplot(2,4,2), axis([-8 6 -5 5])
title('PCA');

%% kernel-PCA (implemented by Emili Balaguer-Ballester, Bournemouth)
subplot(2,4,3), hold off cla
O=4;
Y=kpca(X0,O);
plot(Y(:,1),Y(:,2),'.','MarkerSize',10)
hold on, plot(Y([1 end],1),Y([1 end],2),'ro','LineWidth',2);
set(gca,'FontSize',20); xlabel('pc_1'); ylabel('pc_2'); box off
title(['kernel-PCA (' num2str(O) ')']);
subplot(2,4,3), axis([-800 300 -450 400])

%% MDS (using inbuild ML func.)
subplot(2,4,4), hold off cla
opts=statset('MaxIter',1000);
d=pdist(X0,'euclidean');
[X0pr,stress]=mdscale(d,2,'criterion','metricstress','Start','random','Replicates',10,'Options',opts);
plot(X0pr(:,1),X0pr(:,2),'.','MarkerSize',10)
hold on, plot(X0pr([1 end],1),X0pr([1 end],2),'ro','LineWidth',2);
set(gca,'FontSize',20); xlabel('pc_1'); ylabel('pc_2'); box off
title('MDS');
subplot(2,4,4), axis([-5 9 -5 6])

%% LLE (using ML code from Roweis & Saul, 2000, www.cs.nyu.edu/~roweis/lle/code.html)
subplot(2,4,6), hold off cla
K=12; Y=lle(X0',K,2);
plot(Y(1,:),Y(2,:),'.','MarkerSize',10)
hold on, plot(Y(1,[1 end]),Y(2,[1 end]),'ro','LineWidth',2);
set(gca,'FontSize',20,'YTick',1); xlabel('pc_1'); ylabel('pc_2'); box off
title('LLE (K=12)');
subplot(2,4,6), xlim([-3 3])
subplot(2,4,7), hold off cla
K=200; Y=lle(X0',K,2);
plot(Y(1,:),Y(2,:),'.','MarkerSize',10)
hold on, plot(Y(1,[1 end]),Y(2,[1 end]),'ro','LineWidth',2);
set(gca,'FontSize',20,'YTick',-1); xlabel('pc_1'); ylabel('pc_2'); box off
title('LLE (K=200)');
subplot(2,4,7), xlim([-2 4])

%% Isomap (using ML code from Tenenbaum et al., 2000, isomap.stanford.edu)
subplot(2,4,8), hold off cla
opt.dims=2; opt.display=0;
K=50;
Y=Isomap(squareform(d),'k',K,opt); 
plot(Y.coords{1}(1,:),Y.coords{1}(2,:),'.','MarkerSize',10)
hold on, plot(Y.coords{1}(1,[1 end]),Y.coords{1}(2,[1 end]),'ro','LineWidth',2);
set(gca,'FontSize',20); xlabel('pc_1'); ylabel('pc_2'); box off
title('Isomap');
subplot(2,4,8), axis([-10 5 -5 5])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University