clear all
close all

%% Fig. 6.2: FA for extraction of sync neurons

figure(2)

% generate Poisson spike trains with embedded 'sync assemblies'
rand('state',0);
N=10000; p=20;
X=zeros(N,p);
R=rand(N,p); X(R<0.05)=1;
r=rand(1,N); X(r<0.01,1:5)=1;
r=rand(1,N); X(r<0.01,6:10)=1;
r=rand(1,N); X(r<0.01,11:15)=1;

% run FA with up to kmax factors
kmax=10;
AIC=zeros(1,kmax)+nan; BIC=AIC; FL=cell(1,kmax); Chi2=AIC; LL=AIC; FSC=FL;
for k=1:kmax
    disp(['nfac = ' num2str(k)]);
    [FL{k},PSI,~,~,FSC{k}]=factoran(X,k,'maxit',10000,'delta',1e-4);
    Cest=FL{k}*FL{k}'+diag(PSI);   % estimated data cov matrix
    LL(k)=-N/2*(p*log(2*pi)+log(det(Cest))+trace(Cest^-1*corr(X))); % log-likelihood
    Chi2(k)=(N-(2*p+11)/6-2*k/3)*(log(det(Cest))-log(det(corr(X)))); % chi^2 test stats for successive models
    np=k*p+p-k*(k-1)/2; % # parameters
    AIC(k)=-2*LL(k)+2*np;   % Akaike IC
    BIC(k)=-2*LL(k)+log(N)*np;  % Bayesian IC
end;

%% plot results

% AIC and BIC as function of k
subplot(3,2,1), hold off cla
plot(1:kmax,BIC,'r',1:kmax,AIC,'b','LineWidth',3)
set(gca,'FontSize',20); xlabel('# factors');
ylabel('\color{blue}AIC \color{black}/ \color{red}BIC'); box off

% factor loadings
subplot(3,2,2), hold off cla
imagesc(FL{3});
set(gca,'FontSize',20); xlabel('factor #'); ylabel('unit #');
title('factor loadings');

% original data
subplot(3,2,[3 4]), hold off cla
T=(1:N)*0.01;
imagesc(T,1:p,X'); xlim([41 44]);
set(gca,'FontSize',20); xlabel('Time'); ylabel('unit #');

% extracted factor scores
subplot(3,2,[5 6]), hold off cla
plot(T,FSC{3}(:,1),'b',T,FSC{3}(:,2),'g',T,FSC{3}(:,3),'r'); xlim([41 44]); ylim([-1 15])
set(gca,'FontSize',20); xlabel('Time'); ylabel('factor score');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University