clear all
close all


%% Fig. 6.1A: Illustration of PCA, dropping of dim.
% (from Durstewitz & Balaguer-Ballester, e-Neuroforum 4/2010)

% create and plot data
figure(1), hold off cla
randn('state',0);
mu = [2 3]-1;
SIGMA = [1 1.5; 1.5 3];
X = mvnrnd(mu,SIGMA,100);
plot(X(:,1),X(:,2),'bo','LineWidth',2);

% determine and plot principal components
COEFF = princomp(X);
hold on
plot([0 COEFF(1,1)*10],[0 COEFF(2,1)*10],'k--','LineWidth',2);
plot([0 COEFF(1,1)*-10],[0 COEFF(2,1)*-10],'k--','LineWidth',2);
plot([0 COEFF(1,2)*10],[0 COEFF(2,2)*10],'k--','LineWidth',2);
plot([0 COEFF(1,2)*-10],[0 COEFF(2,2)*-10],'k--','LineWidth',2);
set(gca,'FontSize',20);
axis([-3 6 -3 6]), box off


%% Fig. 6.1C: Principle of LDA
% (from Durstewitz & Balaguer-Ballester, e-Neuroforum 4/2010)

% create and plot data from 2 Gaussians
figure(4), hold off cla
N=100;
randn('state',0);
mu1 = [1 2];
SIGMA = [1 1; 1 2];
X1 = mvnrnd(mu1,SIGMA,N);
plot(X1(:,1),X1(:,2),'bo','LineWidth',2); hold on
mu2 = [2.5 1];
X2 = mvnrnd(mu2,SIGMA,N);
plot(X2(:,1),X2(:,2),'ro','LineWidth',2); hold on

% determine maximally separating direction using FDA
% (cf. Hastie et al., 2009, Elements of Statistical Learning)
M(1,:)=mean(X1); M(2,:)=mean(X2);
W=((N-1)*cov(X1)+(N-1)*cov(X2))./(2*N-2);
Bx=cov(M*W^-(1/2)); [E,V]=eig(Bx);
[~,k]=max(diag(V));

% plot this direction in original space
plot([0 E(1,k)*20],[0 E(2,k)*20],'k--','LineWidth',2);
plot([0 E(1,k)*-20],[0 E(2,k)*-20],'k--','LineWidth',2);
axis([-3 6 -3 6])


%% illustrate projections of distributions on original and max. FDA dimensions

% draw much larger sample
x=-3:0.01:6;
X1 = mvnrnd(mu1,SIGMA,N*100);
X2 = mvnrnd(mu2,SIGMA,N*100);
m1=mean(X1); m2=mean(X2);   % empirical mean & stdv
s1=std(X1); s2=std(X2);

% plot projection on x-axis
figure(5), hold off cla
subplot(3,1,1)
h1=normpdf(x,m1(1),s1(1));
h2=normpdf(x,m2(1),s2(1));
plot(x,h1./sum(h1),'b',x,h2./sum(h2),'r','LineWidth',2);
axis([-4 6 0 5e-3])

% plot projection on y-axis
h1=normpdf(x,m1(2),s1(2));
h2=normpdf(x,m2(2),s2(2));
subplot(3,1,2), hold off cla
plot(x,h1./sum(h1),'b',x,h2./sum(h2),'r','LineWidth',2);
axis([-4 6 0 5e-3])
set(gca,'XDir','reverse');

% project data on max. FDA direction
Wgt=W^-(1/2)*E;
L=ones(2,1)*sqrt(sum(Wgt.^2));
Wgt=Wgt./L;
X1red=X1*Wgt(:,k);
X2red=X2*Wgt(:,k);

% plot distributions along that direction
x=-5:0.01:4;
m1=mean(X1red); m2=mean(X2red);
s1=std(X1red); s2=std(X2red);
h1=normpdf(x,m1,s1);
h2=normpdf(x,m2,s2);
subplot(3,1,3), hold off cla
plot(x,h1./sum(h1),'b',x,h2./sum(h2),'r','LineWidth',2);
axis([-4 6 0 7e-3])
set(gca,'XDir','reverse');


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University