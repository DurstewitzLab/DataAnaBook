clear all
close all

mu1={[0;0],[-4;4],[4;5]};    % group means
SI1={[1 0.2;0.2 1],[1 0.2;0.2 1],[1 0.2;0.2 1]}; % cov-matrices
mu2={[0;0],[-3;3],[3;3]};    % group means
SI2={[4 1.2;1.2 1.5],[2 0;0 3],[1 1;1 4]}; % cov-matrices
load ExampleDistrib


%% Fig. 5.6: Mode-hunting routine on same examples as in Fig. 5.1

figure, hold off cla


%% run mode hunting on well-separated Gaussians
eps=0.2;
MinOvlp=0.5;
alpha=0.05;
wrpfl=false;
Xall=cell2mat(X1)';
[Npts,pr,sig,sel,Ovlp]=FindSigModesML(Xall,eps,MinOvlp,alpha,wrpfl);

% plot results
xrg=range(Xall);
ctrs=Xall(find(sig),:);
clr={'b','g','r'};
subplot(1,2,1), hold off cla
for i=1:length(X1)
    plot(X1{i}(1,:),X1{i}(2,:),[clr{i} '.'],'MarkerSize',7); hold on;
    plot(mu1{i}(1),mu1{i}(2),[clr{i} 'o'],'LineWidth',3,'MarkerSize',10);
    bx=[ctrs(i,1)-eps*xrg(1)/2 ctrs(i,1)+eps*xrg(1)/2];
    by=[ctrs(i,2)-eps*xrg(2)/2 ctrs(i,2)+eps*xrg(2)/2];
    Bx=[bx(1) bx(2) bx(1) bx(2) bx(1) bx(1) bx(2) bx(2)];
    By=[by(1) by(1) by(2) by(2) by(1) by(2) by(1) by(2)];
    plot(Bx,By,clr{i},'LineWidth',2);
end;
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2'); box off
axis([-7 7 -3 8])


%% run mode hunting on ill-separated Gaussians
eps=0.1;
MinOvlp=0.1;
alpha=1;    % be lean on FDR level for ill-separated modes
wrpfl=false;
Xall=cell2mat(X2)';
[Npts,pr,sig,sel,Ovlp]=FindSigModesML(Xall,eps,MinOvlp,alpha,wrpfl);

% plot results
[~,v]=sort(pr(sel),'ascend');
ctrs=Xall(sel(v([2 1 3])),:);
xrg=range(Xall);
clr={'b','g','r'};
subplot(1,2,2), hold off cla
for i=1:length(X2)
    plot(X2{i}(1,:),X2{i}(2,:),[clr{i} '.'],'MarkerSize',7); hold on;
    plot(mu2{i}(1),mu2{i}(2),[clr{i} 'o'],'LineWidth',3,'MarkerSize',10);
    bx=[ctrs(i,1)-eps*xrg(1)/2 ctrs(i,1)+eps*xrg(1)/2];
    by=[ctrs(i,2)-eps*xrg(2)/2 ctrs(i,2)+eps*xrg(2)/2];
    Bx=[bx(1) bx(2) bx(1) bx(2) bx(1) bx(1) bx(2) bx(2)];
    By=[by(1) by(1) by(2) by(2) by(1) by(2) by(1) by(2)];
    plot(Bx,By,clr{i},'LineWidth',2);
end;
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2'); box off
axis([-8 8 -4 10])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University