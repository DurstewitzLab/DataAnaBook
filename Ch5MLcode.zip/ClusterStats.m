function [CH,sh]=ClusterStats(Xall,Z)
% computes 2 different criteria for determining number of classes present
% --- INPUTS
% Xall: Nxp data matrix
% Z: Nx1 vector of corresponding cluster assignments
% --- OUTPUTS
% CH: Calinski & Harabasz statistic
% sh: silhouette statistic

%% Calinski & Harabasz (1974)
ks=unique(Z); nk=length(ks);
W=0; B=0; N=zeros(1,nk); m=zeros(nk,size(Xall,2));
for k=1:nk
    r=find(Z==ks(k)); N(k)=length(r);
    m(k,:)=mean(Xall(r,:));
    W=W+length(r)*cov(Xall(r,:),1);
    B=B+length(r)*(mean(Xall(r,:))-mean(Xall))'*(mean(Xall(r,:))-mean(Xall));
end;
CH=(sum(N)-nk)*trace(B)/((nk-1)*trace(W));

%% silhouette statistic (Kaufman and Rousseeuw 1990)
D=squareform(pdist(Xall));
Davg=zeros(nk,sum(N));
for k=1:nk, r=(Z==ks(k)); Davg(k,:)=mean(D(:,r),2)'; end;
s=zeros(size(Z));
for i=1:sum(N)
    a=Davg(Z(i),i)*N(Z(i))/(N(Z(i))-1);   % correct for id-counts in Davg-mtx
    o=setdiff(ks,Z(i));
    if isempty(o), b=a;
    else b=min(Davg(o,i)); end;
    s(i)=(b-a)/max(b,a);
end;
sh=mean(s);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University