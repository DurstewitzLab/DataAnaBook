function [H,T,F,Bin]=KDensEstim(X,H0,nbins,Z)
% This routine implements different procedures for nonparametric
% multivariate density estimation based on minimizing the mean integrated
% squared error (MISE), E[int((f^(x,H)-f(x))^2)], estimated through 
% unbiased cross-validation (jackknife):
% - For scalar or diagonal kernel matrices, the locally adaptive method due
% to Sain (2002), Comp Stat & Data Ana, is implemented.
% - For full bandwidth matrices, the global UCV kernel density estimator
% due to Duong & Hazelton (2005), Scand J Stats, is implemented.
%
% --- INPUTS
% X: Nxp data matrix
% H0: initial bandwidth matrix (determines method used, see above)
% [nbins: number of data bins for adaptive method]
% [Z: grid points at which density estimate is desired]
% --- OUTPUTS
% H: estimated kernel bandwidth matrix
% T: bin centers
% F: density estimate evaluated at grid points in Z
% Bin: assignment of data points to bins

eps=1e-4;   % small positive constant for ensuring positive-definite kernel matrices

N=size(X,1);    % number data points
p=size(X,2);    % number dimensions
if nargin<3 || isempty(nbins), nbins=round(N^(1/p)); end;

if iscell(H0)
    T=X; H=H0; Bin=nbins;
else
    % method used depends on user-provided initial estimate of H0
    HClass=3;
    D=diag(H0);
    if isempty(find(diag(D)~=H0))
        HClass=2;
        if isempty(find(D~=D(1))), HClass=1; end;
    end;
    HClass

    % minimize UCV-error with respect to bandwidth matrix/matrices H
    if HClass<3
        [hvec0,T,Bin]=IniUCV(X,H0,nbins,HClass);   % initialize all kernels and bin-means
        hvec=fminsearch(@UCVErr,hvec0,[],X,T,Bin,HClass,eps);    % minimize criterion function
        % --> alternatively use fminunc and provide gradient
        H=[];
        for j=1:size(T,2)
            if length(hvec)>p, H{j}=diag(max(hvec((j-1)*p+1:j*p),eps));
            else H{j}=hvec(j)*eye(p); end;
        end;
    else
        T=X'; Bin=1:N;
        HH=tril(H0); hvec0=HH(HH~=0);
        hvec=fminsearch(@UCVErr,hvec0,[],X,T,Bin,HClass,eps);    % minimize criterion function
        % --> alternatively use fminunc and provide gradient
        H=H0; H(HH~=0)=hvec; H=H+H'-diag(diag(H));

        % ensure that kernel matrix is positive-definite:  
        [V,U]=eig(H);
        U=diag(max(diag(U),eps));
        H=V*U*V^-1;
    end;
end;

% evaluate density at grid points specified in Z
if nargin>3, F=KDens(Z,H,T,Bin); end;


function [hvec,T,Bin]=IniUCV(X,H0,nbins,HClass)
N=size(X,1);
p=size(X,2);
% put data into boxes and assign bins
box=ceil(nbins*(X-ones(N,1)*min(X))./(ones(N,1)*range(X)));
k=find(box==0); box(k)=1;
for i=1:p, box(:,i)=(box(:,i)-1)*nbins^(i-1); end;
if p>1, box=sum(box')+1; else box=box+1; end;
v=sort(unique(box),'ascend');
Bin=[];
for i=1:length(v)
    k=find(box==v(i));
    Bin(k)=i;
    if length(k)>1, T(:,i)=mean(X(k,:))';
    else T(:,i)=X(k,:)'; end;
end;
% initialize kernel matrices
hvec=[];
for j=1:length(v)
    if HClass==1, hvec(j)=H0(1,1);
    else hvec((j-1)*p+1:j*p)=diag(H0); end;
end;


function err=UCVErr(hvec,X,T,Bin,HClass,eps)
N=size(X,1);
p=size(X,2);
m=size(T,2);
H=[];
for j=1:m
    switch HClass
        case 1, H{j}=hvec(j)*eye(p);
        case 2, H{j}=diag(hvec((j-1)*p+1:j*p));
        case 3, H{j}=zeros(p,p); H{j}(find(tril(ones(p))))=hvec; H{j}=H{j}+H{j}'-diag(diag(H{j}));
    end;
end;
err1=0; err2=0;
for j=1:m
    n1=length(find(Bin==j));
    a=n1*n1*(2*pi)^(-p/2)*det(2*H{j})^(-1/2);
    err1=err1+a;  % if tj==tk
    for k=j+1:m
        % ensure that kernel matrix is positive-definite:
        [V,U]=eig(H{j}+H{k});
        U=diag(max(diag(U),eps));
        HH=V*U*V^-1;
        
        n2=length(find(Bin==k));
        a=n1*n2*(2*pi)^(-p/2)*det(HH)^(-1/2);
        dt=T(:,j)-T(:,k);
        err2=err2+a*exp(-1/2*dt'*HH^-1*dt);
    end;
end;
err3=0;
for i=1:N
    for j=1:m
        % ensure that kernel matrix is positive-definite:
        [V,U]=eig(H{j});
        U=diag(max(diag(U),eps));
        HH=V*U*V^-1;
        
        n=length(find(Bin==j));
        if Bin(i)==j, n=n-1; end;
        dt=X(i,:)'-T(:,j);
        a=n*(2*pi)^(-p/2)*det(HH)^(-1/2);
        err3=err3+a*exp(-1/2*dt'*HH^-1*dt);
    end;
end;
err=(err1+2*err2)/N^2-2*err3/(N*(N-1));


% evaluate kernel density at grid points using estimated H
function F=KDens(Z,H,T,Bin)
[N,p]=size(Z);
F=zeros(1,N);
for i=1:N
    for j=1:size(T,2)
        if iscell(H), K=H{j}; else K=H; end;
        n=length(find(Bin==j));
        a=n*(2*pi)^(-p/2)*det(K)^(-1/2);
        dt=Z(i,:)'-T(:,j);
        F(i)=F(i)+a*exp(-1/2*dt'*K^-1*dt);
    end;
end;
F=F./length(Bin);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
