clear all
close all


%% Fig. 5.1: GMM and kmeans on three different types of mixture densities

% create example data
mu1={[0;0],[-4;4],[4;5]};    % group means
SI1={[1 0.2;0.2 1],[1 0.2;0.2 1],[1 0.2;0.2 1]}; % cov-matrices
mu2={[0;0],[-3;3],[3;3]};    % group means
SI2={[4 1.2;1.2 1.5],[2 0;0 3],[1 1;1 4]}; % cov-matrices

N=200;
[X1,X2,X3]=CreateDistrib(N,0);
%save ExampleDistrib X1 X2 X3 N
%load ExampleDistrib

%% run GMM and kmeans on data and plot
figure(1)
rand('state',0);
[M,S,Z,LL,Mini,Sini,Zini,Zkm,W]=GMM_kmeans_graphs(X1,mu1,SI1,[-7 7 -3 8],1);
[M,S,Z,LL,Mini,Sini,Zini,Zkm,W]=GMM_kmeans_graphs(X2,mu2,SI2,[-8 8 -4 10],5);
[M,S,Z,LL,Mini,Sini,Zini,Zkm,W]=GMM_kmeans_graphs(X3,[],[],[-10 10 -5 8],9);

subplot(3,4,1), title('\bf{True assignments}','FontSize',20);
subplot(3,4,2), title('\bf{Initial configuration}','FontSize',20);
subplot(3,4,3), title('\bf{GMM}','FontSize',20);
subplot(3,4,4), title('\bf{k-means}','FontSize',20);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University