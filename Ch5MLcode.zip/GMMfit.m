function [M,S,Z,LL,Mini,Sini,Zini]=GMMfit(X,K)
% estimate Gaussian Mixture Model using EM
% --- INPUTS
% X: Nxq data matrix
% K: number of classes
% --- OUTPUTS
% M: cell array of estimated GMM class centers 
% S: cell array of estimated GMM class cov-matrices
% Z: column vector of estimated GMM assignments for all observations
% LL: log-likelihood across EM iterations for GMM
% Mini: cell array of initial 'estimates' of GMM class centers (before training) 
% Sini: cell array of initial 'estimates' of GMM class cov-matrices
% Zini: column vector of initial random class assignments 

tol=1e-8;
[N,Q]=size(X);

%% - initialize all mk, Sk, and apr (= a priori-prob.)
% start with random assignment of data points
w=1:N; Z=ones(N,1);
for k=2:K
    r=randsample(w,round(N/K));
    Z(r)=k; w=setdiff(w,r);
end;
M=cell(1,K); S=cell(1,K); apr=zeros(1,K);
for k=1:K
    r=find(Z==k);
    M{k}=mean(X(r,:));
    S{k}=cov(X(r,:));
    apr(k)=length(r)/N;
end;
Mini=M; Sini=S; Zini=Z;

%% run EM iterations until convergence or MaxIter is exceeded
MaxIter=100;    % max. # EM-iterations
m=1; LLR=1e8; LL=[]; R=cell(1,K);
for k=1:K, R{k}=apr(k)*mvnpdf(X,M{k},S{k}); end;
LL(m)=sum(log(sum(cell2mat(R)')));
while LLR>tol*abs(LL(1)) && m<MaxIter
    % - E step: 'responsibilities' p(znk=1|xn)= g(znk)= 
    % pk * Norm(xn | mk,Sk) / sum_j{ pk * Norm(xn |mj,Sj)}
    for k=1:K, R{k}=apr(k)*mvnpdf(X,M{k},S{k}); end;
    g=cell2mat(R)./(sum(cell2mat(R)')'*ones(1,K));
    % - M step: 
    % mk_new = 1/Nk sum_n{ g(znk) * xn}
    % Sk_new = 1/Nk sum_n{ g(znk) (xn-mk_new) (xn-mk_new)'}
    % pk_new = Nk / N
    % Nk = sum_n { g(znk) }
    G=sum(g);
    for k=1:K
        M{k}=sum((g(:,k)*ones(1,Q)).*X)./G(k);
        X0=X-ones(N,1)*M{k};
        S{k}=(ones(Q,1)*g(:,k)').*X0'*X0./G(k);
    end;
    apr=G./N;
    % evaluate log-likelihood log p(X|m,S,p)= sum_n{log[sum_k{ pk *
    % Norm(xn|mk,Sk)}]} and check for convergence
    for k=1:K, R{k}=apr(k)*mvnpdf(X,M{k},S{k}); end;
    m=m+1; LL(m)=sum(log(sum(cell2mat(R)')));
    LLR=LL(m)-LL(m-1);
    disp(['LLR = ' num2str(LLR)]);
end;
disp(['# iterations = ' num2str(m)]);
[~,Z]=max(g,[],2);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University