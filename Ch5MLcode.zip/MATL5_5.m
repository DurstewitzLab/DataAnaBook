clear all
close all

N=200;
[X1,X2,X3]=CreateDistrib(N,3);

%% Fig. 5.4: Illustration of formal criteria eq. 5.16-5.18 for determining #clusters
% using mixed Gaussians & uniform distributions as examples

figure(8), hold off cla
rand('state',3);
Xsets={X1;X2;X3};
kmax=10;
tt={'3 well-separated','3 overlapping','2 non-Gaussian'};
for i=1:length(Xsets)   % go through various data sets
    Xall=cell2mat(Xsets{i})';
    
    for k=1:kmax   % go through range for number of classes k 
        [M,S,Z]=GMMfit(Xall,k); % run GMM estimation
        if length(intersect(Z,1:k))<k
            CHgmm(k)=nan; shGmm(k)=nan;
        else
            % compute CH and silhouette stats for GMM output as func. of k:
            [CHgmm(k),shGmm(k)]=ClusterStats(Xall,Z);
        end;
        Z=kmeans(Xall,k,'replicates',50,'emptyaction','singleton'); % run kmeans clustering
        % compute CH and silhouette stats for kmeans output as func. of k:
        [CHkm(k),shkm(k)]=ClusterStats(Xall,Z);
    end;
    
    % plot CH and silhouette stats for GMM and kmeans
    subplot(2,length(Xsets),i)
    sf=max(shGmm)/max(CHgmm);   % scale to same range for visualization
    plot(1:kmax,sf*CHgmm,'b',1:kmax,shGmm,'r','LineWidth',2);
    set(gca,'FontSize',20,'XTick',0:10); axis([0 11 0 0.9]); box off;
    ylabel('cluster stats');
    title(tt{i},'FontSize',22);
    subplot(2,length(Xsets),length(Xsets)+i)
    sf=max(shkm)/max(CHkm);   % scale to same range for visualization
    plot(1:kmax,sf*CHkm,'b',1:kmax,shkm,'r','LineWidth',2);
    set(gca,'FontSize',20,'XTick',0:10); axis([0 11 0 0.9]); box off;
    xlabel('# clusters (k)'); ylabel('cluster stats');
    if i==2, s1=max(shGmm); s2=max(shkm); end;
end;


%% compute gap statistic (Tibshirani et al. 2001) on same examples

% draw bootstraps uniformly from convex hull of data
Nbs=100; Xbs=cell(1,Nbs);
Xorg=cell2mat(X2)';
for b=1:Nbs, Xbs{b}=DrawConvH(Xorg); end;

% % run GMM and kmeans on original and Nbs bootstrap data, save results
% % (takes a while!!)
% kmax=10;
% LL=zeros(1,kmax); LLbs=zeros(Nbs,kmax);
% W=zeros(1,kmax); Wbs=zeros(Nbs,kmax);
% for k=1:kmax
%     [~,~,~,LLk]=GMMfit(Xorg,k); LL(k)=LLk(end);
%     for b=1:Nbs, [~,~,~,LLk]=GMMfit(Xbs{b},k); LLbs(b,k)=LLk(end); end;
%     [~,~,Wk]=kmeans(Xorg,k,'replicates',50,'emptyaction','singleton');
%     W(k)=log(sum(Wk));
%     for b=1:Nbs
%         [~,~,Wk]=kmeans(Xbs{b},k,'replicates',50,'emptyaction','singleton');
%         Wbs(b,k)=log(sum(Wk));
%     end;
% end;
% save Fig5_4_GapStatRes LL LLbs W Wbs

% compute & plot gap stats for GMM
load Fig5_4_GapStatRes
gapGMM=LL-mean(LLbs);
gapGmmSE=std(LLbs,1)*sqrt(1+1/Nbs);
sf=1.5*s1/max(gapGMM);  % scale to range
subplot(2,length(Xsets),2), hold on
errorbar(1:kmax,sf*gapGMM,sf*gapGmmSE,'go-');

% compute & plot gap stats for kmeans
gapKm=mean(Wbs)-W;
gapKmSE=std(Wbs,1)*sqrt(1+1/Nbs);
sf=1.5*s2/max(gapKm);  % scale to range
subplot(2,length(Xsets),5), hold on
errorbar(1:kmax,sf*gapKm,sf*gapKmSE,'go-');

legend('Calinski & Harabasz','silhouette stats','gap stats','Position',[400,220,100,1],'Orientation','horizontal');
%legend('Calinski & Harabasz','silhouette stats','gap stats','FontSize',20,'Orientation','horizontal','Position',[600,280,100,1]);
%legend('boxoff')


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University