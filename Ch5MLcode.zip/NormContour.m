function [x1L,x1H]=NormContour(x2,p,mu,S)
% produces 2-dim normal function contours provided data x2 for second dim
% --- INPUTS
% x2: data on dimension 2
% p: p-value for normal contours
% mu: mean vector of Gaussian
% S: cov-matrix
% --- OUTPUTS
% x1L: lower x1-contour 
% x1H: upper x1-contour

Sinv=S^-1;
s=sqrt(2*pi*det(S));
y=norminv(p,0,s);
a=Sinv(1,1);
for i=1:length(x2)
    b=(x2(i)-mu(2))*(Sinv(2,1)+Sinv(1,2));
    c=Sinv(2,2)*(x2(i)-mu(2))^2-(y/s)^2;
    x1L0(i)=-(b+sqrt(b^2-4*a*c))/(2*a)+mu(1);
    x1H0(i)=-(b-sqrt(b^2-4*a*c))/(2*a)+mu(1);
end;
x1L=[]; x1H=[];
for i=1:length(x2)
    x1L(i)=x1L0(i);
    if ~isreal(x1L0(i))
        if (i>=length(x2) || ~isreal(x1L0(i+1))) && ...
           (i==1 || ~isreal(x1L0(i-1))), x1L(i)=NaN; end;
    end;
    x1H(i)=x1H0(i);
    if ~isreal(x1H0(i))
        if (i>=length(x2) || ~isreal(x1H0(i+1))) && ...
           (i==1 || ~isreal(x1H0(i-1))), x1H(i)=NaN; end;
    end;
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
