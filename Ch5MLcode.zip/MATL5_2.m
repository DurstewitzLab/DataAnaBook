clear all
close all


%% Fig. 5.2: Kernel density estimation (KDE) on spike trains (ST)

% create homogeneous Poisson spike train
rand('state',0);
Tend=500;
rate=5; % spike rate
i=1; ST1(i)=-log(rand)/rate;
while ST1(i)<Tend, i=i+1; ST1(i)=ST1(i-1)-log(rand)/rate; end;

% add predictable structure (bursts)
L=length(ST1); dt=3;
kdel=[]; for t=0.4:dt:Tend, k=find(ST1>=t & ST1<=t+0.3); kdel=[kdel k]; end;
keep=setdiff(1:L,kdel);
bursts=[0.4:dt:Tend 0.41:dt:Tend 0.42:dt:Tend 0.43:dt:Tend];
ST2=randsample(ST1(keep),L-length(bursts));
ST2=sort([ST2 bursts],'ascend');


%% Univar. Taylor-KDE on homogen. Poisson ST (=> wide kernel-width h)
T=0:0.05:Tend;  % bin time
h0=mean(diff(ST1))^2;   % set initial bandwidth estimate to mean ISI 
[hucv1,MISE1]=UniKDE(ST1,h0); % call KDE
iFR1=STtoGfAvg(ST1,T,sqrt(hucv1));  % convolve ST with Gaussian kernel using estimated bandwidth

% plot ST and KDE
subplot(1,3,1), hold off cla
plot(T(1:end-1),iFR1,'r',ST1,4,'bo','LineWidth',2)
set(gca,'FontSize',20); xlabel('Time (s)'); ylabel('Rate (Hz)');
title(['$$ \lambda \approx ' num2str(round(1000*hucv1)/1000) '$$'],'Interpreter','latex');
text(247,43,'\bf{A}','FontSize',28)
axis([250 260 0 40]), box off


%% Univar. KDE on structured/predictable ST (=> narrow kernel-width h)
h0=mean(diff(ST2))^2;   % set initial bandwidth estimate to mean ISI
[hucv2,MISE2]=UniKDE(ST2,h0); % call KDE
iFR2=STtoGfAvg(ST2,T,sqrt(hucv2));  % convolve ST with Gaussian kernel using estimated bandwidth

% plot ST and KDE
subplot(1,3,2), hold off cla
plot(T(1:end-1),iFR2,'r',ST2,4,'bo','LineWidth',2)
set(gca,'FontSize',20); xlabel('Time (s)'); ylabel('Rate (Hz)');
title(['$$ \lambda \approx ' num2str(round(1000*hucv2)/1000) '$$'],'Interpreter','latex');
text(247,43,'\bf{B}','FontSize',28)
axis([250 260 0 40]), box off


%% add local rate changes ('stimulus responses') to homogenous ST1
locr=35;
D=14:20:Tend;
ST3=[]; i=1;
for j=1:length(D)
    ST3(i)=D(j)-log(rand)/locr;
    while ST3(i)<D(j)+1, i=i+1; ST3(i)=ST3(i-1)-log(rand)/locr; end;
end;
ST3=sort([ST1 ST3],'ascend');

% perform KDE
h0=mean(diff(ST3))^2;
[hucv3,MISE3]=UniKDE(ST3,h0);
iFR3=STtoGfAvg(ST3,T,sqrt(hucv3));

% ... and plot
subplot(1,3,3), hold off cla
plot(T(1:end-1),iFR3,'r',ST3,4,'bo','LineWidth',2)
set(gca,'FontSize',20); xlabel('Time (s)'); ylabel('Rate (Hz)');
title(['$$ \lambda \approx ' num2str(round(1000*hucv3)/1000) '$$'],'Interpreter','latex');
axis([250 260 0 60]), box off


%% run locally adaptive KDE method on inhomogen. ST3 example
bw=0.1; Z=250:bw:260;
k=find(ST3>=250 & ST3<=260);
[H,T,F,Bin]=KDensEstim(ST3(k)',h0,20,Z');

% ... add to graph
hold on
plot(Z,(length(k)/bw)*(F./sum(F)),'k','LineWidth',2);
text(247,65,'\bf{C}','FontSize',28)


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University