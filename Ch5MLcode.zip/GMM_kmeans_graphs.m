function [M,S,Z,LL,Mini,Sini,Zini,Zkm,W]=GMM_kmeans_graphs(X0,mu,SI,axv,pn)
% visualization of GMM and kmeans on 2D input data
% --- INPUTS
% X0: cell array of samples, one class per cell, samples in columns
% (assumes p=2 for visualization purposes, although not required for GMM
% and kmeans routines called below)
% mu: cell array of corresponding class means (column vectors)
% SI: cell array of corresponding class cov-matrices
% axv: axis-range
% pn: subplot-panel to plot into
% --- OUTPUTS
% M: cell array of estimated GMM class centers 
% S: cell array of estimated GMM class cov-matrices
% Z: column vector of estimated GMM assignments for all observations
% LL: log-likelihood across EM iterations for GMM
% Mini: cell array of initial 'estimates' of GMM class centers (before training) 
% Sini: cell array of initial 'estimates' of GMM class cov-matrices
% Zini: column vector of initial random class assignments 
% Zkm: column vector of estimated kmeans class assignments for all observations
% W: within-class sum of distances from kmeans 


%% plot original data with Gaussian contour lines (based on provided means & cov)
x2=axv(3):0.01:axv(4);
p=0.05; clr={'b','g','r'};
subplot(3,4,pn), hold off cla
warning off
Zorg=[];
for i=1:length(X0)
    plot(X0{i}(1,:),X0{i}(2,:),[clr{i} '.']); hold on;
    if ~isempty(mu)
        [x1L,x1H]=NormContour(x2,p,mu{i},SI{i});    % returns Gaussian 2D contours
        plot(x1L,x2,clr{i},x1H,x2,clr{i},'LineWidth',2);
    end;
    Zorg=[Zorg i*ones(1,length(X0{i}))];
end;
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2'); box off
axis(axv)

%% run GMM on data and plot with color-coded class assignments
Xall=cell2mat(X0)';
[M,S,Z,LL,Mini,Sini,Zini]=GMMfit(Xall,length(X0));

% initial assignments
subplot(3,4,pn+1), hold off cla
for i=1:length(X0)
    Xk=Xall(Zini==i,:);
    plot(Xk(:,1),Xk(:,2),[clr{i} '.'],'MarkerSize',7); hold on;
end;
axis(axv)
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2'); box off

% final GMM assignments with Gaussian contour lines
subplot(3,4,pn+2), hold off cla
for i=1:length(X0)
    Xk=Xall(Z==i,:); c=mode(Zorg(Z==i));
    plot(Xk(:,1),Xk(:,2),[clr{c} '.'],'MarkerSize',7); hold on;
    [x1L,x1H]=NormContour(x2,p,M{i},S{i});
    plot(x1L,x2,clr{c},x1H,x2,clr{c},'LineWidth',2);
end;
axis(axv)
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2'); box off
warning on


%% run kmeans on data and plot with color-coded class assignments
subplot(3,4,pn+3), hold off cla
[Zkm,~,W]=kmeans(Xall,length(X0),'replicates',50,'emptyaction','singleton');
for i=1:length(X0)
    Xk=Xall(Zkm==i,:); c=mode(Zorg(Z==i));
    if pn==9, c=i; end;
    plot(Xk(:,1),Xk(:,2),[clr{c} '.'],'MarkerSize',7); hold on;
end;
axis(axv)
set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2'); box off


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University