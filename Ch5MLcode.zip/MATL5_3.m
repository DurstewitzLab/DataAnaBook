clear all
close all

%% Example for multivar. KDE

% create data
X=mvnrnd(zeros(2,1),[1 0.5;0.5 1],200);

% define grid points for density evaluation
x1=-2.6:0.2:2.6;
x2=-2.6:0.2:2.6;
Z=zeros(length(x1)*length(x2),2);
A=repmat(x1,length(x2),1); Z(:,1)=A(1:end)';
Z(:,2)=repmat(x2',length(x1),1);

% run multivar. KDE with full kernel matrix (may take long!)
H0=cov(X); % initial estimate
[H,T,F,Bin]=KDensEstim(X,H0,[],Z);

% plot results
[X1,X2]=meshgrid(x1,x2);
F_=reshape(F,length(x1),length(x2));
contourf(X1,X2,F_); hold on
for i=1:size(X,1), plot3(X(i,1),X(i,2),0,'r.','MarkerSize',10); end
xlim([min(x1) max(x1)]); ylim([min(x2) max(x2)]);

%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University