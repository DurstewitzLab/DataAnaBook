function Xbs=DrawConvH(X)
% draw bootstrap data Xbs from convex hull of Nxp data matrix X

[K,v]=convhulln(X); % determine convex hull
K=unique(K);
[N,p]=size(X);
vRG=prod(range(X));
q=v/vRG; M=round(5*N/q);
mi=min(X); mx=max(X);
TES=delaunayn(X(K,:));
Xbs=[];
while size(Xbs,1)<N  % draw sample of N BS data points from within convex hull of X
    Y=ones(M,1)*mi+(ones(M,1)*(mx-mi)).*rand(M,p);
    t=tsearchn(X(K,:),TES,Y);
    Y=Y(~isnan(t),:);
    m=size(Xbs,1);
    Xbs=[Xbs;Y(1:N-m,:)];
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University