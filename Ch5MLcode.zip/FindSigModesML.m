function [Npts,pr,sig,sel,Ovlp,dgn]=FindSigModesML(R,eps,MinOvlp,alpha,wrpfl)
% searches for significant modes within a set of data points
% --- INPUTS
% R: Nxp data matrix
% [eps: relative box size (if <=1) or #k-nearest neighbors (if >1)]
% [MinOvlp: from boxes with rel. overlap > MinOlvp, at most 1 will be
% selected]
% [alpha: FDR level for selecting boxes (Benjamini & Hochberg 1995)]
% [wrpfl: 'wrap-flag'; if wrpfl==true, data space will be wrapped around
% (doesn't make sense with all types of data!)]
% --- OUTPUTS
% Npts: #points falling into the boxes
% pr: binomial prob.s associated with all boxes
% sig: boxes deemed significant after FDR correction (representing
% potential modes)
% sel: subset of boxes selected from those with overlap>MinOvlp 
% Ovlp: relative overlap among all box-pairs
% dgn: diagnostic info on max. #points in neighboring boxes (Nmaxnb),
% center of that box (ctr2_sv), points in neighborhood (kout), and eps
%
% NOTES:
% (i) This procedure is very conservative because a mode-region is
% considered not to be significant if it tests n.s. against ANY of the
% neighboring boxes --> The BH-procedure may be too strict in this case
% (ii) If eps is too small, modes may go completely undetected as any high-dens.
% region may have an equally high-dens. neighbor on these small scales!
% If on the other hand eps is too large and 2 modes are nearby, these
% modes may again go undetected as one mode is tested against the other.

if nargin<2 || isempty(eps), eps=0.1; end;
if nargin<3 || isempty(MinOvlp), MinOvlp=0.5; end;
if nargin<4 || isempty(alpha), alpha=0.05; end;
if nargin<5, wrpfl=false; end;
if nargout>5, DiagOn=true; else DiagOn=false; end;
if eps>1, Kneigh=eps; else Kneigh=[]; end;


N=size(R,1);
R=(R-ones(N,1)*min(R))./(ones(N,1)*range(R));   % scale data to unit cube range
Npts=zeros(1,N); pr=zeros(1,N); epsAll=zeros(1,N); kin2=cell(1,N);
Ovlp=sparse(N,N);    % zeros so the diagonal is not counted
Rsv=R;
for i=1:N
    R=Rsv;
    ctr=R(i,:);
    
    % wrap around torus along the dimensions on which range is exceeded
    % (wrap-around may not make sense with all data; e.g. with spike data,
    % high spike rate regions are by nature much less dense than SR~0 regions,
    % yet they become direct neighbors by virtue of the wrapping!!)
    if wrpfl && isempty(Kneigh)
        k1=find(ctr+eps/2>1);
        k2=find(ctr-eps/2<0);   % k1 and k2 should be mutually exclusive
        % cycle through all binary numbers from 1 to 2^(k1+k2)-1
        b=dec2bin(1:2^(k1+k2)-1);
        m=length(k1);
        for j=1:size(b,1)
            Rtemp=R;
            s=find(b(j,1:m)=='1');
            Rtemp(:,k1(s))=Rtemp(:,k1(s))+1;
            s=find(b(j,m+1:end)=='1');
            Rtemp(:,k2(s))=Rtemp(:,k2(s))-1;
            R=[R;Rtemp];
        end;
    end;
    
    % determine # of points falling into the eps-box
    Radj=R-ones(N,1)*ctr;
    if ~isempty(Kneigh)
        [v,s]=sort(max(abs(Radj')),'ascend');
        kin=s(1:Kneigh);
        eps=2*v(Kneigh);
        Npts(i)=Kneigh;
    else
        kin=InBox(Radj,eps/2);
        Npts(i)=length(kin);
    end;
    epsAll(i)=eps;
    
    % determine out-of-target-box points that fall into one neighboring box
    kin2{i}=InBox(Radj,3*eps/2);
    kout=kin2{i}(find(~ismember(kin2{i},kin)));
    
    % adjust each of these boxes to be a true non-overlapping neighbor and
    % count # data points within them
    % NOTE: This gives a speed advantage compared to a fixed set of boxes
    % only if Nneigh<3^d-1 (which may not be the case in low dim.)
    ctr2_sv=[]; % for diagnostics
    Nnbpts=[];
    for j=1:length(kout)
        ctr2=R(kout(j),:);
        k=find(abs(Radj(kout(j),:))>eps);
        if isempty(k), [v,k]=max(abs(Radj(kout(j),:))); end;
        ctr2(k)=ctr2(k)+sign(Radj(kout(j),k))*eps-Radj(kout(j),k);
        kin3=InBox(R-ones(N,1)*ctr2,eps/2);
        Nnbpts(j)=length(kin3);
        if DiagOn, ctr2_sv{j}=ctr2; end;
    end;
    
    % find neighboring box with most points and determine bionomial prob.
    % from this
    if isempty(Nnbpts), M=0; j=1; else [M,j]=max(Nnbpts); end;
    pr(i)=1-binocdf(Npts(i)-1,M+Npts(i),0.5);
    if DiagOn % diagnostic information
        dgn.Nmaxnb(i)=M;
        dgn.ctr_nb{i}=ctr2_sv{j};
        dgn.nbptr(i)=kout(j);
        dgn.eps(i)=eps;
    end;

end;

%% compute shared volume with all other boxes
% to make this faster, only those points in kin2 need to be considered
for i=1:N
    s=find(kin2{i}>i);
    for j=kin2{i}(s)'
        eps=(epsAll(i)+epsAll(j))/2;
        ov=(eps-abs(Rsv(i,:)-Rsv(j,:)))./eps;
        k=find(ov<0); ov(k)=0;
        Ovlp(i,j)=prod(ov); Ovlp(j,i)=Ovlp(i,j);
    end;
end;

%% pick from any set of boxes with overlap>MinOvlp only the one with highest
% density
sel=1:N;
for i=1:N
    k=find(Ovlp(i,:)>MinOvlp);
    if ~isempty(k)
        v=max(Npts(k)); j=find(Npts(k)==v);
        if (v>Npts(i)) || (v==Npts(i) && ...
                ~isempty(find(pr(k(j))<=pr(i)))), sel=setdiff(sel,i); end;
    end;
end;

%% select those modes as significant that pass the Benjamini-Hochberg
% procedure
Nsel=length(sel)
[prL,idc]=sort(pr(sel),'ascend');
M=length(prL);
L=max(find(prL<alpha*(1:M)./M));
sig=zeros(1,N);
if ~isempty(L)
    k=find(pr(sel)<=prL(L));
    sig(sel(k))=1;
end;


function kin=InBox(Radj,l)
p=size(Radj,2);
[a,b]=find(abs(Radj)<l);
u=unique(a); in=[];
for j=1:length(u), in(j)=length(find(a==u(j)))==p; end;
kin=u(find(in));


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University