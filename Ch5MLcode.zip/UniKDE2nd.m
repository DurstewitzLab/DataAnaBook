function [h,MISE,F]=UniKDE2nd(X,h0,Z,ub)
% --> same as UniKDE, but using 2nd order approach (Hessian) for optim.,
% and allowing for constraints on h
% This routine implements univariate nonparametric density estimation
% with bandwidth selection based on minimizing the mean integrated
% squared error (MISE), E[int((f^(x,h)-f(x))^2)], estimated through 
% unbiased cross-validation; based on Taylor (1989), Biometrika 76, pp 705-12.
%
% --- INPUTS
% X: univariate obs. point data
% h0: initial bandwidth estimate
% [Z: grid points at which density estimate is desired]
% [ub: upper bound for bandwidth estimate]
% --- OUTPUTS
% h: kernel bandwidth estimate
% MISE: final mean-integrated-squared-error
% F: density estimate evaluated at grid points in Z


% constrained CV-based optim. using Hessian of second derivatives
if nargin<4, ub=100; end;   % default upper bound
optimoptions('fmincon','GradObj','on','Hessian','on');
[h,MISE]=fmincon(@(h)UCVErr2(h,X),h0,[],[],[],[],0,ub);

% evaluate density at grid points specified in Z
if nargin>2 && ~isempty(Z), F=KDens(Z,X,h); end;


% unbiased cross-validation using analytic Hessian
function [err,derr,dderr]=UCVErr2(h,X)
N=length(X);
k0=1/(2*N^2*sqrt(2*pi));
k1=sqrt(2);
k2=4*N/(N-1);
k3=4*N^2/(N-1);
B=0; C=0;
dB=0; dC=0;
ddB=0; ddC=0;
for i=1:N-1
    for j=i+1:N
        z=(X(i)-X(j))^2;
        y1=exp(-z/(4*h));
        y2=exp(-z/(2*h));
        B=B+y1;
        C=C+y2;
        dB=dB+z/(4*h^2)*y1;
        dC=dC+z/(2*h^2)*y2;
        ddB=ddB+(z^2/(16*h^4)-z/(2*h^3))*y1;
        ddC=ddC+(z^2/(4*h^4)-z/h^3)*y2;
    end;
end;
B=2*B+N; C=2*C+N; A=1/sqrt(h);
dB=2*dB; dC=2*dC; dA=-1/2*h^(-3/2);
ddB=2*ddB; ddC=2*ddC; ddA=3/4*h^(-5/2);
err=k0*A*(k1*B-k2*C+k3);
derr=k0*dA*(k1*B-k2*C+k3)+k0*A*(k1*dB-k2*dC);
dderr=k0*ddA*(k1*B-k2*C+k3)+k0*dA*(k1*dB-k2*dC)+ ...
    k0*dA*(k1*dB-k2*dC)+k0*A*(k1*ddB-k2*ddC);


% evaluate kernel density at grid points using estimated h
function F=KDens(Z,X,h)
N=length(Z);
F=zeros(1,N);
a=1/sqrt(2*pi*h);
for i=1:N
    for j=1:length(X)
        dt=Z(i)-X(j);
        F(i)=F(i)+exp(-dt^2/(2*h));
    end;
end;
F=a*F./length(X);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
