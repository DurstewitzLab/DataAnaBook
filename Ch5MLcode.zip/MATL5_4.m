clear all
close all

%% Fig. 5.3: Example dendrogram(s)

%% create example distributions for 3 MV Gaussians with unequal cov, not well separable
randn('state',4);
N=200;
mu1={[-1;-2],[-4;1],[4;5]};    % group means
SI1={[4 3.5;3.5 4],[2 0;0 3],[1 1;1 4]}; % cov-matrices
X1=cell(1,3); for i=1:3, X1{i}=mvnrnd(mu1{i},SI1{i},N)'; end;

% plot classes
figure(3)
subplot(2,5,1), hold off cla
clr={'b','g','r'};
for i=1:length(X1)
    plot(X1{i}(1,:),X1{i}(2,:),[clr{i} '.'],'MarkerSize',7); hold on;
end;
set(gca,'FontSize',22); xlabel('x_1','FontSize',22); ylabel('x_2','FontSize',22); box off
title('3 classes'); axis([-10 10 -7 12])
Xall=cell2mat(X1)';

% run cluster analyses with different agglomeration criteria
Corg=ones(3*N,1); Corg(N+1:2*N,1)=2; Corg(2*N+1:end,1)=3;   % original class assignments
method={'single','complete','average','Ward'};  % linkage criteria to use
co=[0.55 12 5 50];  % cutoffs for class assignments; deliberately set to obtain (close to) 3 classes
for i=1:4
    m=size(Xall,1);
    Z=linkage(Xall,method{i},'euclidean');  % call cluster analysis
    gca=subplot(2,5,i+1); hold off cla
    dendrogram(Z,m); box off  % create dendrogram from linkage output
    set(gca,'XTickLabel',{[]}); set(gca,'FontSize',22);
    hold on; plot(1:m,zeros(1,m)+co(i),'r--','LineWidth',2);
    C=cluster(Z,'cutoff',co(i),'criterion','distance'); % assign obs. to classes based on linkage output
    
    % keep only 3 clusters with max. #members
    K=histc(C,unique(C));
    [~,r]=sort(K,'descend');
    Cnew=zeros(size(C));
    for j=1:3, Cnew(C==r(j))=j; end; C=Cnew;
    
    % compute relative overlaps between ground truth and retrieved classes 
    ovlp=zeros(length(X1));
    for l=1:length(X1)
        for j=1:length(X1)
            r1=find(C==l); r2=find(Corg==j);
            ovlp(l,j)=length(intersect(r1,r2))/length(union(r1,r2));
        end;
    end;
    U=mean(max(ovlp')); % average overlaps across best-matching classes
    title([method{i} ' (' num2str(round(100*U)/100) ')']);
end;


%% create example distributions for 3x3 nested MV Gaussians
N=30;
mu2={[-3;-3],[-2;-5],[0;-1],[-3.5;3],[-2;3],[-4;0],[3;5],[4.5;6],[4.5;3]};    % group means
SI2={[4 3.5;3.5 4]./2,[2 0;0 3]./2,[1 1;1 4]./2}; % cov-matrices
X2=cell(1,9); for i=1:9, X2{i}=mvnrnd(mu2{i},SI2{ceil(i/3)},N)'; end;

% plot classes
gca=subplot(2,5,6); hold off cla;
cm=colormap('jet');
clr=[1 8 20 30 35 40 47 56 64];
for i=1:length(X2)
    plot(X2{i}(1,:),X2{i}(2,:),'.','Color',cm(clr(i),:),'MarkerSize',7); hold on;
end;
set(gca,'FontSize',22); xlabel('x_1','FontSize',22); ylabel('x_2','FontSize',22); box off
title('3x3 nested'); axis([-10 10 -9 10])
Xall=cell2mat(X2)';

% run cluster analyses with different agglomeration criteria
for i=1:4
    Z=linkage(Xall,method{i},'euclidean');  % call cluster analysis
    gca=subplot(2,5,i+6); hold off cla
    dendrogram(Z,size(Xall,1)); box off  % create dendrogram from linkage output
    set(gca,'XTickLabel',{[]}); set(gca,'FontSize',22);
    title(method{i});
end;


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University