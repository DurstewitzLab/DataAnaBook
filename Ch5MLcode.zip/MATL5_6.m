clear all
close all

%% Fig. 5.5: Illustration of how mode-hunting formalism works
figure, hold off cla

eps=0.7;
randn('state',0);
Xall=randn(8,2);
ctrs=Xall([3 4],:);
plot(Xall(:,1),Xall(:,2),'k.','MarkerSize',10); hold on;
i=1;
for i=1:size(ctrs,2)
    bx=[ctrs(i,1)-eps/2 ctrs(i,1)+eps/2];
    by=[ctrs(i,2)-eps/2 ctrs(i,2)+eps/2];
    Bx=[bx(1) bx(2) bx(2) bx(1) bx(1)];
    By=[by(1) by(1) by(2) by(2) by(1)];
    plot(Bx,By,'k','LineWidth',2);
    if i==1
        plot(bx,[by(1)-0.1 by(1)-0.1],'r','LineWidth',2)
        plot([bx(1) bx(1)],[by(1)-0.15 by(1)-0.05],'r','LineWidth',2)
        plot([bx(2) bx(2)],[by(1)-0.15 by(1)-0.05],'r','LineWidth',2)
        text(bx(1)+0.5*diff(bx),by(1)-0.3,'\epsilon','Color','r','FontSize',22);
    end;
end;

i=1;
bx=[ctrs(i,1)-3*eps/2 ctrs(i,1)+3*eps/2];
by=[ctrs(i,2)-3*eps/2 ctrs(i,2)+3*eps/2];
Bx=[bx(1) bx(2) bx(2) bx(1) bx(1)];
By=[by(1) by(1) by(2) by(2) by(1)];
plot(Bx,By,'k:','LineWidth',2);
text(bx(2)+0.1,by(1),'\it{U}_i','FontSize',22);

i=2;
deps=abs(Xall(4,2)-Xall(3,2))-eps;
bx=[ctrs(i,1)-eps/2 ctrs(i,1)+eps/2];
by=[ctrs(i,2)-deps-eps/2 ctrs(i,2)-deps+eps/2];
Bx=[bx(1) bx(2) bx(2) bx(1) bx(1)];
By=[by(1) by(1) by(2) by(2) by(1)];
plot(Bx,By,'k--','LineWidth',2);
plot([bx(2)+0.1 bx(2)+0.1],[by(1) ctrs(2,2)],'r','LineWidth',2)
plot([bx(2)+0.05 bx(2)+0.15],[by(1) by(1)],'r','LineWidth',2)
plot([bx(2)+0.05 bx(2)+0.15],[ctrs(2,2) ctrs(2,2)],'r','LineWidth',2)
text(bx(2)+0.2,by(1)+0.5*(ctrs(2,2)-by(1)),'\Delta\epsilon^(^1^)_j_k','Color','r','FontSize',22);
plot([bx(2)+0.1 bx(2)+0.1],[ctrs(2,2) by(2)],'r','LineWidth',2)
plot([bx(2)+0.05 bx(2)+0.15],[by(2) by(2)],'r','LineWidth',2)
text(bx(2)+0.2,by(2)-0.06,'\Delta\epsilon^(^2^)_j_k','Color','r','FontSize',22);
text(ctrs(1,1)+0.05,ctrs(1,2),'\bf{x}_i','FontSize',22);
text(ctrs(2,1)+0.05,ctrs(2,2),'\bf{x}_j','FontSize',22);
axis('off')

set(gca,'FontSize',20); xlabel('x_1'); ylabel('x_2'); box off
axis([-2 2 -2 2])


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University