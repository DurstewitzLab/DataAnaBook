function [h,MISE,F]=UniKDE(X,h0,Z)
% This routine implements univariate nonparametric density estimation
% with bandwidth selection based on minimizing the mean integrated
% squared error (MISE), E[int((f^(x,h)-f(x))^2)], estimated through 
% unbiased cross-validation; based on Taylor (1989), Biometrika 76, pp 705-12.
%
% --- INPUTS
% X: univariate obs. point data
% h0: initial bandwidth estimate
% [Z: grid points at which density estimate is desired]
% --- OUTPUTS
% h: kernel bandwidth estimate
% MISE: final mean-integrated-squared-error
% F: density estimate evaluated at grid points in Z


[h,MISE]=fminsearch(@UCVErr1,h0,[],X);   % unbiased cross-validation

% evaluate density at grid points specified in Z
if nargin>2 && ~isempty(Z), F=KDens(Z,X,h); end;


% unbiased cross-validation error
function err=UCVErr1(h,X)   % returns UCV(h) in Taylor (1989)
N=length(X);
a1=1/(N^2*sqrt(4*h*pi));
a2=2/(N*(N-1)*sqrt(2*h*pi));
a3=2/((N-1)*sqrt(2*h*pi));
err1=0; err2=0;
for i=1:N-1
    for j=i+1:N
        b=(X(i)-X(j))^2;
        err1=err1+exp(-b/(4*h));
        err2=err2+exp(-b/(2*h));
    end;
end;
err=a1*(N+2*err1)-a2*(N+2*err2)+a3;


% evaluate kernel density at grid points using estimated h
function F=KDens(Z,X,h)
N=length(Z);
F=zeros(1,N);
a=1/sqrt(2*pi*h);
for i=1:N
    for j=1:length(X)
        dt=Z(i)-X(j);
        F(i)=F(i)+exp(-dt^2/(2*h));
    end;
end;
F=a*F./length(X);


%%
% (c) 2017 Daniel Durstewitz, Dept. Theoretical Neuroscience,
% Central Institute of Mental Health, Heidelberg University
